ZinKit customer search and voice-search update.

HIGH-QUALITY PRODUCT PHOTOS
- Admin product form supports Image 1, Image 2, and Image 3 uploads to existing Supabase Storage.
- Images up to 2.5 MB are preserved without recompression; larger images are optimized to a maximum 2400 px edge at JPEG quality 90 to balance clarity and upload size.
- Customer product cards use contain-fit photos and a slightly taller image area so products are less likely to be cropped. Product detail gallery also uses contain-fit.
- Existing product table columns and Storage bucket fallback behavior are preserved.
- This is a code/package update only. Actual upload still depends on existing Supabase Storage buckets and policies; test with a real product photo after deploying.
