ZinKit Customer — More Products You May Like

When a customer opens a product, the detail screen now displays up to 20 other products instead of only 6. Same-category products appear first, then same-brand products, followed by other products. The opened product is excluded and duplicates are removed. This uses the existing products data; no Supabase schema, credentials, orders, stores, or existing data are changed.

Deploy the Customer app files from this package to publish the change. This package has not been deployed to Vercel.
