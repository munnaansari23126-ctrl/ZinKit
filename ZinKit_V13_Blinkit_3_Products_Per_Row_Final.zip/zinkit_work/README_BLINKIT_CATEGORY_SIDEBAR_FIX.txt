ZinKit V13 — Blinkit-style Category Sidebar Fix

Change:
- Tapping a category tile now opens the Categories screen rather than jumping directly to the home product list.
- The Categories screen keeps the vertical left-side category rail and right-side category/subcategory area.
- Selecting a left-side main category updates the active category and refreshes the right-side panel.
- Existing app files, Supabase configuration, cart/order/rider code and Admin/Rider apps are preserved.

Validation: ZIP archive check and Customer inline JavaScript syntax check passed.
Not verified: live Supabase product loading, Vercel deployment, or device interaction test.
