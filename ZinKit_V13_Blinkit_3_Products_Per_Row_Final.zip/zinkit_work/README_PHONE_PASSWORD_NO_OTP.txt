ZinKit V13 — Phone + Password (No OTP) Customer Login Patch

Customer App login UI changed to mobile number + password, with Create Account and Login actions using Supabase Auth phone/password methods.

REQUIRED Supabase settings before deployment:
1. Authentication > Sign In / Providers > Phone must be enabled.
2. Disable phone confirmations if you truly want signup without SMS OTP. Menu wording can vary by dashboard version.
3. Supabase Auth phone numbers must use India E.164 format (+91 followed by the 10-digit number).
4. Test in a staging project first. This no-OTP mode does NOT verify ownership of the phone number. Anyone can register an unverified number, so do not treat the phone number as proof of identity. Consider limiting access to sensitive account recovery flows.

Important compatibility note:
- Existing email-based accounts are not automatically migrated or linked to phone/password accounts.
- Existing Supabase project, tables, SQL, Admin, Rider and product/order data were not changed by this ZIP patch.
- The patch does not change live Vercel or Supabase settings. Deploy only after testing.
