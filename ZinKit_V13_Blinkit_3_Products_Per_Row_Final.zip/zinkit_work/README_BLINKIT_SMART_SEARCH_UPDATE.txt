ZinKit V13 — Blinkit-Style Smart Search Update

Updated in Customer/index.html:
- Keeps the existing live app structure and existing Supabase configuration/data untouched.
- Improves search matching across product name, brand, category, subcategory, variant and keywords.
- Reduces false matches caused by loose fuzzy matching across long descriptions.
- Keeps product suggestions, category/brand suggestions, Enter-to-search, clear-search and existing voice-search UI/handler.
- Keeps the existing Hotel one-tap/category screen code in place.
- Keeps the existing Customer, Admin and Rider files in the package.

Validation performed:
- ZIP archive integrity test passed.
- Inline JavaScript syntax check passed with Node.js.

Important:
- This is a code package validation, not a live Vercel/Supabase integration test.
- Deploy to a preview/staging URL first and test with actual catalog data.
- No database SQL, Supabase project, customer/order records, or credentials were changed.
- Voice search depends on browser SpeechRecognition support and microphone permission.
