ZinKit Customer Product Reviews

Added to Customer app:
- Product detail page has a 1–5 star rating and review form.
- Customers submit a review using their saved customer mobile login.
- Approved reviews and average rating/count appear on that product's detail page.
- Review rows include product_id and store_id, so the product/store context is preserved.

IMPORTANT SETUP (one-time):
1. Open Supabase Dashboard -> SQL Editor.
2. Run the supplied SUPABASE_PRODUCT_REVIEWS.sql.
3. Deploy the updated Customer/index.html with the existing Admin and Rider folders.

The review form uses the existing customer phone-only login. This is not strong identity verification; if you need verified-purchase reviews or moderation, add Supabase Auth/order checks and an Admin moderation panel before production.
