-- ZinKit V13 Order Privacy Fix — aligned to the existing orders.user_id column.
-- BACK UP first. Run in staging first and verify Admin/Rider flows before production.
-- Does not add a duplicate customer_id column and does not migrate old orders by phone.
begin;
alter table public.orders enable row level security;

-- Remove permissive legacy policies so they cannot OR-bypass ownership rules.
do $$ declare p record; begin
  for p in select policyname from pg_policies where schemaname='public' and tablename='orders'
  loop execute format('drop policy if exists %I on public.orders',p.policyname); end loop;
end $$;

revoke all on public.orders from anon;
grant select, insert, update on public.orders to authenticated;

-- Customers may read only orders whose user_id matches their verified Supabase Auth ID.
create policy zinkit_orders_customer_select on public.orders
for select to authenticated
using (user_id = (select auth.uid()));

-- Customers may create only orders linked to their own Auth ID.
create policy zinkit_orders_customer_insert on public.orders
for insert to authenticated
with check (user_id = (select auth.uid()));

-- Customer updates are limited by trigger below to status-only cancellation.
create policy zinkit_orders_customer_update on public.orders
for update to authenticated
using (user_id = (select auth.uid()))
with check (user_id = (select auth.uid()));

-- Admin access remains available through profiles.role='admin'.
create policy zinkit_orders_admin_all on public.orders
for all to authenticated
using (exists (select 1 from public.profiles p where p.id=(select auth.uid()) and p.role='admin'))
with check (exists (select 1 from public.profiles p where p.id=(select auth.uid()) and p.role='admin'));

-- Riders can read/update only orders already assigned to their Auth UUID.
create policy zinkit_orders_rider_select on public.orders
for select to authenticated
using (rider_id=(select auth.uid()) and exists (select 1 from public.profiles p where p.id=(select auth.uid()) and p.role='rider'));
create policy zinkit_orders_rider_update on public.orders
for update to authenticated
using (rider_id=(select auth.uid()) and exists (select 1 from public.profiles p where p.id=(select auth.uid()) and p.role='rider'))
with check (rider_id=(select auth.uid()) and exists (select 1 from public.profiles p where p.id=(select auth.uid()) and p.role='rider'));

create or replace function public.zinkit_guard_order_update()
returns trigger language plpgsql security definer set search_path=public as $$
declare is_admin boolean; is_rider boolean;
begin
  select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin') into is_admin;
  if is_admin then return new; end if;
  select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='rider') into is_rider;
  if old.user_id=auth.uid() then
    if new.status is distinct from 'Cancelled'
       or (to_jsonb(new)-'status'-'updated_at') is distinct from (to_jsonb(old)-'status'-'updated_at') then
      raise exception 'Customers may only cancel their own order';
    end if;
    return new;
  end if;
  if is_rider and old.rider_id=auth.uid() and new.rider_id=auth.uid() then
    if (to_jsonb(new)-'status'-'updated_at') is distinct from (to_jsonb(old)-'status'-'updated_at') then
      raise exception 'Riders may only update status for assigned orders';
    end if;
    return new;
  end if;
  raise exception 'Not authorized to update this order';
end; $$;
drop trigger if exists zinkit_guard_order_update_trigger on public.orders;
create trigger zinkit_guard_order_update_trigger before update on public.orders
for each row execute function public.zinkit_guard_order_update();

-- Returns are scoped to orders.user_id. Verify the return table and column names before running.
alter table public.order_return_requests enable row level security;
do $$ declare p record; begin
  for p in select policyname from pg_policies where schemaname='public' and tablename='order_return_requests'
  loop execute format('drop policy if exists %I on public.order_return_requests',p.policyname); end loop;
end $$;
revoke all on public.order_return_requests from anon;
grant select, insert on public.order_return_requests to authenticated;
create policy zinkit_returns_customer_select on public.order_return_requests
for select to authenticated using (
 exists(select 1 from public.orders o where o.id=order_return_requests.order_id and o.user_id=(select auth.uid()))
);
create policy zinkit_returns_customer_insert on public.order_return_requests
for insert to authenticated with check (
 exists(select 1 from public.orders o where o.id=order_return_requests.order_id and o.user_id=(select auth.uid()))
);
create policy zinkit_returns_admin_all on public.order_return_requests
for all to authenticated using (
 exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.role='admin')
) with check (
 exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.role='admin')
);
commit;

-- IMPORTANT:
-- 1) This assumes public.profiles(id uuid, role text), orders.user_id/rider_id uuid,
--    and order_return_requests(order_id). Check these columns before applying.
-- 2) Existing orders with user_id NULL will be hidden from customers until ownership
--    is verified independently. Never assign ownership from a typed phone number alone.
-- 3) Riders cannot claim unassigned orders with this policy; admin must assign them first.
-- 4) Email OTP verifies the email, not the phone number. SMS phone verification is separate.
-- 5) Do not run in production until Admin/Rider workflows and return table schema are verified.
