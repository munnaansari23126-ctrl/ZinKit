ZinKit V13 - Featured Food Promo Media

Admin App: open Featured Food panel and use Featured Food Promo Media to set Brand/Store Name, upload a logo, promotional photo and/or video, choose active state and tap action. Settings are saved as JSON in app_settings under key featured_food_media.

Customer App: active media renders inside the Featured Food section, directly under its title, plus a compact promo card beside the food chips. The side card can show the uploaded logo, photo/video, store name and caption. Video is muted, does not autoplay, and has controls. Tapping a promo opens the selected category.

Storage: uploads use existing ad-images (logo/photo), product-images as a photo fallback, and ad-videos (video). The relevant bucket must exist, be accessible to the admin session for uploads, and have public read access for customer rendering. No SQL schema change is required. Existing app_settings keys and products/orders/store data are not changed.

Validation performed: ZIP integrity and inline JavaScript syntax checks. Live Supabase Storage/RLS and Vercel/mobile deployment still need to be tested in the actual project.
