ZinKit Fast Search V13 — Admin + Customer + Rider

Project name: zinkit_fast_search_v13_admin_customer_rider

This V13 package is based on the supplied V12 ZIP so existing app files and features are preserved. It includes the existing Customer, Admin, and Rider apps, PWA manifests/service workers, fast search, voice search, fashion/category sections, Order Again/profile shortcut, and existing SQL/README files.

Important: This package rename/versioning alone does not prove that a live Supabase connection, orders, inventory, or rider GPS works. Test on staging before deployment. Keep the same Supabase project/config unless you explicitly intend to migrate.
