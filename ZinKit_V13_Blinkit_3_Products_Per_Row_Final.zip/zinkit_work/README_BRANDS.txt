ZinKit Brand Management

1. Run SUPABASE_BRANDS.sql in the same Supabase project used by ZinKit.
2. Open Admin/index.html. In Quick Controls, open 🏷️ Brands.
3. Add brand name, optional logo URL, optional description, and choose Global or a store.
4. Active brands appear in Customer App under “Shop by Brand”; tapping a brand filters products whose products.brand matches that name.
5. In Admin > Products, fill the Brand field on products to connect them to the brand.

Security note: the current browser-only Admin has no server-side admin authorization in this module. Included write policies allow public client writes for functionality and are not production-grade. Before production, replace them with authenticated admin-only policies/RPC or server-side validation.
