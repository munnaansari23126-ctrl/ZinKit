ZinKit Fashion Store Admin — V8

Added in Admin app:
- New Quick Controls entry: Fashion Store Products.
- Fashion product helper inside the existing Products panel.
- One-tap category shortcuts: Store, Men, Women, Accessories, Innerwear, Footwear, Kids, Jewellery.
- Opens/reuses the existing products form, current store selector, product table, and product image upload flow.
- Adds any missing fashion categories to the existing app_settings product_categories list (does not create a new table).
- Uses existing product colour, size, size-wise stock, brand, variant/price, and Image 1/2/3 fields.

Important:
- No separate Fashion/Cloth table was added.
- Existing Customer, Rider, Supabase connection, cart/order/payment/tracking code was left unchanged.
- Live Supabase save, Customer display, and phone/browser end-to-end tests are not verified by static validation. Test in staging before production/Play Store deployment.
