ZinKit Blinkit-Style Home Screen V6

Customer home screen order:
1. Delivery location bar (existing location/GPS logic retained)
2. Search and voice search (existing search logic retained)
3. All Products shortcut
4. Promotional banner (existing Admin/Supabase banner settings retained)
5. Popular Products
6. Shop by Category
7. Featured Food
8. Shop by Brand (loads from existing brands table)
9. Product grid with clear contained images, price and Add/quantity controls

Scope: Customer home page layout/CSS and removal of the side-category DOM rearrangement only. Existing Admin and Rider files and app logic are retained from the input archive.

Validation: ZIP integrity and inline JavaScript syntax checks are run on this archive. Live GPS permissions, Supabase reads/writes, checkout, and rider tracking require runtime/device testing and are not certified by this package.
