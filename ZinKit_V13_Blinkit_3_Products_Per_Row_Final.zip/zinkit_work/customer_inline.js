
const MD_MUNNA_DAILY_ORDER_LIMIT=1000;

/* ZinKit shared delivery settings — loaded from Admin -> Supabase app_settings. */
let ZINKIT_DELIVERY_RESTRICTION_ENABLED = true;
let ZINKIT_STORE_LAT = null;
let ZINKIT_STORE_LON = null;
let ZINKIT_DELIVERY_FRONT_KM = 10;
let ZINKIT_DELIVERY_BACK_KM = 10;
let ZINKIT_DELIVERY_LEFT_KM = 10;
let ZINKIT_DELIVERY_RIGHT_KM = 10;
let ZINKIT_STORE_NAME = 'ZinKit Store';
let ZINKIT_ACTIVE_STORE_ID = null;
let ZINKIT_ACTIVE_STORE_AREA = '';
let ZINKIT_ACTIVE_STORE_RANGE_KM = 10;
let ZINKIT_ACTIVE_STORE_CHARGE = 0;
let ZINKIT_DELIVERY_SETTINGS_READY = false;
let ZINKIT_STORE_MATCH_SOURCE = 'legacy';

function zinkitDistanceKm(lat1,lon1,lat2,lon2){
  const R=6371, toRad=x=>x*Math.PI/180;
  const dLat=toRad(lat2-lat1), dLon=toRad(lon2-lon1);
  const a=Math.sin(dLat/2)**2 + Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dLon/2)**2;
  return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
}

function zinkitMaxDeliveryRadiusKm(){
  return Math.max(
    Number(ZINKIT_DELIVERY_FRONT_KM)||0,
    Number(ZINKIT_DELIVERY_BACK_KM)||0,
    Number(ZINKIT_DELIVERY_LEFT_KM)||0,
    Number(ZINKIT_DELIVERY_RIGHT_KM)||0
  );
}

function zinkitDeliveryDistance(lat,lon){
  if(!Number.isFinite(Number(ZINKIT_STORE_LAT)) || !Number.isFinite(Number(ZINKIT_STORE_LON))) return NaN;
  return zinkitDistanceKm(Number(ZINKIT_STORE_LAT),Number(ZINKIT_STORE_LON),Number(lat),Number(lon));
}

function zinkitCheckDeliveryRange(lat,lon){
  /* OFF = no store-distance restriction. */
  if(!ZINKIT_DELIVERY_RESTRICTION_ENABLED){
    return {allowed:true,distance:zinkitDeliveryDistance(lat,lon),unrestricted:true};
  }
  const d=zinkitDeliveryDistance(lat,lon);
  const radius=zinkitMaxDeliveryRadiusKm();
  const allowed=Number.isFinite(d) && radius>0 && d<=radius;
  return {allowed,distance:d,radius,unrestricted:false};
}

function zinkitShowRangeStatus(distance,allowed){
  const el=$('orderPlaceStatus');
  if(!el)return;
  if(!ZINKIT_DELIVERY_RESTRICTION_ENABLED){
    el.textContent='✅ Delivery restriction OFF • Normal / unrestricted delivery';
    el.style.color='#16852b';
    return;
  }
  const radius=zinkitMaxDeliveryRadiusKm();
  if(!Number.isFinite(Number(distance))){
    el.textContent='❌ Store location Admin app mein set nahi hai.';
    el.style.color='#c62828';
    return;
  }
  el.textContent=allowed
    ? `✅ Delivery available • ${distance.toFixed(1)} km away (within ${radius} km)`
    : `❌ Delivery available nahi hai • ${distance.toFixed(1)} km away. ZinKit delivery range ${radius} km hai.`;
  el.style.color=allowed?'#16852b':'#c62828';
}

function zinkitDirectionAllowed(store,lat,lon){
  const slat=Number(store.latitude), slon=Number(store.longitude), clat=Number(lat), clon=Number(lon);
  if(![slat,slon,clat,clon].every(Number.isFinite)) return {allowed:false,distance:NaN,radius:0,direction:''};
  const distance=zinkitDistanceKm(slat,slon,clat,clon);
  if(store.delivery_restriction_enabled===false) return {allowed:true,distance,radius:Infinity,direction:'Unrestricted'};
  const y=Math.sin((clon-slon)*Math.PI/180)*Math.cos(clat*Math.PI/180);
  const x=Math.cos(slat*Math.PI/180)*Math.sin(clat*Math.PI/180)-Math.sin(slat*Math.PI/180)*Math.cos(clat*Math.PI/180)*Math.cos((clon-slon)*Math.PI/180);
  const bearing=(Math.atan2(y,x)*180/Math.PI+360)%360;
  let direction, key;
  if(bearing>=315||bearing<45){direction='North';key='delivery_front_km';}
  else if(bearing<135){direction='East';key='delivery_right_km';}
  else if(bearing<225){direction='South';key='delivery_back_km';}
  else {direction='West';key='delivery_left_km';}
  const fallback=Number(store.delivery_range_km)||0;
  const radius=Math.max(0,Number(store[key] ?? fallback)||0);
  return {allowed:radius>0 && distance<=radius,distance,radius,direction};
}
function zinkitSaveStoreChoice(id){
  if(id==null||id==='') localStorage.removeItem('zinkit_selected_store_id');
  else localStorage.setItem('zinkit_selected_store_id',String(id));
}
function zinkitGetStoreChoice(){return localStorage.getItem('zinkit_selected_store_id')||'';}
async function zinkitSelectStore(id){
  const stores=window.ZINKIT_STORES||[]; const s=stores.find(x=>String(x.id)===String(id));
  if(!s)return;
  // Manual store selection must not hide the store's products just because
  // the developer/test device is outside that store's delivery radius.
  // Delivery restriction is enforced at checkout; product browsing remains
  // available for the selected store.
  ZINKIT_ACTIVE_STORE_ID=s.id; ZINKIT_STORE_NAME=String(s.name||'ZinKit Store'); ZINKIT_ACTIVE_STORE_AREA=String(s.area||'');
  ZINKIT_STORE_LAT=Number(s.latitude); ZINKIT_STORE_LON=Number(s.longitude);
  ZINKIT_ACTIVE_STORE_RANGE_KM=Number(s.delivery_range_km)||10;
  ZINKIT_ACTIVE_STORE_CHARGE=Math.min(30,Math.max(0,Number(s.delivery_charge)||0));
  ZINKIT_DELIVERY_RESTRICTION_ENABLED=s.delivery_restriction_enabled!==false;
  ZINKIT_DELIVERY_FRONT_KM=Number(s.delivery_front_km??s.delivery_range_km??10)||0;
  ZINKIT_DELIVERY_BACK_KM=Number(s.delivery_back_km??s.delivery_range_km??10)||0;
  ZINKIT_DELIVERY_LEFT_KM=Number(s.delivery_left_km??s.delivery_range_km??10)||0;
  ZINKIT_DELIVERY_RIGHT_KM=Number(s.delivery_right_km??s.delivery_range_km??10)||0;
  ZINKIT_STORE_MATCH_SOURCE='manual'; window.ZINKIT_SELECTED_STORE={store:s}; zinkitSaveStoreChoice(s.id);
  zinkitUpdateSelectedStoreUI(); await loadProducts();
}
async function zinkitLoadDeliverySettings(){
  if(!db){
    ZINKIT_DELIVERY_SETTINGS_READY=true;
    return;
  }
  try{
    /* Multi-store first: active stores are candidates and the nearest
       store inside its own delivery range is selected for the customer. */
    /* Read all store columns so Customer V24 remains compatible with the
       current multi-store schema even when optional delivery columns have
       not been added to every store yet. */
    const sr=await db.from('stores')
      .select('*')
      .eq('active',true);

    if(!sr.error && Array.isArray(sr.data) && sr.data.length){
      window.ZINKIT_STORES=sr.data;
      let customerLat=Number(deliveryLocation?.latitude);
      let customerLon=Number(deliveryLocation?.longitude);

      if(Number.isFinite(customerLat) && Number.isFinite(customerLon)){
        let best=null;
        const savedId=zinkitGetStoreChoice();
        for(const s of sr.data){
          const slat=Number(s.latitude), slon=Number(s.longitude);
          /* Ignore placeholder 0,0 store coordinates during nearest-store
             matching; they must never win over a real store location. */
          if(!Number.isFinite(slat)||!Number.isFinite(slon)||(slat===0&&slon===0)) continue;
          const chk=zinkitDirectionAllowed(s,customerLat,customerLon);
          if(chk.allowed && (!best || (String(s.id)===String(savedId)) || chk.distance<best.distance)){
            best={store:s,distance:chk.distance,range:chk.radius,allowed:chk.allowed,restriction:s.delivery_restriction_enabled!==false,direction:chk.direction};
            if(String(s.id)===String(savedId)) break;
          }
        }
        if(best){
          const s=best.store;
          ZINKIT_ACTIVE_STORE_ID=s.id;
          ZINKIT_STORE_NAME=String(s.name||'ZinKit Store');
          ZINKIT_ACTIVE_STORE_AREA=String(s.area||'');
          ZINKIT_STORE_LAT=Number(s.latitude);
          ZINKIT_STORE_LON=Number(s.longitude);
          ZINKIT_ACTIVE_STORE_RANGE_KM=best.range;
          ZINKIT_ACTIVE_STORE_CHARGE=Math.min(30,Math.max(0,Number(s.delivery_charge)||0));
          ZINKIT_DELIVERY_RESTRICTION_ENABLED=best.restriction;
          ZINKIT_DELIVERY_FRONT_KM=Number(s.delivery_front_km??s.delivery_range_km??best.range)||0;
          ZINKIT_DELIVERY_BACK_KM=Number(s.delivery_back_km??s.delivery_range_km??best.range)||0;
          ZINKIT_DELIVERY_LEFT_KM=Number(s.delivery_left_km??s.delivery_range_km??best.range)||0;
          ZINKIT_DELIVERY_RIGHT_KM=Number(s.delivery_right_km??s.delivery_range_km??best.range)||0;
          window.ZINKIT_SELECTED_STORE=best;
          ZINKIT_STORE_MATCH_SOURCE='multi-store';
          ZINKIT_DELIVERY_SETTINGS_READY=true;
          return;
        }
      }

      // No GPS match: keep a previously selected active store, otherwise use
      // the first active store so store-scoped products never disappear just
      // because location permission is unavailable. Delivery restriction is
      // still enforced when the customer attempts a location-based checkout.
      const savedId=zinkitGetStoreChoice();
      // Without GPS, browse the active catalogue across stores by default.
      // Only narrow to one store when the customer explicitly selected that store.
      // This prevents a configured Admin store with no products from making the
      // whole Home Screen look empty before the customer adds a delivery location.
      const preferredId=savedId && String(savedId)!=='all' ? String(savedId) : '';
      if(!preferredId){
        ZINKIT_ACTIVE_STORE_ID=null;
        ZINKIT_STORE_NAME='All Stores';
        ZINKIT_ACTIVE_STORE_AREA='';
        ZINKIT_STORE_LAT=null; ZINKIT_STORE_LON=null;
        ZINKIT_ACTIVE_STORE_RANGE_KM=0; ZINKIT_ACTIVE_STORE_CHARGE=0;
        ZINKIT_STORE_MATCH_SOURCE='all-stores';
        window.ZINKIT_SELECTED_STORE={store:null,allStores:true};
        zinkitSaveStoreChoice('all');
        zinkitUpdateSelectedStoreUI();
        ZINKIT_DELIVERY_SETTINGS_READY=true;
        return;
      }
      const saved=sr.data.find(s=>String(s.id)===String(preferredId));
      const validStores=sr.data.filter(s=>{
        const la=Number(s.latitude),lo=Number(s.longitude);
        return Number.isFinite(la)&&Number.isFinite(lo)&&!(la===0&&lo===0);
      });
      const chosen=saved||validStores[0]||sr.data[0];
      if(chosen){
        ZINKIT_ACTIVE_STORE_ID=chosen.id;
        ZINKIT_STORE_NAME=String(chosen.name||'ZinKit Store');
        ZINKIT_ACTIVE_STORE_AREA=String(chosen.area||'');
        ZINKIT_STORE_LAT=Number(chosen.latitude);
        ZINKIT_STORE_LON=Number(chosen.longitude);
        ZINKIT_ACTIVE_STORE_RANGE_KM=Number(chosen.delivery_range_km)||10;
        ZINKIT_ACTIVE_STORE_CHARGE=Math.min(30,Math.max(0,Number(chosen.delivery_charge)||0));
        ZINKIT_DELIVERY_RESTRICTION_ENABLED=chosen.delivery_restriction_enabled!==false;
        ZINKIT_DELIVERY_FRONT_KM=Number(chosen.delivery_front_km??chosen.delivery_range_km??10)||0;
        ZINKIT_DELIVERY_BACK_KM=Number(chosen.delivery_back_km??chosen.delivery_range_km??10)||0;
        ZINKIT_DELIVERY_LEFT_KM=Number(chosen.delivery_left_km??chosen.delivery_range_km??10)||0;
        ZINKIT_DELIVERY_RIGHT_KM=Number(chosen.delivery_right_km??chosen.delivery_range_km??10)||0;
        window.ZINKIT_SELECTED_STORE={store:chosen};
        ZINKIT_STORE_MATCH_SOURCE='multi-store-default';
        zinkitSaveStoreChoice(chosen.id);
        zinkitUpdateSelectedStoreUI();
        ZINKIT_DELIVERY_SETTINGS_READY=true;
        return;
      }
    }

    /* Backward-compatible fallback to the existing app_settings system. */
    const keys=[
      'active_store_id',
      'delivery_restriction_enabled',
      'store_name',
      'store_latitude',
      'store_longitude',
      'delivery_front_km',
      'delivery_back_km',
      'delivery_left_km',
      'delivery_right_km'
    ];
    const r=await db.from('app_settings').select('key,value').in('key',keys);
    if(r.error) throw r.error;
    const m=Object.fromEntries((r.data||[]).map(x=>[x.key,x.value]));
    ZINKIT_ACTIVE_STORE_ID=m.active_store_id||null;
    ZINKIT_STORE_NAME=String(m.store_name||'ZinKit Store');
    ZINKIT_STORE_LAT=Number(m.store_latitude);
    ZINKIT_STORE_LON=Number(m.store_longitude);
    ZINKIT_DELIVERY_RESTRICTION_ENABLED=String(m.delivery_restriction_enabled??'true').toLowerCase()==='true';
    ZINKIT_DELIVERY_FRONT_KM=Math.max(0,Number(m.delivery_front_km??10)||0);
    ZINKIT_DELIVERY_BACK_KM=Math.max(0,Number(m.delivery_back_km??10)||0);
    ZINKIT_DELIVERY_LEFT_KM=Math.max(0,Number(m.delivery_left_km??10)||0);
    ZINKIT_DELIVERY_RIGHT_KM=Math.max(0,Number(m.delivery_right_km??10)||0);
    ZINKIT_ACTIVE_STORE_RANGE_KM=zinkitMaxDeliveryRadiusKm();
    ZINKIT_STORE_MATCH_SOURCE='legacy';
    ZINKIT_DELIVERY_SETTINGS_READY=true;
  }catch(e){
    console.warn('Multi-store delivery settings load failed:',e?.message||e);
    ZINKIT_DELIVERY_SETTINGS_READY=false;
  }
}
function zinkitDeliveryRangeLabel(){
  if(!ZINKIT_DELIVERY_RESTRICTION_ENABLED) return 'Normal / unrestricted delivery';
  const r=Number(ZINKIT_ACTIVE_STORE_RANGE_KM)||zinkitMaxDeliveryRadiusKm();
  return r>0 ? `${r} km` : 'Not configured';
}
function zinkitUpdateSelectedStoreUI(){
  const el=document.getElementById('zinkitSelectedStoreInfo');
  if(!el)return;
  const sel=document.getElementById('zinkitStoreSelector');
  if(sel && Array.isArray(window.ZINKIT_STORES)){
    const current=String(ZINKIT_ACTIVE_STORE_ID||'');
    sel.innerHTML='<option value="">🏪 Select store</option>'+window.ZINKIT_STORES.map(s=>`<option value="${esc(String(s.id))}">${esc(String(s.name||'ZinKit Store'))}${s.area?' • '+esc(String(s.area)):''}</option>`).join('');
    sel.value=current;
  }
  if(ZINKIT_STORE_MATCH_SOURCE==='multi-store' && ZINKIT_STORE_NAME){
    const area=ZINKIT_ACTIVE_STORE_AREA?` • ${ZINKIT_ACTIVE_STORE_AREA}`:'';
    el.textContent=`🏪 Store: ${ZINKIT_STORE_NAME}${area}`;
  }else if(ZINKIT_STORE_NAME){
    el.textContent=`🏪 Store: ${ZINKIT_STORE_NAME}`;
  }else{
    el.textContent='';
  }
}
function mdMunnaDayKey(){const d=new Date();return "zinkit_orders_"+d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0")}
function mdMunnaTodayOrderCount(){try{return Number(localStorage.getItem(mdMunnaDayKey())||0)}catch(e){return 0}}
function mdMunnaCanProcessOrder(){return mdMunnaTodayOrderCount()<MD_MUNNA_DAILY_ORDER_LIMIT}
function mdMunnaRecordProcessedOrder(){try{localStorage.setItem(mdMunnaDayKey(),String(mdMunnaTodayOrderCount()+1))}catch(e){}}
function mdMunnaShowDailyLimit(){alert("Aaj ke 1,000 orders complete ho gaye hain. Naye orders kal se process honge.")}

;


const LOCAL_BAZAARS=[
  {name:"Lal Bazaar",area:"Local Bazaar"},
  {name:"Doranda Bazaar",area:"Doranda"},
  {name:"Giridih Bazaar",area:"Giridih"},
  {name:"Main Bazaar",area:"Local Market"}
];
let selectedLocalBazaar=localStorage.getItem("zinkit_local_bazaar")||"";
function openLocalBazaarPicker(){
  $("localBazaarPicker").classList.add("show");
  $("localBazaarSearch").value="";
  $("customBazaarName").value="";
  renderLocalBazaars();
}
function closeLocalBazaarPicker(){ $("localBazaarPicker").classList.remove("show"); }
function renderLocalBazaars(){
  const q=($("localBazaarSearch").value||"").trim().toLowerCase();
  const list=LOCAL_BAZAARS.filter(x=>(x.name+" "+x.area).toLowerCase().includes(q));
  $("localBazaarList").innerHTML=list.length?list.map(x=>{
    const selected=selectedLocalBazaar===x.name;
    return `<button type="button" class="localBazaarItem ${selected?'selected':''}" onclick='selectLocalBazaar(${JSON.stringify(x.name)})'>
      <span class="bazaarIcon">📍</span><span><b>${esc(x.name)}</b><small>${esc(x.area)}</small></span>${selected?'<span style="margin-left:auto;color:#16852b;font-weight:900">✓</span>':''}
    </button>`;
  }).join(""):'<div style="padding:18px;text-align:center;color:#777">Bazaar nahi mila. Neeche apna area naam save karein.</div>';
}
function selectLocalBazaar(name){
  selectedLocalBazaar=name;
  localStorage.setItem("zinkit_local_bazaar",name);
  const el=$("topLocationText");
  if(el)el.textContent=name;
  closeLocalBazaarPicker();
}
function saveCustomBazaar(){
  const name=($("customBazaarName").value||"").trim();
  if(!name){alert("Area / Bazaar ka naam likhein.");return;}
  selectLocalBazaar(name);
}
function initLocalBazaar(){
  const el=$("topLocationText");
  if(!el)return;
  if(selectedLocalBazaar){el.textContent=selectedLocalBazaar;return;}
  if(deliveryLocation?.address){
    el.textContent=String(deliveryLocation.address).split(',').slice(0,2).join(', ').trim();
  }else{
    el.textContent='Detecting location…';
  }
}

const SUPABASE_URL="https://fxwwvhfpmggvbnxwocls.supabase.co";
const SUPABASE_KEY="sb_publishable_hGrj4EXH8sv8i36yrC89bg_KBjzvVUp";
const db=window.supabase?.createClient(SUPABASE_URL,SUPABASE_KEY); window.__lqDb=db;
let ZINKIT_CANCEL_SETTINGS={order:true,product:true};
async function zinkitLoadCancelSettings(){
  if(!db)return ZINKIT_CANCEL_SETTINGS;
  try{
    const r=await db.from('app_settings').select('key,value').in('key',['order_cancel_enabled','product_change_cancel_enabled']);
    if(r.error)throw r.error;
    const m=Object.fromEntries((r.data||[]).map(x=>[x.key,String(x.value).toLowerCase()]));
    ZINKIT_CANCEL_SETTINGS={order:m.order_cancel_enabled!=='false',product:m.product_change_cancel_enabled!=='false'};
  }catch(e){console.warn('Cancel settings load failed; keeping safe backwards-compatible defaults.',e?.message||e);}
  return ZINKIT_CANCEL_SETTINGS;
}
window.ZINKIT_SUPABASE_CONNECTION={url:SUPABASE_URL,sharedWithAdmin:true,adminVersion:'V26',customerVersion:'V32'};
let products=[],cart=JSON.parse(localStorage.getItem("mdmunna_cart")||"{}"),orders=JSON.parse(localStorage.getItem("mdmunna_orders")||"[]"),selectedCategory="All";
let zinkitRenderedOrders={};
let deliveryLocation=JSON.parse(localStorage.getItem("zinkit_location")||"null");
const $=id=>document.getElementById(id);
const esc=x=>String(x??"").replace(/[&<>'"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;","\"":"&quot;"}[c]));
function productImage(p){return [p.Image1,p.Image2,p.Image3,p.Image,p.image1,p.image2,p.image3,p.image,p.image_url,p.imageUrl].find(x=>typeof x==='string'&&x.trim())||"";}
function productName(p){return p.Products||p.products||p.name||p.Name||"Product"}
function productBasePrice(p){return Number(p.Price??p.price??0)}
function productStoreDiscountMeta(p){const s=String(p.Description||p.description||'');const m=s.match(/__ZINKIT_STORE_DISCOUNT__:(\{.*?\})(?=\s*__ZINKIT_VARIANTS__|\s*$)/s);if(!m)return {percent:0};try{const x=JSON.parse(m[1])||{},n=Number(x.percent)||0;return {percent:n>0&&n<=100?n:0};}catch(e){return {percent:0};}}
function productStoreDiscount(p,base=productBasePrice(p)){const pct=productStoreDiscountMeta(p).percent;return p.store_id!=null&&pct>0?Math.round(base*(1-pct/100)*100)/100:base;}
function productPrice(p){return productStoreDiscount(p,productBasePrice(p))}
function productDiscountMeta(p){const s=String(p.Description||p.description||'');const m=s.match(/__ZINKIT_DISCOUNT__:(\{.*?\})(?=\s*__ZINKIT_STORE_DISCOUNT__|\s*__ZINKIT_VARIANTS__|\s*$)/s);if(!m)return {originalPrice:null};try{const x=JSON.parse(m[1])||{};return {originalPrice:Number(x.originalPrice)||null};}catch(e){return {originalPrice:null};}}
function productOriginalPrice(p){const legacy=Number(productDiscountMeta(p).originalPrice||0),base=productBasePrice(p);return legacy>base?legacy:(productStoreDiscountMeta(p).percent>0&&p.store_id!=null?base:null)}
function productIsDiscounted(p){const n=productOriginalPrice(p);return n!==null&&n>productPrice(p)}
function productPriceMarkup(p){const price=productPrice(p),original=productOriginalPrice(p);return original&&original>price?`<span style="color:#16852b;font-weight:900">₹${price.toLocaleString('en-IN')}</span> <del style="color:#888;font-size:12px">₹${original.toLocaleString('en-IN')}</del> <span style="color:#b42318;font-size:11px;font-weight:900">${Math.round((original-price)*100/original)}% OFF</span>`:`<span class="price">₹${price.toLocaleString('en-IN')}</span>`}
function productCategory(p){return p.category||p.Category||"Groceries"}
function productId(p){return p.id??p.ID??p.Products}
function save(){localStorage.setItem("mdmunna_cart",JSON.stringify(cart));localStorage.setItem("mdmunna_orders",JSON.stringify(orders));updateCount()}
function updateCount(){const n=Object.values(cart).reduce((a,b)=>a+Number(b),0);$("cartCount").textContent=n;renderFloatingCart()}
function renderFloatingCart(){const bar=$("zinkitFloatingCart");if(!bar)return;const live=$("liveTrackingCard");if(live&&live.classList.contains('show')){bar.classList.remove('show');return;}const items=cartItems();const total=items.reduce((sum,p)=>sum+Number(p.qty||0),0);if(!items.length){bar.classList.remove("show");return;}const thumbs=$("zfcThumbs");thumbs.innerHTML=items.slice(0,2).map(p=>{const img=productImage(p);return img?`<img class="zfcThumb" src="${esc(img)}" alt="" onerror="this.style.display='none'">`:`<div class="zfcMore">🛍️</div>`}).join("");if(items.length>2)thumbs.innerHTML+=`<div class="zfcMore">+${items.length-2}</div>`;$("zfcCount").textContent=`${total} ${total===1?'Item':'Items'}`;bar.classList.toggle("show",!document.querySelector('.screen.show#cartScreen, .screen.show#checkoutScreen'));}
function openFloatingCart(){showScreen("cart");window.scrollTo(0,0)}

let zFoodCustomerRestaurants=[],zFoodCustomerCategories=[],zFoodCustomerItems=[],zFoodCustomerRestaurant=null,zFoodCart={};
function zfcEsc(v){return esc(v==null?'':String(v));}
function zfcCategory(){return selectedCategory||'Biryani';}
async function loadFoodRestaurants(category){
  const title=category||'Biryani';
  $('foodScreenTitle').textContent='🍛 '+title;
  $('foodScreenSub').textContent='Hotels serving '+title+' near your selected store';
  if(!db)return;
  let q=category==='Hotel'?'':category;
  let selectedId=ZINKIT_ACTIVE_STORE_ID==null?'':String(ZINKIT_ACTIVE_STORE_ID).trim();
  // Always refresh stores before food lookup so a newly-created/selected store is used.
  try{ await zinkitLoadDeliverySettings(); zinkitUpdateSelectedStoreUI(); selectedId=ZINKIT_ACTIVE_STORE_ID==null?'':String(ZINKIT_ACTIVE_STORE_ID).trim(); }catch(e){}
  let r;
  if(selectedId){
    r=await db.from('restaurants').select('*').eq('active',true).eq('store_id',selectedId).order('created_at',{ascending:false});
    // Avoid a blank Customer screen when the selected delivery store differs
    // from the Store ID assigned to the hotel in Admin. Try all active hotels.
    if(!r.error && (!Array.isArray(r.data) || r.data.length===0)){
      const fallback=await db.from('restaurants').select('*').eq('active',true).order('created_at',{ascending:false});
      if(!fallback.error && Array.isArray(fallback.data) && fallback.data.length) r=fallback;
    }
  }else{
    r=await db.from('restaurants').select('*').eq('active',true).order('created_at',{ascending:false});
  }
  if(r.error){$('foodRestaurants').innerHTML='<div class="empty">Hotels load error: '+zfcEsc(r.error.message)+'</div>';return;}
  let rows=r.data||[];
  // Hotel listing must show all active hotels; category/name matching should
  // only filter when it finds matches, never hide every hotel by accident.
  if(q){
    const rr=await db.from('food_items').select('restaurant_id').eq('active',true).ilike('name','%'+q+'%');
    if(!rr.error){const ids=new Set((rr.data||[]).map(x=>String(x.restaurant_id)));if(ids.size){const matched=rows.filter(x=>ids.has(String(x.id)));if(matched.length) rows=matched;}}
  }
  zFoodCustomerRestaurants=rows;$('foodRestaurants').innerHTML=rows.length?rows.map(r=>`<div class="card" style="margin-bottom:12px;padding:12px" onclick="openCustomerRestaurant(${r.id})"><div style="display:flex;gap:12px;align-items:center"><img src="${zfcEsc(r.logo_url||'')}" style="width:78px;height:78px;border-radius:14px;object-fit:cover;background:#f3f4f6" onerror="this.style.display='none'"><div style="flex:1"><h3 style="margin:0 0 5px;font-size:17px">🏨 ${zfcEsc(r.name)}</h3><div style="font-size:12px;color:#6b7280">⭐ 4.5 • 25–35 min</div><div style="font-size:12px;color:#6b7280;margin-top:4px">📍 ${zfcEsc(r.address||r.store_id?'Nearby':'Nearby')}</div><div style="font-size:12px;color:#16852b;font-weight:800;margin-top:5px">🚚 ₹${Number(r.delivery_charge||0)} delivery • Min ₹${Number(r.min_order||0)}</div></div></div></div>`).join(''):'<div class="empty" style="margin-top:20px">🏨 Is store mein abhi hotels available nahi hain.</div>'}
async function openCustomerRestaurant(id){const r=zFoodCustomerRestaurants.find(x=>String(x.id)===String(id));if(!r)return;zFoodCustomerRestaurant=r;showScreen('restaurant');$('restaurantHero').innerHTML=`<div class="card" style="padding:12px"><div style="display:flex;gap:12px;align-items:center"><img src="${zfcEsc(r.logo_url||'')}" style="width:88px;height:88px;border-radius:15px;object-fit:cover;background:#f3f4f6" onerror="this.style.display='none'"><div><h2 style="margin:0 0 5px">🏨 ${zfcEsc(r.name)}</h2><div style="font-size:12px;color:#6b7280">⭐ 4.5 • 25–35 min</div><div style="font-size:12px;color:#6b7280">📍 ${zfcEsc(r.address||'')}</div><div style="font-size:12px;color:#16852b;font-weight:800;margin-top:5px">🚚 ₹${Number(r.delivery_charge||0)} delivery • Min ₹${Number(r.min_order||0)}</div></div></div></div>`;$('restaurantMenu').innerHTML='<div class="empty" style="margin-top:20px">Menu load ho raha hai…</div>';try{const [cr,ir]=await Promise.all([db.from('food_categories').select('*').eq('restaurant_id',r.id).eq('active',true).order('sort_order').order('id'),db.from('food_items').select('*').eq('restaurant_id',r.id).eq('active',true).order('sort_order').order('id')]);if(cr.error)throw new Error('Food categories: '+cr.error.message);if(ir.error)throw new Error('Food items: '+ir.error.message);zFoodCustomerCategories=cr.data||[];zFoodCustomerItems=ir.data||[];renderCustomerRestaurantMenu();if(!zFoodCustomerCategories.length)$('restaurantMenu').innerHTML='<div class="empty" style="margin-top:20px">Is hotel ki active menu category nahi mili. Admin App → Hotels/Food → Menu mein category add karein aur Active rakhein.</div>';else if(!zFoodCustomerItems.length)$('restaurantMenu').innerHTML='<div class="empty" style="margin-top:20px">Is hotel mein active food items nahi mile. Admin App mein item ko Active aur Available karke Save karein.</div>';}catch(err){$('restaurantMenu').innerHTML='<div class="empty" style="margin-top:20px;color:#b91c1c">Menu load error: '+zfcEsc(err.message||err)+'<br>Supabase RLS policies aur restaurant_id check karein.</div>';}}
function renderCustomerRestaurantMenu(){const cats=zFoodCustomerCategories;const items=zFoodCustomerItems;$('restaurantMenu').innerHTML=(cats.length?cats.map(cat=>{const list=items.filter(i=>String(i.category_id)===String(cat.id));if(!list.length)return '';return `<div style="margin-top:18px"><h3 style="margin:0 0 10px">${zfcEsc(cat.name)}</h3>${list.map(i=>`<div class="card" style="margin-bottom:9px;padding:10px;display:flex;gap:10px;align-items:center"><img src="${zfcEsc(i.image_url||'')}" style="width:76px;height:76px;border-radius:12px;object-fit:cover;background:#f5f5f5" onerror="this.style.display='none'"><div style="flex:1"><b style="font-size:15px">${zfcEsc(i.name)}</b><div style="font-size:11px;color:#6b7280;margin:3px 0">${zfcEsc(i.description||'')}</div><div style="font-size:12px;color:#6b7280">${i.veg_nonveg==='veg'?'🟢 Veg':'🔴 Non-Veg'} • ${i.available?'Available':'Out of stock'}</div><div class="row" style="margin-top:5px"><b style="font-size:17px">₹${Number(i.price||0).toLocaleString('en-IN')}</b><button type="button" ${i.available?'':'disabled'} onclick="event.stopPropagation();openFoodItemCustomisation(${i.id})">${i.available?'ADD':'OUT OF STOCK'}</button></div></div></div>`).join('')}</div>`}).join(''):'<div class="empty" style="margin-top:20px">Is hotel ka menu abhi add nahi hua.</div>');}
async function openFoodItemCustomisation(id){const i=zFoodCustomerItems.find(x=>String(x.id)===String(id));if(!i||!i.available)return;const variants=await db.from('food_variants').select('*').eq('food_item_id',id).eq('active',true).order('id');const addons=await db.from('food_addons').select('*').eq('food_item_id',id).eq('active',true).order('id');const v=variants.data||[],a=addons.data||[];let variant=v[0]||null;let selectedAddons=[];let qty=1;const html=`<div class="variantSheet"><div class="variantHead"><h3 style="margin:0">${zfcEsc(i.name)}</h3><button class="secondary" onclick="closeVariantModal()">✕</button></div><div style="font-size:13px;color:#666;margin:8px 0">₹${Number(i.price||0)}</div>${v.length?'<b>Choose size</b><div style="display:grid;gap:7px;margin:8px 0">'+v.map((x,n)=>`<label><input type="radio" name="foodVar" ${n===0?'checked':''} onchange="window._zFoodVar=${x.id};window._zFoodVarPrice=${Number(x.price||0)}"> ${zfcEsc(x.name)} — ₹${Number(x.price||0)}</label>`).join('')+'</div>':''}${a.length?'<b>Add-ons / Extras</b><div style="display:grid;gap:7px;margin:8px 0">'+a.map(x=>`<label><input type="checkbox" value="${x.id}" data-price="${x.price}" data-name="${zfcEsc(x.name)}"> ${zfcEsc(x.name)} +₹${Number(x.price||0)}</label>`).join('')+'</div>':''}<div class="qty" style="margin:12px 0"><button onclick="this.nextElementSibling.textContent=Math.max(1,Number(this.nextElementSibling.textContent)-1)">−</button><span>1</span><button onclick="this.previousElementSibling.textContent=Number(this.previousElementSibling.textContent)+1">+</button></div><button style="width:100%" onclick="addFoodToCart(${i.id})">Add to Cart</button></div>`;let m=document.getElementById('zFoodCustomModal');if(!m){m=document.createElement('div');m.id='zFoodCustomModal';m.className='variantModal';document.body.appendChild(m);}m.innerHTML=html;m.classList.add('show');window._zFoodVar=v[0]?.id||null;window._zFoodVarPrice=v[0]?Number(v[0].price||0):Number(i.price||0);}
function addFoodToCart(id){const i=zFoodCustomerItems.find(x=>String(x.id)===String(id));const modal=$('zFoodCustomModal');if(!i||!modal)return;const qty=Math.max(1,Number(modal.querySelector('.qty span')?.textContent||1));const variantId=window._zFoodVar||'';const variant=zFoodCustomerItems;const checked=[...modal.querySelectorAll('input[type=checkbox]:checked')];const addonIds=checked.map(x=>x.value).sort();const key=`${id}__${variantId}__${addonIds.join(',')}`;const existing=zFoodCart[key]||{item:i,qty:0,variantId,variantPrice:Number(window._zFoodVarPrice||i.price||0),addonIds,addons:checked.map(x=>({id:x.value,name:x.dataset.name,price:Number(x.dataset.price)||0}))};existing.qty+=qty;zFoodCart[key]=existing;modal.classList.remove('show');renderCart();alert('✅ '+i.name+' cart mein add ho gaya');}
function closeVariantModal(){const m=$('zFoodCustomModal');if(m)m.classList.remove('show');}
let zinkitBrowseSelectedMain='All';
function zinkitBrowseNormalize(v){return String(v||'').trim().toLowerCase().replace(/\s+/g,' ');}
function zinkitBrowseIcon(name){const n=zinkitBrowseNormalize(name);const icons={'all':'🛒','fresh':'🥬','fashion':'👕','men':'👔','women':'👗','accessories':'👜','innerwear':'🩲','footwear':'👟','kids':'🧒','jewellery':'💍','mobiles':'📱','pharmacy':'💊','price drop':'🏷️','ayush store':'🌿','t-shirt':'👕','t shirt':'👕','shirt':'👔','jeans':'👖','pant':'👖','trousers':'👖','saree':'🥻','kurti':'👗','dress':'👗','tops':'👚','leggings':'👖','bags':'👜','watches':'⌚','watch':'⌚','belts':'🪢','belt':'🪢','shoes':'👟','sandals':'🩴','slippers':'🩴','earrings':'💎','necklaces':'📿','rings':'💍','bangles':'💫','vests':'👕','briefs':'🩲','boxers':'🩳'};if(icons[n])return icons[n];for(const k of Object.keys(icons))if(n.includes(k))return icons[k];return '📦';}
function zinkitBrowseData(){
 const source=Array.isArray(zinkitDynamicCategories)&&zinkitDynamicCategories.length?zinkitDynamicCategories:[['All','🛒']];
 const all=source.map(x=>({name:String(x&&x[0]||'').trim(),icon:String(x&&x[1]||'📦')})).filter(x=>x.name);
 const byKey=new Map(all.map(x=>[zinkitBrowseNormalize(x.name),x]));
 const parents=['Men','Women','Accessories','Innerwear','Footwear','Kids','Jewellery'];
 // Create navigable parent rows when Admin categories only contain entries such as “Men - Shirt”.
 all.forEach(x=>{const m=x.name.match(/^(.+?)\s*[-:|]\s*(.+)$/);if(m){const parent=m[1].trim();if(!byKey.has(zinkitBrowseNormalize(parent))){const p={name:parent,icon:zinkitBrowseIcon(parent),synthetic:true};byKey.set(zinkitBrowseNormalize(parent),p);}}});
 let main=Array.from(byKey.values()).filter(x=>!/^(.+?)\s*[-:|]\s*(.+)$/.test(x.name));
 // Keep All first, then preserve Admin ordering for all configured main categories.
 main.sort((a,b)=>{if(zinkitBrowseNormalize(a.name)==='all')return -1;if(zinkitBrowseNormalize(b.name)==='all')return 1;const ia=all.findIndex(x=>zinkitBrowseNormalize(x.name)===zinkitBrowseNormalize(a.name));const ib=all.findIndex(x=>zinkitBrowseNormalize(x.name)===zinkitBrowseNormalize(b.name));return (ia<0?9999:ia)-(ib<0?9999:ib);});
 // A Fashion parent opens fashion departments that exist in this catalogue.
 const fashion=main.find(x=>zinkitBrowseNormalize(x.name)==='fashion');
 if(fashion){const departments=parents.map(n=>byKey.get(zinkitBrowseNormalize(n))).filter(Boolean);fashion.children=departments;}
 main=main.map(parent=>{let children=all.filter(x=>{const m=x.name.match(/^(.+?)\s*[-:|]\s*(.+)$/);return m&&zinkitBrowseNormalize(m[1])===zinkitBrowseNormalize(parent.name);}).map(x=>({name:x.name.replace(/^.+?\s*[-:|]\s*/,''),fullName:x.name,icon:x.icon}));if(zinkitBrowseNormalize(parent.name)==='fashion'&&parent.children?.length)children=parent.children.map(x=>({name:x.name,fullName:x.name,icon:x.icon}));return {...parent,children};});
 return main;
}
function renderCategoriesBrowseGrid(){
 const target=document.getElementById('categoriesBrowseGrid');if(!target)return;
 const data=zinkitBrowseData();if(!data.length)return;
 if(!data.some(x=>zinkitBrowseNormalize(x.name)===zinkitBrowseNormalize(zinkitBrowseSelectedMain)))zinkitBrowseSelectedMain=data[0].name;
 let active=data.find(x=>zinkitBrowseNormalize(x.name)===zinkitBrowseNormalize(zinkitBrowseSelectedMain))||data[0];
 target.replaceChildren();
 const mainList=document.createElement('div');mainList.className='zcat-main-list';mainList.setAttribute('aria-label','Main categories');
 data.forEach(item=>{const btn=document.createElement('button');btn.type='button';btn.className='zcat-main'+(zinkitBrowseNormalize(item.name)===zinkitBrowseNormalize(active.name)?' active':'');btn.setAttribute('aria-label','Show '+item.name+' subcategories');const emoji=document.createElement('span');emoji.className='zcat-emoji';emoji.textContent=item.icon||zinkitBrowseIcon(item.name);const label=document.createElement('span');label.textContent=item.name;btn.append(emoji,label);btn.addEventListener('click',()=>{zinkitBrowseSelectedMain=item.name;selectedCategory=item.name;selectedBrandFilter='';renderCategoriesBrowseGrid();});mainList.appendChild(btn);});
 const subList=document.createElement('div');subList.className='zcat-sub-list';subList.setAttribute('aria-label',active.name+' subcategories');
 const children=active.children&&active.children.length?active.children:zinkitBrowseChildren(active.name);
 const heading=document.createElement('h3');heading.className='zcat-heading';heading.textContent=active.name==='All'?'All Categories':active.name;subList.appendChild(heading);
 if(children.length){children.forEach(child=>{const btn=document.createElement('button');btn.type='button';btn.className='zcat-sub';btn.setAttribute('aria-label','Open '+child.name);const em=document.createElement('span');em.className='zcat-sub-emoji';em.textContent=child.icon||zinkitBrowseIcon(child.name);const label=document.createElement('span');label.textContent=child.name;btn.append(em,label);btn.addEventListener('click',()=>openCategoryFromBrowse(child.fullName||child.name));subList.appendChild(btn);});}
 else if(zinkitBrowseNormalize(active.name)==='all'){
   data.filter(x=>zinkitBrowseNormalize(x.name)!=='all').forEach(child=>{const btn=document.createElement('button');btn.type='button';btn.className='zcat-sub';const em=document.createElement('span');em.className='zcat-sub-emoji';em.textContent=child.icon||zinkitBrowseIcon(child.name);const label=document.createElement('span');label.textContent=child.name;btn.append(em,label);btn.addEventListener('click',()=>{zinkitBrowseSelectedMain=child.name;renderCategoriesBrowseGrid();if(!(child.children&&child.children.length)&&!zinkitBrowseChildren(child.name).length)openCategoryFromBrowse(child.name);});subList.appendChild(btn);});
 } else {const empty=document.createElement('div');empty.className='zcat-empty';empty.textContent='Is category ke products dekhne ke liye yahan tap karein.';empty.addEventListener('click',()=>openCategoryFromBrowse(active.name));subList.appendChild(empty);}
 target.append(mainList,subList);
}
function zinkitBrowseChildren(parentName){const source=Array.isArray(zinkitDynamicCategories)?zinkitDynamicCategories:[];const p=zinkitBrowseNormalize(parentName);return source.map(x=>({name:String(x&&x[0]||'').trim(),icon:String(x&&x[1]||'📦')})).filter(x=>{const m=x.name.match(/^(.+?)\s*[-:|]\s*(.+)$/);return m&&zinkitBrowseNormalize(m[1])===p;}).map(x=>({name:x.name.replace(/^.+?\s*[-:|]\s*/,''),fullName:x.name,icon:x.icon}));}
async function openCategoryFromBrowse(name){
 const category=String(name||'All').trim()||'All';
 const key=category.toLowerCase();
 if(['biryani','hotel','restaurant','food'].includes(key)){selectedCategory=category;selectedBrandFilter='';showScreen('food');if(typeof loadFoodRestaurants==='function')await loadFoodRestaurants(category);return;}
 selectedCategory=category;selectedBrandFilter='';
 try{if(typeof loadProducts==='function')await loadProducts();}catch(e){console.warn('Category product refresh failed:',e&&e.message||e);}
 showScreen('home');renderCategories();renderProducts();setTimeout(()=>{const productsBox=document.getElementById('products');if(productsBox)productsBox.scrollIntoView({behavior:'smooth',block:'start'});},80);
}
function openHomeCategories(){
  renderCategories();
  renderCategoriesBrowseGrid();
  showScreen('categories');
  window.scrollTo({top:0,behavior:'auto'});
}
function showScreen(name){if(name==='categories')renderCategoriesBrowseGrid();const screens=["home","categories","cart","checkout","orders","profile","payment","productDetail","help","food","restaurant"];screens.forEach(s=>$(s+"Screen").classList.toggle("show",s===name));["Home","Categories","Cart","Orders","Profile"].forEach(x=>{const e=$("nav"+x);if(e)e.classList.remove("activeNav")});const map={home:"navHome",categories:"navCategories",cart:"navCart",orders:"navOrders",profile:"navProfile",help:"navProfile",food:"navHome",restaurant:"navHome"};if(map[name])$(map[name]).classList.add("activeNav");if(name==='cart')renderCart();if(name==='food')loadFoodRestaurants(selectedCategory||'Biryani');if(name==='orders')renderOrders();if(name==='profile')refreshProfile();if(name==='payment'){const pay=localStorage.getItem('zinkit_payment')||'COD';setTimeout(()=>selectPaymentSetting(pay,false),0)}renderFloatingCart();/* keep current scroll position */}
function closeSearchSuggestions(){const box=document.getElementById('searchSuggestions');if(box)box.style.display='none';}
function zinkitSearchNormalize(value){return String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();}
function zinkitEditDistance(a,b){if(a===b)return 0;if(Math.abs(a.length-b.length)>2)return 3;let prev=Array.from({length:b.length+1},(_,i)=>i);for(let i=1;i<=a.length;i++){const cur=[i];let rowMin=i;for(let j=1;j<=b.length;j++){const v=Math.min(cur[j-1]+1,prev[j]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));cur[j]=v;if(v<rowMin)rowMin=v;}if(rowMin>2)return 3;prev=cur;}return prev[b.length];}
function zinkitProductSearchFields(p){return [productName(p),productCategory(p),p.brand,p.Brand,p.description,p.Description,p.variant,p.Variant,p.size,p.Size,p.color,p.colour,p.gender,p.department,p.subcategory,p.sub_category,p.product_type,p.type,p.tags,p.search_keywords].flatMap(v=>Array.isArray(v)?v:[v]).map(v=>String(v||'').trim()).filter(Boolean);}
function zinkitSearchScore(value,query){const q=zinkitSearchNormalize(query),v=zinkitSearchNormalize(value);if(!q||!v)return -1;if(v===q)return 100;if(v.startsWith(q))return 90;if(v.includes(q))return 80;const qs=q.split(' ').filter(Boolean),vs=v.split(' ').filter(Boolean);let total=0;for(const qt of qs){let best=3;for(const vt of vs){if(vt===qt){best=0;break;}if(vt.startsWith(qt)||qt.startsWith(vt)){best=Math.min(best,1);continue;}if(Math.min(qt.length,vt.length)>=3)best=Math.min(best,zinkitEditDistance(qt,vt));}if(best>2)return -1;total+=best;}return 50-total;}
function zinkitProductMatchesSearch(p,query){const q=zinkitSearchNormalize(query);if(!q)return true;return zinkitProductSearchFields(p).some(v=>zinkitSearchScore(v,q)>=0)||zinkitSearchScore(zinkitProductSearchFields(p).join(' '),q)>=0;}
function chooseSearchSuggestion(value){const input=document.getElementById('search');if(!input)return;input.value=value;closeSearchSuggestions();renderProducts();input.blur();}
function handleCustomerSearch(){
  const input=document.getElementById('search');if(!input)return;
  renderProducts();
  const box=document.getElementById('searchSuggestions');if(!box)return;
  const q=input.value.trim();
  if(!q){box.style.display='none';box.innerHTML='';return;}
  const values=new Map();
  (Array.isArray(products)?products:[]).forEach(p=>zinkitProductSearchFields(p).forEach(v=>{const value=String(v||'').trim();if(!value)return;const score=zinkitSearchScore(value,q);if(score>=0){const key=zinkitSearchNormalize(value);if(!values.has(key)||values.get(key).score<score)values.set(key,{value,score});}}));
  const matches=[...values.values()].sort((a,b)=>b.score-a.score).slice(0,7);
  box.innerHTML='';
  if(!matches.length){box.innerHTML='<div class="searchHint">No exact match. Spelling check karein ya category/brand try karein.</div>';box.style.display='block';return;}
  const hint=document.createElement('div');hint.className='searchHint';hint.textContent='Fast Search · Product, Category, Brand';box.appendChild(hint);
  matches.forEach(({value})=>{const row=document.createElement('div');row.className='searchSuggestion';row.setAttribute('role','option');const ico=document.createElement('span');ico.className='sIcon';ico.textContent='⌕';const label=document.createElement('span');label.textContent=value;label.style.flex='1';const arrow=document.createElement('span');arrow.textContent='↗';arrow.style.color='#16852b';row.append(ico,label,arrow);row.addEventListener('click',()=>chooseSearchSuggestion(value));box.appendChild(row);});
  box.style.display='block';
}
document.addEventListener('click',function(e){const h=document.querySelector('header');if(h&&!h.contains(e.target))closeSearchSuggestions();});
function startVoiceSearch(){
  const input=document.getElementById('search');
  const btn=document.getElementById('voiceSearchBtn');
  const SpeechRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SpeechRecognition){alert('Voice Search is not supported in this browser. iPhone par Safari/Chrome ka updated version ya supported browser mein try karein.');return;}
  try{
    closeSearchSuggestions();
    const recognition=new SpeechRecognition();
    recognition.lang='hi-IN';
    recognition.interimResults=false;
    recognition.maxAlternatives=3;
    if('processLocally' in recognition)recognition.processLocally=false;
    btn.classList.add('listening');
    btn.textContent='🔴';
    recognition.onresult=function(event){
      const transcript=event.results&&event.results[0]&&event.results[0][0]?event.results[0][0].transcript:'';
      if(transcript){input.value=transcript;handleCustomerSearch();closeSearchSuggestions();renderProducts();}
    };
    recognition.onerror=function(event){if(event.error!=='no-speech'&&event.error!=='aborted')alert('Voice search error: '+event.error+'. Microphone permission check karein.');};
    recognition.onend=function(){btn.classList.remove('listening');btn.textContent='🎙️';};
    recognition.start();
  }catch(e){btn.classList.remove('listening');btn.textContent='🎙️';alert('Voice search start nahi hua. Microphone permission allow karein.');}
}
function focusSearch(){showScreen("home");setTimeout(()=>$("search").focus(),80)}
function refreshProfile(){const phone=(localStorage.getItem('zinkit_customer_mobile')||'').replace(/\D/g,'').slice(-10);const name=localStorage.getItem('zinkit_customer_name')||'Customer';$('profileName').textContent=name;$('profilePhone').textContent=phone?'+91 '+phone:'Mobile number';$('profileAddress').textContent=deliveryLocation?.address||localStorage.getItem('zinkit_customer_address')||'Add your delivery address';const pay=localStorage.getItem('zinkit_payment')||'COD';$('paymentSummary').textContent=pay==='Online'?'Online Payment (UPI / Card)':'Cash on Delivery';}
function editCustomerProfile(){const current=localStorage.getItem('zinkit_customer_name')||'';const name=prompt('Customer name',current);if(name===null)return;if(name.trim())localStorage.setItem('zinkit_customer_name',name.trim());refreshProfile()}
function openPaymentSettings(){showScreen('payment');const pay=localStorage.getItem('zinkit_payment')||'COD';selectPaymentSetting(pay,false)}
function selectPaymentSetting(value,goBack=true){localStorage.setItem('zinkit_payment',value);$('payCod').classList.toggle('selected',value==='COD');$('payOnline').classList.toggle('selected',value==='Online');refreshProfile();if(goBack){setTimeout(()=>showScreen('profile'),120)}}
let zinkitDynamicCategories=[];
function mergeZinKitCategories(base,extra){const out=[],seen=new Set();for(const item of [...(base||[]),...(extra||[])]){if(!item||!item[0])continue;const key=String(item[0]).trim().toLowerCase();if(!key||seen.has(key))continue;seen.add(key);out.push([String(item[0]).trim(),String(item[1]||'📦')]);}return out;}
async function loadDynamicCategories(){
  const fallback=[['All','🛒']];
  try{
    let r=await db.from('app_settings').select('value').eq('key','product_categories').maybeSingle();
    if(!r.error && r.data && r.data.value!=null){
      let rows=typeof r.data.value==='string'?JSON.parse(r.data.value):r.data.value;
      if(Array.isArray(rows)){
        zinkitDynamicCategories=mergeZinKitCategories([['All','🛒']],rows.filter(x=>x&&x.active!==false&&String(x.name||'').trim()&&String(x.name).toLowerCase()!=='all').sort((a,b)=>(Number(a.sort_order)||0)-(Number(b.sort_order)||0)).map(x=>[String(x.name),String(x.icon||'📦')]));
        renderCategories();return;
      }
    }
    r=await db.from('product_categories').select('name,icon,sort_order,active').eq('active',true).order('sort_order').order('id');
    if(!r.error&&Array.isArray(r.data))zinkitDynamicCategories=mergeZinKitCategories([['All','🛒']],r.data.filter(x=>x.active!==false&&String(x.name||'').toLowerCase()!=='all').map(x=>[String(x.name),String(x.icon||'📦')]));
    else zinkitDynamicCategories=fallback;
  }catch(e){zinkitDynamicCategories=fallback;console.warn('Dynamic categories load failed:',e.message||e);}
  renderCategories();
}
function renderCategories(){
  const cats=Array.isArray(zinkitDynamicCategories)?zinkitDynamicCategories:[['All','🛍️']];
  const visibleCats=cats.length?cats:[['All','🛍️']];
  if(selectedCategory && !visibleCats.some(x=>String(x[0]).toLowerCase()===String(selectedCategory).toLowerCase()))selectedCategory='All';
  const box=$('categories');if(!box)return;
  box.innerHTML=visibleCats.map(([name,icon])=>`<div role="button" tabindex="0" class="cat ${String(selectedCategory).toLowerCase()===String(name).toLowerCase()?'active':''}" onclick="selectCategory(decodeURIComponent('${encodeURIComponent(String(name))}'))" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();selectCategory(decodeURIComponent('${encodeURIComponent(String(name))}'))}"><div class="emoji">${esc(icon)}</div><small>${esc(name)}</small></div>`).join('');
  const browse=document.getElementById('categoriesScreen');
  if(browse&&browse.classList.contains('show'))renderCategoriesBrowseGrid();
}
let zinkitBrands=[];let selectedBrandFilter='';
function zinkitBrandEsc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
async function loadCustomerBrands(){
  const section=$('customerBrandsSection'),box=$('customerBrands');if(!section||!box||!db)return;
  try{
    const storeId=ZINKIT_ACTIVE_STORE_ID==null?'':String(ZINKIT_ACTIVE_STORE_ID).trim();
    let q=db.from('brands').select('id,name,logo_url,description,store_id,active').eq('active',true).order('name').limit(200);
    if(storeId)q=q.or(`store_id.eq.${storeId},store_id.is.null`);else q=q.is('store_id',null);
    const r=await q;if(r.error)throw r.error;zinkitBrands=r.data||[];
    if(!zinkitBrands.length){section.style.display='none';return;}section.style.display='block';
    box.innerHTML=zinkitBrands.map(b=>`<button type="button" onclick="selectBrandFilter(${JSON.stringify(String(b.name))})" style="flex:0 0 86px;width:86px;border:1px solid ${selectedBrandFilter===b.name?'#7c3aed':'#e5e7eb'};border-radius:12px;background:${selectedBrandFilter===b.name?'#f5f3ff':'white'};padding:8px 6px;color:#222;display:flex;flex-direction:column;align-items:center;gap:5px"><span style="width:48px;height:48px;display:flex;align-items:center;justify-content:center;background:#f8fafc;border-radius:10px;overflow:hidden">${b.logo_url?`<img src="${zinkitBrandEsc(b.logo_url)}" alt="" style="width:100%;height:100%;object-fit:contain" onerror="this.style.display='none'">`:'🏷️'}</span><span style="font-size:11px;font-weight:700;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${zinkitBrandEsc(b.name)}</span></button>`).join('');
  }catch(e){section.style.display='none';console.warn('Brand list load failed:',e.message||e);}
}
function selectBrandFilter(name){selectedBrandFilter=String(name||'').trim();selectedCategory='All';renderCategories();renderProducts();loadCustomerBrands();const list=$('products');if(list){list.scrollIntoView({behavior:'smooth',block:'start'});}}
function clearBrandFilter(){selectedBrandFilter='';selectedCategory='All';renderCategories();renderProducts();loadCustomerBrands();}

function categoryMatches(selected,cat,p){
 const rawSelected=String(selected||'All').trim(), s=rawSelected.toLowerCase();
 const fields=[cat,p&&p.subcategory,p&&p.sub_category,p&&p.subCategory,p&&p.department,p&&p.product_type,p&&p.type,p&&p.category_path,p&&p.CategoryPath,p&&p.tags]
   .flatMap(v=>Array.isArray(v)?v:[v]).map(v=>String(v||'').trim()).filter(Boolean);
 const norm=v=>String(v||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,' ').trim();
 const selectedNorm=norm(rawSelected);
 const cats=fields.map(norm).filter(Boolean);
 if(!selectedNorm||selectedNorm==='all')return true;
 if(selectedNorm==='price drop')return productIsDiscounted(p);
 const aliases={
   'fresh':['fresh','fruits vegetables','fruits and vegetables','dairy eggs','snacks beverages','grocery','groceries','produce'],
   'fashion':['fashion','clothing','cloth','apparel','men','mens','women','womens','accessories','innerwear','footwear','kids','jewellery','jewelry'],
   'men':['men','mens','male','gents'], 'women':['women','womens','female','ladies'],
   'kids':['kids','kid','children','child','baby','infant'],
   'accessories':['accessories','accessory','bags','bag','watches','watch','belts','belt','sunglasses'],
   'innerwear':['innerwear','underwear','lingerie','vests','briefs','boxers','bras','panties'],
   'footwear':['footwear','shoes','shoe','sandals','slippers','sneakers'],
   'jewellery':['jewellery','jewelry','ornaments','earrings','necklaces','rings','bangles'],
   'mobiles':['mobiles','mobile','phone','phones','electronics','electronic','computer','laptop'],
   'pharmacy':['pharmacy','medicine','medical','healthcare','tablet','first aid'],
   'fruits vegetables':['fruits vegetables','fruit','fruits','vegetable','vegetables','produce'],
   'dairy eggs':['dairy eggs','dairy','milk','eggs','egg'],
   'snacks beverages':['snacks beverages','snacks','snack','beverages','beverage','drinks','drink'],
   'mobile electronics':['mobile electronics','mobile','mobiles','electronics','electronic','phone','computer','laptop'],
   'beauty cosmetics jewellery':['beauty','cosmetics','cosmetic','jewellery','jewelry','makeup','skincare'],
   'cloth':['cloth','clothing','fashion','apparel'],
   'oil ghee masala':['oil','ghee','masala','spice','spices'],
   'bakery biscuits':['bakery','biscuit','biscuits','bread','cake'],
   'chips chocolate ice cream':['chips','chip','chocolate','ice cream','icecream','frozen'],
   'atta rice dal':['atta','rice','dal','flour'],
   'personal care':['personal care','personal'],
   'tea coffee dry fruit seeds':['tea','coffee','dry fruit','dryfruit','seeds','seed'],
   'grocery':['grocery','groceries']
 };
 const parts=selectedNorm.split(' ');
 // A full path such as "men shirt" matches only that path or a child path, never a product name.
 const exactOrChild=field=>field===selectedNorm||field.startsWith(selectedNorm+' ');
 if(cats.some(exactOrChild))return true;
 // A parent department can contain its own direct category and explicitly prefixed subcategories.
 if(['men','women','kids','accessories','innerwear','footwear','jewellery'].includes(selectedNorm)){
   const aliasesForParent=aliases[selectedNorm]||[selectedNorm];
   return cats.some(field=>aliasesForParent.some(a=>field===norm(a)||field.startsWith(norm(a)+' ')));
 }
 // Known broad categories use category metadata only, not product-name guesses.
 const broad=aliases[selectedNorm];
 if(broad)return cats.some(field=>broad.some(a=>{const na=norm(a);return field===na||field.startsWith(na+' ')||field.split(' ').includes(na);}));
 // If an admin category is "Men - Shirt", allow the subcategory button "Shirt" to match
 // the final category segment only. Do not match unrelated products merely by their names.
 if(parts.length===1)return cats.some(field=>field.split(' ').includes(selectedNorm));
 return false;
}
function openFashionDepartment(parent){
 const map={
  'Store':['All Fashion'],
  'Men':['T-Shirt','Shirt','Jeans','Pant'],
  'Women':['Saree','Kurti','Dress','Tops','Jeans','Leggings'],
  'Accessories':['Bags','Watches','Belts','Sunglasses'],
  'Innerwear':['Vests','Briefs','Boxers','Bras','Panties'],
  'Footwear':['Shoes','Sandals','Slippers','Sneakers'],
  'Kids':['T-Shirts','Shirts','Dresses','Jeans','Kids Footwear'],
  'Jewellery':['Earrings','Necklaces','Rings','Bangles']
 };
 const panel=document.getElementById('fashionSubcategoryPanel'),title=document.getElementById('fashionSubcategoryTitle'),opts=document.getElementById('fashionSubcategoryOptions');
 if(!panel||!opts){selectCategory(parent);document.getElementById('products').scrollIntoView({behavior:'smooth'});return;}
 title.textContent='Shop '+parent+' by type';
 const items=map[parent]||[];
 opts.innerHTML=items.map(label=>`<button type="button" onclick="selectFashionSubcategory(${JSON.stringify(parent)},${JSON.stringify(label)})">${esc(label)}</button>`).join('');
 panel.style.display='block';
 if(parent==='Store'){selectCategory('Fashion');document.getElementById('products').scrollIntoView({behavior:'smooth'});}
 else panel.scrollIntoView({behavior:'smooth',block:'nearest'});
}
function selectFashionSubcategory(parent,label){
 selectedCategory=(parent==='Store'?'Fashion':parent+' - '+label);
 const panel=document.getElementById('fashionSubcategoryPanel');
 if(panel)document.getElementById('fashionSubcategoryTitle').textContent=parent+' • '+label;
 renderCategories();renderProducts();
 const productsBox=document.getElementById('products');if(productsBox)productsBox.scrollIntoView({behavior:'smooth',block:'start'});
}

function selectCategory(c){const category=String(c||'All').trim()||'All';selectedCategory=category;selectedBrandFilter='';const foodCategory=category.toLowerCase();if(['biryani','hotel','restaurant','food'].includes(foodCategory)){showScreen('food');return;}zinkitBrowseSelectedMain=category;renderCategories();openHomeCategories();}
function renderProducts(){const q=$("search").value.trim();const list=products.filter(p=>{const cat=productCategory(p).toLowerCase(),brand=String(p.brand||p.Brand||'').toLowerCase();const categoryOk=String(selectedCategory).toLowerCase()==='price drop'?productIsDiscounted(p):categoryMatches(selectedCategory,cat,p);return categoryOk&&(!selectedBrandFilter||brand===selectedBrandFilter.toLowerCase())&&zinkitProductMatchesSearch(p,q)});const box=$("products");if(!list.length){box.innerHTML='<div class="empty" style="grid-column:1/-1">No products found.</div>';return}box.innerHTML=list.map(p=>{const img=productImage(p),id=JSON.stringify(productId(p)),qty=Object.entries(cart).filter(([k])=>String(k).split('__')[0]===String(productId(p))).reduce((a,[,v])=>a+Number(v),0);const control=qty>0?`<div class="qty productQty"><button type="button" onclick='event.stopPropagation();changeQty(${id},-1)'>−</button><span>${qty}</span><button type="button" onclick='event.stopPropagation();changeQty(${id},1)'>+</button></div>`:`<button class="add" type="button" onclick='event.stopPropagation();openVariantModal(${id})'>ADD</button>`;return `<div class="card zinkitProductCard" role="button" tabindex="0" data-zinkit-product-id="${esc(productId(p))}" aria-label="View ${esc(productName(p))}" onclick="openProductDetail(${id})" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();openProductDetail(${id})}"><div class="pic" onclick="openProductDetail(${id})">${img?`<img src="${esc(img)}" loading="lazy" decoding="async" alt="${esc(productName(p))}" onerror="this.style.display='none';this.parentElement.insertAdjacentHTML('beforeend','🛍️')">`:'🛍️'}</div><div class="name" onclick="openProductDetail(${id})">${esc(productName(p))}</div><div class="muted" onclick="openProductDetail(${id})">Fresh & quality • ${esc(productCategory(p))}${p.brand?` • 🏷️ ${esc(p.brand)}`:""}</div><div class="row">${productPriceMarkup(p)}${control}</div></div>`}).join("")}
function openProductDetail(id){
  currentDetailProductId=id;
  const p=products.find(x=>String(productId(x))===String(id));
  if(!p)return;
  const imgs=[p.Image1,p.Image2,p.Image3,p.Image,p.image1,p.image2,p.image3,p.image,p.image_url,p.imageUrl].filter((v,i,a)=>typeof v==='string'&&v.trim()&&a.indexOf(v)===i).slice(0,3);
  const img=imgs[0]||'', name=productName(p), price=productPrice(p), qty=Object.entries(cart).filter(([k])=>String(k).split('__')[0]===String(id)).reduce((s,[,v])=>s+Number(v),0), cm=clothMeta(p);
  let gallery='';
  if(imgs.length){
    const slides=imgs.map(u=>`<img class="zkPhotoSlide" src="${esc(u)}" loading="lazy" decoding="async" alt="${esc(name)}" draggable="false" onerror="this.style.opacity='.35'">`).join('');
    const dots=imgs.map((_,i)=>`<span class="zkPhotoDot${i===0?' active':''}"></span>`).join('');
    gallery=`<div class="zkPhotoGallery" id="zkPhotoGallery" aria-label="Swipe left or right to view product photos" data-index="0" data-count="${imgs.length}"><div class="zkPhotoTrack" id="zkPhotoTrack">${slides}</div></div>${imgs.length>1?`<div class="zkPhotoDots" id="zkPhotoDots">${dots}</div>`:''}`;
  }else gallery='<div class="pic" style="height:260px;border-radius:18px;background:#f6f8f6;display:flex;align-items:center;justify-content:center">🛍️</div>';
  detailClothColour=''; detailClothSize='';
  const clothInfo=(cm.colours.length||cm.sizes.length)?`<div class="summary"><b>👕 Choose your options</b>${cm.colours.length?`<div class="clothOptionGroup"><b>🎨 Colour</b><div class="clothChoices">${cm.colours.map(v=>`<button type="button" class="clothChoice" onclick='chooseDetailClothOption("colour",${JSON.stringify(v)},this)'>${esc(v)}</button>`).join('')}</div></div>`:''}${cm.sizes.length?`<div class="clothOptionGroup"><b>📏 Size <button type="button" class="sizeChartLink" onclick="openSizeChart()">Size Chart</button></b><div class="clothChoices">${cm.sizes.map(v=>{const tracked=Object.prototype.hasOwnProperty.call(cm.sizeStocks||{},v);const sold=tracked&&Number(cm.sizeStocks[v])<=0;return `<button type="button" class="clothChoice ${sold?'soldOut':''}" ${sold?'disabled':''} onclick='chooseDetailClothOption("size",${JSON.stringify(v)},this)'>${esc(v)}${sold?'<small>Sold out</small>':''}</button>`}).join('')}</div></div>`:''}</div>`:'';
  const detailAddAction=isClothProduct(p)?`addDetailClothToCart(${JSON.stringify(id)})`:`openVariantModal(${JSON.stringify(id)})`;
  $('productDetail').innerHTML=`<div style="padding:0 16px 24px">${gallery}<h2 style="margin:18px 0 5px">${esc(name)}</h2><div class="muted">${esc(productCategory(p))}</div><div style="font-size:24px;font-weight:900;margin:14px 0">${productPriceMarkup(p)}</div>${clothInfo}<div class="summary"><b>Product details</b><p style="color:#666;line-height:1.5">Fresh & quality product. Variant, colour and size are shown as provided by the store.</p></div><div class="row" style="margin-top:14px;justify-content:space-between"><div class="qty"><button type="button" onclick='changeQty(${JSON.stringify(id)},-1);openProductDetail(${JSON.stringify(id)})'>−</button><span>${qty}</span><button type="button" class="add" onclick='${detailAddAction}'>${qty?'ADD MORE':'ADD TO CART'}</button></div></div></div>`;
  if(imgs.length>1){
    const galleryEl=$('zkPhotoGallery'), track=$('zkPhotoTrack'), dotsEl=$('zkPhotoDots');
    let current=0,startX=0,startY=0,dragging=false;
    const setSlide=(n,animate=true)=>{current=Math.max(0,Math.min(imgs.length-1,n));track.style.transition=animate?'transform .22s ease':'none';track.style.transform=`translate3d(${-current*100}%,0,0)`;galleryEl.dataset.index=String(current);if(dotsEl)[...dotsEl.children].forEach((d,i)=>d.classList.toggle('active',i===current));};
    galleryEl.addEventListener('touchstart',e=>{if(!e.touches[0])return;startX=e.touches[0].clientX;startY=e.touches[0].clientY;dragging=true;track.style.transition='none';},{passive:true});
    galleryEl.addEventListener('touchmove',e=>{if(!dragging||!e.touches[0])return;const dx=e.touches[0].clientX-startX,dy=e.touches[0].clientY-startY;if(Math.abs(dx)>Math.abs(dy)){e.preventDefault();track.style.transform=`translate3d(calc(${-current*100}% + ${dx}px),0,0)`;}},{passive:false});
    galleryEl.addEventListener('touchend',e=>{if(!dragging)return;dragging=false;const t=e.changedTouches&&e.changedTouches[0];const dx=t?t.clientX-startX:0;const threshold=Math.max(45,galleryEl.clientWidth*.12);if(dx<-threshold)setSlide(current+1);else if(dx>threshold)setSlide(current-1);else setSlide(current);});
    galleryEl.addEventListener('mousedown',e=>{if(e.button!==0)return;startX=e.clientX;startY=e.clientY;dragging=true;track.style.transition='none';});
    window.addEventListener('mouseup',e=>{if(!dragging)return;dragging=false;const dx=e.clientX-startX;const threshold=Math.max(45,galleryEl.clientWidth*.12);if(dx<-threshold)setSlide(current+1);else if(dx>threshold)setSlide(current-1);else setSlide(current);},{once:false});
    if(dotsEl)[...dotsEl.children].forEach((d,i)=>d.addEventListener('click',()=>setSlide(i)));
    setSlide(0,false);
  }
  // Show a larger recommendation shelf: same category first, then same brand, then other available products.
  // Keep the currently opened product out and deduplicate by product ID.
  const otherProducts=products.filter(x=>String(productId(x))!==String(id));
  const categoryKey=String(productCategory(p)||'').trim().toLowerCase();
  const brandKey=String(p.brand||p.Brand||'').trim().toLowerCase();
  const categoryRelated=otherProducts.filter(x=>categoryKey&&String(productCategory(x)||'').trim().toLowerCase()===categoryKey);
  const brandRelated=otherProducts.filter(x=>brandKey&&String(x.brand||x.Brand||'').trim().toLowerCase()===brandKey);
  const recommendationPool=[...categoryRelated,...brandRelated,...otherProducts];
  const seenRelated=new Set();
  const fallback=recommendationPool.filter(x=>{const key=String(productId(x));if(seenRelated.has(key))return false;seenRelated.add(key);return true;}).slice(0,20);
  $('relatedProducts').innerHTML=fallback.length?fallback.map(r=>{const ri=productImage(r),rid=JSON.stringify(productId(r));return `<div class="card" onclick='openProductDetail(${rid})'><div class="pic">${ri?`<img src="${esc(ri)}" loading="lazy" decoding="async" alt="${esc(productName(r))}">`:'🛍️'}</div><div class="name">${esc(productName(r))}</div><div class="muted">${esc(productCategory(r))}${r.brand||r.Brand?` · 🏷️ ${esc(r.brand||r.Brand)}`:''}</div><div class="row">${productPriceMarkup(r)}<button class="add" onclick='event.stopPropagation();openVariantModal(${rid})'>ADD</button></div></div>`}).join(''):'<div class="empty" style="grid-column:1/-1">More products will appear here when available.</div>';
  showScreen('productDetail');
  loadProductReviews(p);
}
let zinkitReviewProduct=null, zinkitReviewRating=5;
function zinkitReviewStars(rating,interactive=false){
  return [1,2,3,4,5].map(n=>interactive?`<button type="button" aria-label="${n} stars" onclick="zinkitSetReviewRating(${n})" style="padding:3px 5px;background:transparent;color:${n<=rating?'#f59e0b':'#cbd5e1'};font-size:28px;line-height:1">★</button>`:`<span style="color:${n<=rating?'#f59e0b':'#d1d5db'}">★</span>`).join('');
}
function zinkitSetReviewRating(n){zinkitReviewRating=Math.max(1,Math.min(5,Number(n)||5));const box=$('zinkitReviewStars');if(box)box.innerHTML=zinkitReviewStars(zinkitReviewRating,true);const label=$('zinkitReviewRatingLabel');if(label)label.textContent=`${zinkitReviewRating}/5`;}
async function loadProductReviews(product){
  zinkitReviewProduct=product;zinkitReviewRating=5;
  const summary=$('productReviewSummary'), form=$('productReviewForm'), list=$('productReviewList');
  if(!summary||!form||!list)return;
  const name=localStorage.getItem('zinkit_customer_name')||'';
  const phone=(localStorage.getItem('zinkit_customer_mobile')||'').replace(/\D/g,'').slice(-10);
  form.innerHTML=`<div style="border:1px solid #eee6fa;background:#faf7ff;border-radius:12px;padding:12px;margin-bottom:14px"><b style="display:block;margin-bottom:5px">Rate this product</b><div style="display:flex;align-items:center;gap:6px"><div id="zinkitReviewStars">${zinkitReviewStars(5,true)}</div><b id="zinkitReviewRatingLabel">5/5</b></div><textarea id="zinkitReviewText" rows="3" maxlength="1000" placeholder="Aapka product kaisa laga? Apna review likhein…" style="width:100%;box-sizing:border-box;margin:8px 0;padding:11px;border:1px solid #ddd;border-radius:10px;font:inherit;resize:vertical"></textarea><div style="font-size:11px;color:#6b7280;margin-bottom:8px">Review submit karne ke liye customer mobile login zaroori hai.</div><button type="button" id="zinkitSubmitReviewBtn" onclick="submitProductReview()" style="width:100%">Submit Review</button></div>`;
  if(!db){summary.textContent='Reviews ke liye database connection available nahi hai.';list.innerHTML='';return;}
  summary.textContent='Reviews load ho rahe hain…';list.innerHTML='';
  try{
    // Do not filter by an approval-column name here: existing installations may
    // use either `approved` or `is_approved`. Supabase RLS already limits SELECT
    // to approved rows, so querying without either column supports both schemas.
    const r=await db.from('product_reviews').select('id,product_id,customer_name,rating,review,created_at').eq('product_id',Number(productId(product))).order('created_at',{ascending:false}).limit(50);
    if(r.error)throw r.error;
    const rows=r.data||[];const avg=rows.length?rows.reduce((a,x)=>a+Number(x.rating||0),0)/rows.length:0;
    summary.innerHTML=rows.length?`<b style="font-size:20px;color:#111">${avg.toFixed(1)} / 5</b> <span style="color:#f59e0b;font-size:18px">${zinkitReviewStars(Math.round(avg),false)}</span><div style="font-size:12px;color:#6b7280">${rows.length} customer review${rows.length===1?'':'s'}</div>`:'Abhi is product ka koi review nahi hai. Pehla review aap dein!';
    list.innerHTML=rows.length?rows.map(x=>`<article style="padding:12px 0;border-top:1px solid #eee"><div style="display:flex;justify-content:space-between;gap:8px;align-items:center"><b>${esc(x.customer_name||'Customer')}</b><small style="color:#777">${x.created_at?new Date(x.created_at).toLocaleDateString('en-IN'):''}</small></div><div style="font-size:16px;margin:3px 0">${zinkitReviewStars(Number(x.rating)||0,false)}</div><div style="font-size:13px;line-height:1.5;white-space:pre-wrap">${esc(x.review||'')}</div></article>`).join(''):'';
  }catch(e){
    console.warn('Product reviews load failed:',e);
    summary.textContent='Reviews database se load nahi ho paaye.';
    list.innerHTML='<div style="font-size:12px;color:#92400e;line-height:1.5">Supabase connection, product_reviews table aur uski permissions check karein. Technical detail console mein available hai.</div>';
  }
}
async function submitProductReview(){
  const p=zinkitReviewProduct, text=($('zinkitReviewText')?.value||'').trim();
  const phone=(localStorage.getItem('zinkit_customer_mobile')||'').replace(/\D/g,'').slice(-10);
  const name=(localStorage.getItem('zinkit_customer_name')||'Customer').trim().slice(0,100)||'Customer';
  const btn=$('zinkitSubmitReviewBtn');
  if(!p){alert('Product select nahi hua.');return;}
  if(!/^[0-9]{10}$/.test(phone)){alert('Pehle apna 10-digit mobile number login karein.');return;}
  if(!text){alert('Apna review likhein.');$('zinkitReviewText')?.focus();return;}
  if(!db){alert('Database connection available nahi hai.');return;}
  if(btn){btn.disabled=true;btn.textContent='Submitting…';}
  try{
    const payload={product_id:Number(productId(p)),product_name:productName(p),customer_name:name,customer_phone:phone,rating:zinkitReviewRating,review:text,store_id:p.store_id==null?null:Number(p.store_id)};
    const r=await db.from('product_reviews').insert(payload);
    if(r.error)throw r.error;
    alert('✅ Aapka review submit ho gaya.');
    await loadProductReviews(p);
  }catch(e){console.error('Review submit failed:',e);alert('Review save nahi hua. Supabase mein SUPABASE_PRODUCT_REVIEWS.sql run karein. Details: '+(e.message||e));}
  finally{const b=$('zinkitSubmitReviewBtn');if(b){b.disabled=false;b.textContent='Submit Review';}}
}

async function trackOrder(id){
  // Track the exact order from Supabase first. This keeps Track Order working
  // even when renderOrders() fetched the latest orders into its local list only.
  let o=orders.find(x=>String(x.id)===String(id))||null;
  if(db){
    try{
      const r=await db.from('orders').select('*').eq('id',id).maybeSingle();
      if(!r.error&&r.data){
        o=r.data;
        const idx=orders.findIndex(x=>String(x.id)===String(id));
        if(idx>=0)orders[idx]=o; else orders.unshift(o);
      }
    }catch(e){}
  }
  if(!o){alert('Order details nahi mile.');return;}
  $('ordersList').innerHTML=`<div class="orderCard">
    <h3 style="margin:0 0 12px">🚚 Track Order #${esc(id)}</h3>
    <div style="padding:12px;border-left:4px solid #16852b;background:#f4fbf4;border-radius:8px">
      <b>${esc(o.status||'Order Placed')}</b><br><span style="color:#666">Rider app se order accept hone ke baad live location yahin dikhegi.</span>
    </div>
    <div style="margin-top:10px;padding:12px;border:1px solid #eee;border-radius:8px">
      📍 Delivery Address<br><b>${esc(o.address||'Saved location')}</b>
    </div>
    ${o.rider_id?`<div style="margin-top:10px;padding:10px;border-radius:10px;background:#eef9f0;color:#166534;font-weight:800">🚴 Rider accepted • Live GPS check ON</div>
    <div id="riderContactLive" style="margin-top:10px"></div>
    <div id="orderLiveStatus" style="margin-top:10px;padding:10px;border-radius:10px;background:#f7f7f7;color:#555;font-weight:700">📍 Rider location check ho rahi hai…</div>
    <div id="orderLiveMapWrap" style="display:none;margin-top:10px"><div id="orderLiveMap" title="ZinKit Rider Live Location" style="width:100%;height:300px;border-radius:14px;overflow:hidden;background:#e9eef3"></div><a id="orderLiveMapLink" href="#" target="_blank" rel="noopener" style="display:none;margin-top:8px;font-weight:800;text-decoration:none">📍 Open Rider Location in Google Maps</a></div>`:'<div style="margin-top:10px;padding:10px;border-radius:10px;background:#fff8e8;color:#92400e;font-weight:800">🟡 Rider abhi order accept nahi kiya hai.</div>'}
    <button class="back" onclick="renderOrders()">← Back to orders</button>
  </div>`;
  window.scrollTo({top:0,behavior:'smooth'});
  // Use the mobile stored on this exact order first. The RPC uses it to authorize tracking.
  riderLiveMobile=String(o.mobile||$('custMobile')?.value||localStorage.getItem('zinkit_customer_mobile')||'').replace(/\D/g,'').slice(-10);
  // Track Order starts rider live-location polling.
  startRiderLiveTracking(id, riderLiveMobile);
}
let pendingVariantProduct=null;
function isFoodProduct(p){
  const c=String(productCategory(p)).toLowerCase();
  return c.includes('biryani')||c.includes('fast food')||c.includes('food')||c.includes('bakery')||c.includes('snack');
}

function clothMeta(p){
  const s=String(p.Description||p.description||'');
  const m=s.match(/__ZINKIT_CLOTH__:(\{[\s\S]*\})(?=\s*__ZINKIT_DISCOUNT__|\s*__ZINKIT_STORE_DISCOUNT__|\s*__ZINKIT_VARIANTS__|\s*$)/s);
  if(!m)return {colours:[],sizes:[],sizeStocks:{}};
  try{const x=JSON.parse(m[1])||{};return {colours:Array.isArray(x.colours)?x.colours:[],sizes:Array.isArray(x.sizes)?x.sizes:[],sizeStocks:x.sizeStocks&&typeof x.sizeStocks==='object'?x.sizeStocks:{}};}catch(e){return {colours:[],sizes:[],sizeStocks:{}};}
}
function isClothProduct(p){const c=String(productCategory(p)).toLowerCase();const m=clothMeta(p);return c.includes('cloth')||c.includes('clothing')||c.includes('fashion')||m.colours.length||m.sizes.length;}

function productVariants(p){
  const raw=String(p.Description||p.description||'');
  const m=raw.match(/__ZINKIT_VARIANTS__:(\[[\s\S]*?\])(?=\s*$)/);
  if(m){
    try{
      const arr=JSON.parse(m[1]);
      if(Array.isArray(arr)&&arr.length){
        const seen=new Set();
        const cleaned=arr.filter(v=>v&&String(v.name||'').trim()&&String(v.price??'').trim()!==''&&Number.isFinite(Number(v.price))&&Number(v.price)>=0)
          .map(v=>({name:String(v.name).trim(),price:Number(v.price)}))
          .filter(v=>{const key=v.name.toLocaleLowerCase();if(seen.has(key))return false;seen.add(key);return true;});
        if(cleaned.length)return cleaned;
      }
    }catch(e){}
  }
  // No configured variants: show one base-price option, never invent 100g/250g/500g/1kg.
  return [{name:'Default',price:productPrice(p)}];
}

let pendingClothProduct=null,pendingClothColour='',pendingClothSize='',detailClothColour='',detailClothSize='',currentDetailProductId=null;
function chooseDetailClothOption(type,value,el){if(type==='colour'){detailClothColour=value;document.querySelectorAll('#productDetail .clothOptionGroup').forEach(g=>{if(g.textContent.includes('Colour'))g.querySelectorAll('.clothChoice').forEach(b=>b.classList.remove('selected'));});}else{const p=products.find(x=>String(productId(x))===String(currentDetailProductId));const m=clothMeta(p||{});if(Object.prototype.hasOwnProperty.call(m.sizeStocks||{},value)&&Number(m.sizeStocks[value])<=0){alert('Ye size Sold out hai.');return;}detailClothSize=value;document.querySelectorAll('#productDetail .clothOptionGroup').forEach(g=>{if(g.textContent.includes('Size'))g.querySelectorAll('.clothChoice').forEach(b=>b.classList.remove('selected'));});}el.classList.add('selected');}
function addDetailClothToCart(id){const p=products.find(x=>String(productId(x))===String(id));if(!p)return;const m=clothMeta(p);if(m.colours.length&&!detailClothColour){alert('Colour select karein.');return;}if(m.sizes.length&&!detailClothSize){alert('Size select karein.');return;}if(detailClothSize&&Object.prototype.hasOwnProperty.call(m.sizeStocks||{},detailClothSize)&&Number(m.sizeStocks[detailClothSize])<=0){alert('Ye size Sold out hai.');return;}const label=[detailClothColour,detailClothSize].filter(Boolean).join(' / ')||'Default';const key=String(id)+'__'+label;cart[key]=(cart[key]||0)+1;save();renderProducts();renderCart();alert('Product cart mein add ho gaya.');}
function openClothModal(id){
  const p=products.find(x=>String(productId(x))===String(id)); if(!p)return;
  pendingClothProduct=p; pendingClothColour=''; pendingClothSize='';
  const m=clothMeta(p); $('clothProductName').textContent='👕 '+productName(p);
  $('clothColoursWrap').innerHTML=m.colours.length?`<div class="clothOptionGroup"><b>🎨 Colour</b><div class="clothChoices">${m.colours.map(v=>`<button type="button" class="clothChoice" onclick='chooseClothColour(${JSON.stringify(v)},this)'>${esc(v)}</button>`).join('')}</div></div>`:'';
  $('clothSizesWrap').innerHTML=m.sizes.length?`<div class="clothOptionGroup"><b>📏 Size <button type="button" class="sizeChartLink" onclick="openSizeChart()">Size Chart</button></b><div class="clothChoices">${m.sizes.map(v=>{const tracked=Object.prototype.hasOwnProperty.call(m.sizeStocks||{},v);const sold=tracked&&Number(m.sizeStocks[v])<=0;return `<button type="button" class="clothChoice ${sold?'soldOut':''}" ${sold?'disabled':''} onclick='chooseClothSize(${JSON.stringify(v)},this)'>${esc(v)}${sold?'<small>Sold out</small>':''}</button>`}).join('')}</div></div>`:'';
  $('clothModal').classList.add('show');
}
function openSizeChart(){$('sizeChartModal').classList.add('show');}
function closeSizeChart(){$('sizeChartModal').classList.remove('show');}
function chooseClothColour(v,el){pendingClothColour=v;document.querySelectorAll('#clothColoursWrap .clothChoice').forEach(x=>x.classList.remove('selected'));el.classList.add('selected');}
function chooseClothSize(v,el){const m=clothMeta(pendingClothProduct||{});if(Object.prototype.hasOwnProperty.call(m.sizeStocks||{},v)&&Number(m.sizeStocks[v])<=0)return;pendingClothSize=v;document.querySelectorAll('#clothSizesWrap .clothChoice').forEach(x=>x.classList.remove('selected'));el.classList.add('selected');}
function closeClothModal(){$('clothModal').classList.remove('show');pendingClothProduct=null;pendingClothColour='';pendingClothSize='';}
function confirmClothAdd(){
  if(!pendingClothProduct)return;
  const m=clothMeta(pendingClothProduct);
  if(m.colours.length&&!pendingClothColour){alert('Colour select karein.');return;}
  if(m.sizes.length&&!pendingClothSize){alert('Size select karein.');return;}
  if(pendingClothSize&&Object.prototype.hasOwnProperty.call(m.sizeStocks||{},pendingClothSize)&&Number(m.sizeStocks[pendingClothSize])<=0){alert('Ye size Sold out hai.');return;}
  const id=String(productId(pendingClothProduct));
  const label=[pendingClothColour,pendingClothSize].filter(Boolean).join(' / ')||'Default';
  const key=id+'__'+label; cart[key]=(cart[key]||0)+1; save(); closeClothModal(); renderProducts(); renderCart();
}

function openVariantModal(id){
  const p=products.find(x=>String(productId(x))===String(id));
  if(!p)return;
  if(isClothProduct(p)){openClothModal(id);return;}
  pendingVariantProduct=p;
  $('variantProductName').textContent=productName(p);
  const options=productVariants(p);
  $('variantChoices').innerHTML=options.map(v=>{
    const price=productStoreDiscount(p,v.price);
    return `<button type="button" class="variantBtn" onclick='selectVariant(${JSON.stringify(v.name)},${price})'><b>${esc(v.name)}</b><small>₹${price.toLocaleString('en-IN')}</small></button>`;
  }).join('');
  $('variantModal').classList.add('show');
}
function closeVariantModal(){ $('variantModal').classList.remove('show'); pendingVariantProduct=null; }
function selectVariant(variant,price){
  if(!pendingVariantProduct)return;
  const id=String(productId(pendingVariantProduct));
  const key=id+'__'+variant;
  cart[key]=(cart[key]||0)+1;
  save(); closeVariantModal(); renderProducts(); renderCart();
}
function addToCart(id,variant=''){
  const p=products.find(x=>String(productId(x))===String(id));
  if(isFoodProduct(p)&&!variant){openVariantModal(id);return;}
  const key=variant?String(id)+'__'+variant:String(id);
  cart[key]=(cart[key]||0)+1;save();renderProducts();renderCart();
}
function changeQty(key,d){
  const keepY=window.scrollY;
  let targetKey=String(key);
  // Product cards can represent variant keys (id__variant). If an exact key
  // is not present, use the first cart entry belonging to this product.
  if(!Object.prototype.hasOwnProperty.call(cart,targetKey)){
    const match=Object.keys(cart).find(k=>String(k).split('__')[0]===targetKey);
    if(match) targetKey=match;
  }
  const current=Math.max(0,Number(cart[targetKey]||0));
  const next=Math.max(0,current+Number(d||0));
  if(next===0) delete cart[targetKey];
  else cart[targetKey]=next;
  save();
  renderProducts();
  renderCart();
  requestAnimationFrame(()=>window.scrollTo(0,keepY));
}
function cartEntry(key,qty){
  const parts=String(key).split('__');
  const id=parts[0],variant=parts.slice(1).join('__');
  const p=products.find(x=>String(productId(x))===String(id));
  if(!p)return null;
  const variantBase=variant?variantPrice(p,variant):productBasePrice(p);
  const price=productStoreDiscount(p,variantBase);
  return {...p,qty,key,variant,cartPrice:price};
}
function variantPrice(p,variant){
  const found=productVariants(p).find(v=>String(v.name)===String(variant));
  return found?Number(found.price):productPrice(p);
}
function cartItems(){return Object.entries(cart).map(([key,qty])=>cartEntry(key,qty)).filter(Boolean)}
function renderCart(){const items=cartItems(),box=$("cartItems");const foodItems=Object.entries(zFoodCart).map(([key,x])=>({...x,key,cartPrice:Number(x.variantPrice??x.item.price??0)+x.addons.reduce((s,a)=>s+Number(a.price||0),0),name:x.item.name,image:x.item.image_url,variant:x.variantId?"Customised":"",qty:x.qty}));if(!items.length&&!foodItems.length){box.innerHTML='<div class="empty">🛒<br><br>Your cart is empty.<br>Add products to continue.</div>';$('cartSummary').innerHTML="";return}box.innerHTML=items.map(p=>{const img=productImage(p),key=JSON.stringify(p.key);return `<div class="cartItem"><div class="cartEmoji">${img?`<img src="${esc(img)}" style="width:52px;height:52px;object-fit:contain;border-radius:10px" onerror="this.style.display='none'">`:'🛍️'}</div><div class="cartInfo"><b>${esc(productName(p))}</b>${p.variant?`<div style="color:#16852b;font-weight:800;font-size:12px;margin:3px 0">${esc(p.variant)}</div>`:''}<div>₹${p.cartPrice} × ${p.qty} = <b>₹${p.cartPrice*p.qty}</b></div><div class="qty"><button onclick='event.stopPropagation();changeQty(${key},-1)'>−</button><span>${p.qty}</span><button onclick='event.stopPropagation();changeQty(${key},1)'>+</button></div>${ZINKIT_CANCEL_SETTINGS.product?`<button type="button" style="margin-top:7px;background:#fff;color:#b91c1c;border:1px solid #fecaca;border-radius:8px;padding:6px 10px;font-weight:800" onclick='removeCartProduct(${key})'>✕ Cancel / Remove Product</button>`:''}</div></div>`}).join("")+foodItems.map(p=>`<div class="cartItem"><div class="cartEmoji">${p.image?`<img src="${esc(p.image)}" style="width:52px;height:52px;object-fit:contain;border-radius:10px">`:'🍛'}</div><div class="cartInfo"><b>${esc(p.name)}</b><div style="color:#16852b;font-size:12px">${p.addons.length?'Extras: '+esc(p.addons.map(a=>a.name).join(', ')):''}</div><div>₹${p.cartPrice} × ${p.qty} = <b>₹${p.cartPrice*p.qty}</b></div><div class="qty"><button onclick="zFoodQty('${p.key}',-1)">−</button><span>${p.qty}</span><button onclick="zFoodQty('${p.key}',1)">+</button></div>${ZINKIT_CANCEL_SETTINGS.product?`<button type="button" style="margin-top:7px;background:#fff;color:#b91c1c;border:1px solid #fecaca;border-radius:8px;padding:6px 10px;font-weight:800" onclick="removeFoodCartProduct('${p.key}')">✕ Cancel / Remove Product</button>`:''}</div></div>`).join('');const allSubtotal=items.reduce((s,p)=>s+p.cartPrice*p.qty,0)+foodItems.reduce((s,p)=>s+p.cartPrice*p.qty,0);const subtotal=allSubtotal,delivery=subtotal>=199?0:25;$('cartSummary').innerHTML=`<div class="summary"><div class="line"><span>Subtotal</span><b>₹${subtotal}</b></div><div class="line"><span>Delivery</span><b>${delivery?'₹'+delivery:'FREE'}</b></div><div class="line total"><span>Total</span><b>₹${subtotal+delivery}</b></div><button class="checkout" onclick="openCheckout()">Proceed to Checkout</button></div>`}
function removeCartProduct(key){
  if(!ZINKIT_CANCEL_SETTINGS.product){alert('Product/cart cancellation Admin Settings mein disabled hai.');return;}
  const p=cartEntry(key,cart[key]);
  if(!confirm('"'+(p?productName(p):'Product')+'" ko cart se remove karna hai?'))return;
  delete cart[key];save();renderProducts();renderCart();
}
function removeFoodCartProduct(key){
  if(!ZINKIT_CANCEL_SETTINGS.product){alert('Product/cart cancellation Admin Settings mein disabled hai.');return;}
  if(!confirm('Is food item ko cart se remove karna hai?'))return;
  delete zFoodCart[key];save();renderCart();
}
function openCheckout(){
  if(!cartItems().length&&!zFoodCartItems().length){alert('Cart empty hai.');return;}
  const keepY=window.scrollY;
  showScreen('checkout');
  const a=$('custAddress');
  a.removeAttribute('readonly'); a.removeAttribute('disabled');
  if(deliveryLocation?.address) a.value=deliveryLocation.address;
  setTimeout(()=>{a.blur();window.scrollTo(0,keepY)},80);
}

function resetCartAfterOrder(){
  cart={};
  zFoodCart={};
  localStorage.setItem('mdmunna_cart', JSON.stringify(cart));
  save();
  renderProducts();
  renderCart();
  updateCount();
}

function zFoodQty(key,delta){if(!zFoodCart[key])return;zFoodCart[key].qty=Math.max(0,Number(zFoodCart[key].qty)+delta);if(!zFoodCart[key].qty)delete zFoodCart[key];renderCart();renderFloatingCart();}
function zFoodCartItems(){return Object.entries(zFoodCart).map(([key,x])=>({key,item:x.item,qty:Number(x.qty),variantId:x.variantId||null,addons:x.addons||[],price:Number(x.variantPrice??x.item.price??0)+((x.addons||[]).reduce((s,a)=>s+Number(a.price||0),0))}));}
async function ensureOrderGPS(){if(deliveryLocation&&Number.isFinite(Number(deliveryLocation.latitude))&&Number.isFinite(Number(deliveryLocation.longitude)))return true;if(!navigator.geolocation){alert('📍 Customer live location nahi mil rahi. Please location enable karein.');return false}if(location.protocol!=='https:'&&location.protocol!=='file:'){alert('🔒 GPS ke liye HTTPS website zaroori hai.');return false}return await new Promise(resolve=>{navigator.geolocation.getCurrentPosition(async pos=>{await saveDetectedLocation(pos.coords.latitude,pos.coords.longitude,'gps');resolve(true)},err=>{alert('📍 Customer live location save nahi hui. Order place karne se pehle Current Location/Allow Location karein.');resolve(false)},{enableHighAccuracy:true,timeout:20000,maximumAge:0})})}async function placeOrder(ev){
  if(ev){ev.preventDefault();ev.stopPropagation();}
  const btn=$('placeOrderBtn'), status=$('orderPlaceStatus');
  if(btn?.dataset.busy==='1') return;

  const setStatus=(msg,ok=true)=>{
    if(status){
      status.textContent=msg;
      status.style.color=ok?'#16852b':'#c62828';
    }
  };

  try{
    const name=$('custName')?.value.trim()||'';
    const mobile=$('custMobile')?.value.trim()||'';
    const address=$('custAddress')?.value.trim()||'';
    const payment=$('payment')?.value||'COD';

    if(!name){setStatus('Naam bhariye.',false);$('custName')?.focus();return;}
    if(!/^[0-9]{10}$/.test(mobile)){setStatus('10-digit mobile number bhariye.',false);$('custMobile')?.focus();return;}
    if(!address){setStatus('Delivery address bhariye.',false);$('custAddress')?.focus();return;}

    const items=cartItems();
    const foodOrderItems=zFoodCartItems();
    if(!items.length&&!foodOrderItems.length){setStatus('Cart empty hai.',false);return;}

    if(typeof mdMunnaCanProcessOrder==='function' && !mdMunnaCanProcessOrder()){
      if(typeof mdMunnaShowDailyLimit==='function')mdMunnaShowDailyLimit();
      setStatus('Aaj ke 1,000 orders complete ho gaye hain.',false);
      return;
    }

    if(btn){
      btn.dataset.busy='1';
      btn.disabled=true;
      btn.textContent='⏳ Order place ho raha hai…';
      btn.style.opacity='.7';
    }
    setStatus('📍 Location check ho rahi hai…');

    if(!(await ensureOrderGPS())){
      setStatus('📍 Location allow karke dobara Place Order dabayein.',false);
      return;
    }

    /* Always re-match the customer against active stores after GPS is known. */
    ZINKIT_DELIVERY_SETTINGS_READY=false;
    await zinkitLoadDeliverySettings();
    zinkitUpdateSelectedStoreUI();

    const range=zinkitCheckDeliveryRange(deliveryLocation.latitude,deliveryLocation.longitude);
    zinkitShowRangeStatus(range.distance,range.allowed);
    if(!range.allowed){
      if(!ZINKIT_DELIVERY_RESTRICTION_ENABLED){
        setStatus('❌ Delivery settings load nahi hui. Please try again.',false);
      }else if(!Number.isFinite(Number(range.distance))){
        setStatus('❌ Store location Admin app mein set nahi hai.',false);
      }else{
        setStatus(`❌ Aap ${range.distance.toFixed(1)} km door hain. ZinKit delivery range ${range.radius} km hai.`,false);
      }
      return;
    }

    setStatus('🛒 Order save ho raha hai…');

    const subtotal=items.reduce((s,p)=>s+p.cartPrice*p.qty,0)+foodOrderItems.reduce((s,p)=>s+p.price*p.qty,0);
    /* Per-store Admin delivery charge; existing ₹199 free-delivery rule stays. */
    const configuredStoreCharge=Math.min(30,Math.max(0,Number(ZINKIT_ACTIVE_STORE_CHARGE)||0));
    const delivery=subtotal>=199?0:configuredStoreCharge;
    const payload={
      customer_name:name,
      mobile,
      address,
      payment,
      items:items.map(p=>({name:productName(p),variant:p.variant||'',qty:Number(p.qty),price:Number(p.cartPrice)})).concat(foodOrderItems.map(p=>({name:p.item.name,variant:'',qty:p.qty,price:p.price}))),
      order_type:foodOrderItems.length?'food':'grocery',
      restaurant_id:foodOrderItems.length?(zFoodCustomerRestaurant?.id||null):null,
      total:subtotal+delivery,
      status:'Order Placed',
      latitude:Number(deliveryLocation.latitude),
      longitude:Number(deliveryLocation.longitude),
      location_source:deliveryLocation.source||'gps',
      store_id:ZINKIT_ACTIVE_STORE_ID||null,
      store_name:ZINKIT_STORE_NAME||null,
      store_area:ZINKIT_ACTIVE_STORE_AREA||null
    };

    let saved=null;
    if(db){
      let r=await db.from('orders').insert(payload).select('*').single();
      if(r.error && /store_(id|name|area)/i.test(r.error.message||'')){
        const legacyPayload={...payload};
        delete legacyPayload.store_id;
        delete legacyPayload.store_name;
        delete legacyPayload.store_area;
        r=await db.from('orders').insert(legacyPayload).select('*').single();
      }
      if(r.error){
        setStatus('Order save nahi hua. '+r.error.message,false);
        return;
      }
      saved=r.data;
    }else{
      saved={...payload,id:'MM'+Date.now().toString().slice(-8),created_at:new Date().toISOString()};
    }

    if(foodOrderItems.length && saved?.id && db){
      const foodRows=foodOrderItems.map(p=>({order_id:saved.id,restaurant_id:zFoodCustomerRestaurant?.id||null,food_item_id:p.item.id,item_name:p.item.name,quantity:p.qty,unit_price:Number(p.item.price||0),variant_name:null,variant_price:null,addons:p.addons||[],total_price:p.price*p.qty}));
      const fr=await db.from('food_order_items').insert(foodRows); if(fr.error)console.warn('food_order_items save failed',fr.error);
    }
    orders.unshift(saved);
    cart={};
    zFoodCart={};
    save();
    renderProducts();
    renderCart();
    updateCount();

    if(typeof mdMunnaRecordProcessedOrder==='function')mdMunnaRecordProcessedOrder();

    setStatus('✅ Order successfully placed!');
    alert('✅ Order successfully placed! Order ID: #'+(saved.id||''));

    const keepY=window.scrollY;
    showScreen('orders');
    requestAnimationFrame(()=>window.scrollTo(0,keepY));

  }catch(err){
    console.error(err);
    setStatus('Order place nahi hua: '+(err?.message||'Please try again.'),false);
  }finally{
    if(btn){
      btn.dataset.busy='0';
      btn.disabled=false;
      btn.textContent='🛒 Place Order';
      btn.style.opacity='1';
    }
  }
}
async function getRiderContactForOrder(orderId, orderMobile, orderRiderId){
  try{
    if(!db || !orderId) return null;

    // Always prefer the mobile stored on this exact order.
    const mobile=String(orderMobile||$('custMobile')?.value||localStorage.getItem('zinkit_customer_mobile')||'')
      .replace(/\D/g,'').slice(-10);

    // Primary: existing secure RPC.
    if(mobile){
      const r=await db.rpc('get_rider_contact_for_order',{
        p_order_id:Number(orderId),
        p_mobile:mobile
      });
      if(!r.error && Array.isArray(r.data) && r.data.length && r.data[0]){
        return r.data[0];
      }
    }

    // Fallback: exact order rider UUID -> riders.user_id.
    // This does not alter any database data.
    if(orderRiderId){
      const r2=await db.from('riders')
        .select('name,phone,mobile')
        .eq('user_id',orderRiderId)
        .maybeSingle();
      if(!r2.error && r2.data){
        return r2.data;
      }
    }

    return null;
  }catch(e){
    console.warn('Rider contact fetch failed:',e?.message||e);
    return null;
  }
}
function riderContactHtml(c){
  if(!c) return '';
  const name=esc(c.name||c.full_name||'Delivery Rider');
  const phone=String(c.phone||'').replace(/\D/g,'');
  return `<div style="margin-top:10px;padding:12px;border:1px solid #bde5c4;border-radius:12px;background:#f2fff4">
    <b>🚴 Rider Details</b><div style="margin-top:5px;font-weight:900">👤 ${name}</div>
    ${phone?`<div style="margin-top:4px;font-weight:900">📞 ${esc(c.phone)}</div><a href="tel:${phone}" style="display:inline-block;margin-top:8px;background:#16852b;color:#fff;padding:9px 14px;border-radius:9px;text-decoration:none;font-weight:900">📞 Call Rider</a>`:''}
  </div>`;
}
async function refreshLiveRiderContact(orderId){
  const c=await getRiderContactForOrder(orderId);
  const el=document.getElementById('riderContactLive');
  if(el)el.innerHTML=riderContactHtml(c);
}
async function renderOrders(){
  const box=$('ordersList');
  let list=orders;
  const mobile=$('custMobile')?.value.trim();
  if(db&&mobile){
    const r=await db.from('orders').select('*').eq('mobile',mobile).order('created_at',{ascending:false});
    if(!r.error&&Array.isArray(r.data)&&r.data.length)list=r.data;
  }
  if(!list.length){
    zinkitRenderedOrders={};
    box.innerHTML='<div class="empty">📦<br><br>Abhi koi order nahi hai.</div>';
    return;
  }
  zinkitRenderedOrders=Object.fromEntries(list.map(o=>[String(o.id),o]));
  box.innerHTML=list.map(o=>{
    const items=Array.isArray(o.items)?o.items:[];
    const itemText=items.length
      ? items.map(i=>`<div style="padding:7px 0;border-bottom:1px solid #f0f0f0"><b>${esc(i.name||'Product')}</b>${i.variant?` <span style="color:#16852b;font-weight:800">(${esc(i.variant)})</span>`:''} × ${Number(i.qty||0)} <span style="float:right">₹${Number(i.price||0)*Number(i.qty||0)}</span></div>`).join('')
      : '<div style="color:#777">Product details unavailable</div>';
    return `<div class="orderCard">
      <div style="display:flex;justify-content:space-between;gap:10px">
        <b>Order #${esc(o.id)}</b><span class="status">${esc(o.status||'Order Placed')}</span>
      </div>
      <div style="margin-top:9px;font-size:13px;color:#666">${esc(o.created_at?new Date(o.created_at).toLocaleString('en-IN'):o.date||'')}</div>
      <div style="margin-top:12px"><b>🛍️ Aapne order kiya:</b></div>
      <div style="margin-top:5px">${itemText}</div>
      <div style="margin-top:10px;font-weight:800">Total: ₹${Number(o.total||0).toLocaleString('en-IN')} • ${esc(o.payment||'COD')}</div>
      ${o.rider_id ? `<div id="riderContact-${esc(o.id)}" style="margin-top:10px"></div>` : ''}
      <button class="checkout" style="padding:11px;margin-top:10px" onclick='trackOrder(${JSON.stringify(o.id)})'>🚚 Track Order</button>
      <button type="button" style="width:100%;margin-top:8px;background:#f0fdf4;color:#166534;border:1px solid #86efac;padding:11px;border-radius:10px;font-weight:900" onclick='orderAgain(${JSON.stringify(o.id)})'>🔄 Order Again</button>
      ${ZINKIT_CANCEL_SETTINGS.order && !['cancelled','delivered','completed','return requested','return approved','returned','return rejected'].includes(String(o.status||'').toLowerCase()) ? `<button type="button" style="width:100%;margin-top:8px;background:#fff;color:#d32f2f;border:1px solid #d32f2f;padding:11px;border-radius:10px;font-weight:900" onclick='cancelOrder(${JSON.stringify(o.id)})'>✕ Cancel Order</button>` : ''}
      ${['delivered','completed'].includes(String(o.status||'').toLowerCase()) && !(JSON.parse(localStorage.getItem('zinkit_return_requested_ids')||'[]').map(String).includes(String(o.id))) ? `<button type="button" style="width:100%;margin-top:8px;background:#fff7ed;color:#9a3412;border:1px solid #fdba74;padding:11px;border-radius:10px;font-weight:900" onclick='requestOrderReturn(${JSON.stringify(o.id)})'>↩️ Return Order</button>` : ''}
      ${String(o.status||'').toLowerCase().includes('return') ? `<div style="margin-top:8px;padding:9px;border-radius:9px;background:#fff7ed;color:#9a3412;font-weight:800;font-size:13px">↩️ Return status: ${esc(o.status)}</div>` : ''}
    </div>`;
  }).join('');
  const assigned=list.filter(o=>o && o.rider_id);
  await Promise.all(assigned.map(async o=>{
    const c=await getRiderContactForOrder(o.id,o.mobile,o.rider_id);
    const el=document.getElementById('riderContact-'+String(o.id).replace(/[^a-zA-Z0-9_-]/g,''));
    if(el)el.innerHTML=riderContactHtml(c);
  }));
}
async function orderAgain(id){
  const order=zinkitRenderedOrders[String(id)]||orders.find(x=>String(x.id)===String(id));
  if(!order){alert('Purane order ki details nahi mili. Orders refresh karke dobara try karein.');return;}
  const oldItems=Array.isArray(order.items)?order.items:[];
  if(!oldItems.length){alert('Is order ke product details available nahi hain.');return;}
  if(!db){alert('Supabase connection nahi hai.');return;}
  const button=[...document.querySelectorAll('#ordersList button')].find(b=>b.getAttribute('onclick')===`orderAgain(${JSON.stringify(id)})`);
  if(button){button.disabled=true;button.textContent='⏳ Products check ho rahe hain…';}
  try{
    // Refresh store selection and live product rows so old prices/stock are never reused.
    await zinkitLoadDeliverySettings();
    await loadProducts();
    const added=[],skipped=[];
    for(const old of oldItems){
      const oldName=String(old.name||old.product_name||'').trim();
      if(!oldName){skipped.push('Unknown product');continue;}
      const p=products.find(x=>String(productName(x)).trim().toLowerCase()===oldName.toLowerCase());
      if(!p){skipped.push(oldName+' (current store mein nahi hai)');continue;}
      if(p.out_of_stock===true||String(p.out_of_stock).toLowerCase()==='true'||p.available===false||p.is_active===false){skipped.push(oldName+' (out of stock)');continue;}
      const stockVal=p.stock??p.Stock;
      const requested=Math.max(1,Math.floor(Number(old.qty)||1));
      const maxQty=(stockVal!==undefined&&stockVal!==null&&String(stockVal)!=='')?Math.max(0,Math.floor(Number(stockVal))):requested;
      if(maxQty<=0){skipped.push(oldName+' (out of stock)');continue;}
      const qty=Math.min(requested,maxQty);
      const variant=String(old.variant||'').trim();
      if(variant){
        const meta=clothMeta(p);
        const size=variant.split('/').map(x=>x.trim()).find(x=>Object.prototype.hasOwnProperty.call(meta.sizeStocks||{},x));
        if(size&&Number(meta.sizeStocks[size])<=0){skipped.push(oldName+' ('+size+' sold out)');continue;}
      }
      const key=variant?String(productId(p))+'__'+variant:String(productId(p));
      cart[key]=Math.min(maxQty,Math.max(0,Number(cart[key]||0))+qty);
      added.push(oldName+(qty<requested?' (stock ke hisaab se '+qty+')':''));
    }
    save();renderProducts();renderCart();
    if(added.length){showScreen('cart');window.scrollTo(0,0);alert('✅ Available products cart mein add ho gaye. Current price aur stock use hua hai.\n\nAdded: '+added.join(', ')+(skipped.length?'\n\nSkipped: '+skipped.join(', '):'')+'\n\nCheckout se pehle cart aur total check karein.');}
    else alert('Purane order ke koi products abhi current store mein available nahi mile.'+(skipped.length?'\n\nSkipped: '+skipped.join(', '):''));
  }catch(e){alert('Order Again abhi complete nahi hua: '+(e?.message||e));}
  finally{if(button){button.disabled=false;button.textContent='🔄 Order Again';}}
}

async function requestOrderReturn(id){
  const mobile=String($('custMobile')?.value||localStorage.getItem('zinkit_customer_mobile')||'').replace(/\D/g,'').slice(-10);
  if(!/^[0-9]{10}$/.test(mobile)){alert('Return request ke liye customer mobile login zaroori hai.');return;}
  const o=orders.find(x=>String(x.id)===String(id));
  const status=String(o?.status||'').toLowerCase();
  if(!['delivered','completed'].includes(status)){alert('Return sirf delivered order ke liye request kar sakte hain.');return;}
  const reason=prompt('Return ka reason likhein (jaise wrong/damaged product):','');
  if(reason===null)return;
  if(!reason.trim()){alert('Return ka reason likhna zaroori hai.');return;}
  if(!db){alert('Database connection nahi hai.');return;}
  try{
    const result=await db.from('order_return_requests').insert({order_id:id,customer_mobile:mobile,reason:reason.trim(),status:'Pending'});
    if(result.error)throw result.error;
    const requested=JSON.parse(localStorage.getItem('zinkit_return_requested_ids')||'[]').map(String); if(!requested.includes(String(id)))requested.push(String(id)); localStorage.setItem('zinkit_return_requested_ids',JSON.stringify(requested));
    alert('✅ Return request submit ho gayi. Admin review karega.');
    renderOrders();
  }catch(e){alert('Return request save nahi hui: '+(e?.message||e)+'\nAgar table setup nahi hai to ZIP ke SUPABASE_ORDER_RETURNS.sql ko Supabase SQL Editor mein run karein.');}
}

async function cancelOrder(id){
  await zinkitLoadCancelSettings();
  if(!ZINKIT_CANCEL_SETTINGS.order){alert('Order cancellation Admin Settings mein disabled hai.');return;}
  const o=orders.find(x=>String(x.id)===String(id));
  if(!o){alert('Order details nahi mile.');return;}
  const current=String(o.status||'Order Placed').toLowerCase();
  if(['cancelled','delivered','completed'].includes(current)){alert('Ye order ab cancel nahi ho sakta.');return;}
  if(!confirm('Order #'+id+' cancel karna hai?'))return;
  try{
    if(db){
      const r=await db.from('orders').update({status:'Cancelled'}).eq('id',id);
      if(r.error){alert('Order cancel nahi hua. '+r.error.message);return;}
    }
    o.status='Cancelled';
    orders=orders.map(x=>String(x.id)===String(id)?{...x,status:'Cancelled'}:x);
    save();
    alert('✅ Order #'+id+' cancel ho gaya.');
    renderOrders();
  }catch(e){
    alert('Order cancel nahi hua. '+(e?.message||'Please try again.'));
  }
}
function updateLocationUI(){if(deliveryLocation)$('locationLabel').textContent=deliveryLocation.address||'Current location'}
function openLocation(){
  const m=$('locationModal');
  const a=$('addressInput');
  if(deliveryLocation?.address && a && !a.value) a.value=deliveryLocation.address;
  m.classList.add('show');
}
function closeLocation(){$('locationModal').classList.remove('show')}
function focusAddressInput(){
  const el=document.getElementById('addressInput');
  if(el){el.removeAttribute('readonly');el.removeAttribute('disabled');setTimeout(()=>el.focus(),50);}
}
document.addEventListener('DOMContentLoaded',()=>{
  const el=document.getElementById('addressInput');
  if(el){
    el.addEventListener('touchstart',()=>{el.removeAttribute('readonly');el.removeAttribute('disabled');},{passive:true});
    el.addEventListener('click',()=>el.focus());
  }
});
document.addEventListener('DOMContentLoaded',()=>{
  const a=document.getElementById('custAddress');
  if(a){
    a.removeAttribute('readonly');a.removeAttribute('disabled');
    a.addEventListener('touchstart',()=>{a.removeAttribute('readonly');a.removeAttribute('disabled');},{passive:true});
    a.addEventListener('click',()=>a.focus());
  }
});
async function autoDetectLocationOnOpen(){
  const top=$('topLocationText');
  // Home Screen/PWA reopen: restore saved location AND refresh store selection/products.
  // Permission is not requested again when the browser has already granted it.
  if(deliveryLocation && Number.isFinite(Number(deliveryLocation.latitude)) && Number.isFinite(Number(deliveryLocation.longitude))){
    if(top)top.textContent=String(deliveryLocation.address||'Current location').split(',').slice(0,2).join(', ').trim();
    try{
      await zinkitLoadDeliverySettings();
      zinkitUpdateSelectedStoreUI();
      await loadProducts();
    }catch(e){
      console.warn('Saved location restore refresh failed:',e&&e.message||e);
      try{await loadProducts();}catch(_e){}
    }
    return;
  }
  if(!navigator.geolocation){
    if(top)top.textContent='Select your Local Bazaar';
    return;
  }
  if(location.protocol!=='https:' && location.protocol!=='file:'){
    if(top)top.textContent='Use HTTPS for location';
    return;
  }
  if(top)top.textContent='Detecting location…';
  navigator.geolocation.getCurrentPosition(async pos=>{
    await saveDetectedLocation(pos.coords.latitude,pos.coords.longitude,'gps');
    const el=$('topLocationText');
    if(el)el.textContent=String(deliveryLocation?.address||'Current location').split(',').slice(0,2).join(', ').trim();
  },()=>{
    if(top)top.textContent='Select your Local Bazaar';
  },{enableHighAccuracy:true,timeout:15000,maximumAge:0});
}

function saveTypedLocation(){
  const a=$('addressInput').value.trim();
  if(!a){$('locStatus').textContent='Address likhiye.';return}
  deliveryLocation={address:a,source:'manual'};
  localStorage.setItem('zinkit_location',JSON.stringify(deliveryLocation));
  updateLocationUI();
  updateHomeLocation();
  $('custAddress').value=a;
  closeLocation();
}

function updateHomeLocation(){
  const el=document.getElementById('homeLocationText');
  if(el) el.textContent=deliveryLocation?.address || 'Add your location for faster delivery';
}
async function reverseLocation(lat,lon){
  let address=`Location (${lat.toFixed(5)}, ${lon.toFixed(5)})`;
  try{
    const r=await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}&zoom=18&addressdetails=1`,{headers:{Accept:"application/json"}});
    if(r.ok){
      const d=await r.json();
      address=d.display_name||address;
    }
  }catch(e){}
  return address;
}
async function saveDetectedLocation(lat,lon,source){
  const st=$('locStatus');
  st.textContent='📍 Address mil raha hai…';
  const address=await reverseLocation(lat,lon);
  deliveryLocation={address,latitude:lat,longitude:lon,source:source||'gps'};
  await zinkitLoadDeliverySettings();
  zinkitUpdateSelectedStoreUI();
  await loadProducts();
  localStorage.setItem('zinkit_location',JSON.stringify(deliveryLocation));
  const range=zinkitCheckDeliveryRange(lat,lon);
  const rangeText=!ZINKIT_DELIVERY_RESTRICTION_ENABLED
    ? '✅ Location set • Delivery restriction OFF'
    : range.allowed
      ? `✅ Location set • ${range.distance.toFixed(1)} km from ${ZINKIT_STORE_NAME}`
      : `❌ Outside ${zinkitMaxDeliveryRadiusKm()} km delivery range • ${range.distance.toFixed(1)} km`;
  st.textContent=rangeText;
  updateLocationUI();
  $('addressInput').value=address;
  $('custAddress').value=address;
  st.textContent=source==='ip'?'⚠️ Approx location set ho gayi. Exact ke liye GPS allow karein.':'✅ Location set ho gayi.';
  setTimeout(closeLocation,900);
}
async function useIpLocation(){
  const st=$('locStatus');
  st.textContent='🌐 Approx location detect ho rahi hai…';
  try{
    const r=await fetch('https://ipapi.co/json/',{cache:'no-store'});
    if(!r.ok)throw new Error('IP location failed');
    const d=await r.json();
    const lat=Number(d.latitude),lon=Number(d.longitude);
    if(!Number.isFinite(lat)||!Number.isFinite(lon))throw new Error('No coordinates');
    await saveDetectedLocation(lat,lon,'ip');
  }catch(e){
    st.textContent='Location detect nahi hui. Address manually save karein.';
  }
}
function useCurrentLocation(){
  const st=$('locStatus');
  if(!navigator.geolocation){
    st.textContent='📍 GPS available nahi hai. Address manually likhein.';
    return;
  }
  if(location.protocol!=='https:' && location.protocol!=='file:'){
    st.textContent='🔒 Location ke liye HTTPS website zaroori hai.';
    return;
  }
  st.textContent='📍 GPS location detect ho rahi hai… iPhone par Allow dabayein.';
  let done=false;
  const finish=(fn)=>{if(done)return;done=true;fn()};
  const success=async pos=>finish(async()=>{
    await saveDetectedLocation(pos.coords.latitude,pos.coords.longitude,'gps');
  });
  const fail=err=>finish(()=>{
    if(err && err.code===1){
      st.textContent='⚠️ Location permission blocked hai. iPhone Settings → Privacy & Security → Location Services → Safari/Browser → While Using App karein.';
    }else if(err && err.code===2){
      st.textContent='📡 GPS signal nahi mil raha. Wi‑Fi/Location ON karke phir try karein.';
    }else{
      st.textContent='⏳ GPS response nahi mila. Wi‑Fi/Location ON karke phir try karein.';
    }
  });
  try{
    navigator.geolocation.getCurrentPosition(success,fail,{
      enableHighAccuracy:true,
      timeout:20000,
      maximumAge:0
    });
  }catch(e){
    st.textContent='Location start nahi hui. Address manually likhein.';
  }
}
async function loadProducts(){
  const box=$('products');
  if(box)box.innerHTML='<div class="empty" style="grid-column:1/-1">Products load ho rahe hain…</div>';
  if(!db){if(box)box.innerHTML='<div class="empty">Supabase load nahi hua.</div>';return;}
  try{
    /* Robust product sync: avoid hard-coded column lists that break when optional
       columns (brand, Image3, Description, etc.) are absent in older schemas. */
    const selectedId=ZINKIT_ACTIVE_STORE_ID==null?'':String(ZINKIT_ACTIVE_STORE_ID).trim();
    const allStoresMode=ZINKIT_STORE_MATCH_SOURCE==='all-stores'||selectedId==='';
    let q=db.from('products').select('*').order('created_at',{ascending:false}).limit(2000);
    if(!allStoresMode && selectedId) q=q.or(`store_id.eq.${selectedId},store_id.is.null`);
    let r=await q;
    if(r.error){
      /* Older schemas may not have created_at; retry without ordering. */
      let q2=db.from('products').select('*').limit(2000);
      if(!allStoresMode && selectedId) q2=q2.or(`store_id.eq.${selectedId},store_id.is.null`);
      r=await q2;
    }
    if(r.error)throw r.error;
    let rows=Array.isArray(r.data)?r.data:[];
    /* Filter after retrieval for schema compatibility. Never mix another store's
       products into a selected store. Null store_id means a shared/global item. */
    rows=rows.filter(p=>p.is_active===undefined||p.is_active===null||p.is_active===true);
    if(!allStoresMode && selectedId){
      rows=rows.filter(p=>p.store_id==null||String(p.store_id)===selectedId);
    }
    products=rows;
    renderCategories();renderProducts();loadCustomerBrands();if(typeof loadPopularProductsCustomer==='function')loadPopularProductsCustomer();
    if(!products.length && box)box.innerHTML='<div class="empty">📦 Is store ke liye active product nahi mila. Admin mein product ka Store aur Active status check karein.</div>';
  }catch(e){
    console.warn('Products load failed:',e);
    if(box)box.innerHTML='<div class="empty" style="color:#c62828">Products load error: '+esc(e.message||e)+'</div>';
  }
}
updateLocationUI();refreshProfile();renderCategories();loadDynamicCategories();renderCart();renderOrders();updateCount();updateHomeLocation();startRiderContactRealtime();
zinkitLoadCancelSettings().then(()=>{if(typeof renderCart==='function')renderCart();if(typeof renderOrders==='function'&&document.getElementById('ordersScreen')?.classList.contains('show'))renderOrders();});
zinkitLoadDeliverySettings().then(async ()=>{
  const label=$('zinkitDeliveryRangeLabel');
  if(label)label.textContent=zinkitDeliveryRangeLabel();
  zinkitUpdateSelectedStoreUI();
  await loadProducts();
}).catch(()=>loadProducts());
// Refresh product list periodically so Admin uploads appear without reopening
// the Customer App. Existing cart/order/tracking state is preserved.
setInterval(()=>{ loadProducts().catch(()=>{}); }, 60000);
setTimeout(resumeCustomerLiveTracking,600);

;

/* Customer -> Supabase live location bridge. It starts after a successful order and can be resumed from Orders. */
let customerLiveWatchId=null;
let customerLiveOrderId=null;
function showLiveTracking(orderId){
  customerLiveOrderId=orderId;
  const c=document.getElementById('liveTrackingCard'); if(c)c.classList.add('show');
  const t=document.getElementById('liveTrackingText'); if(t)t.textContent='Order #'+orderId+' ke liye live location ON hai.'; if(typeof renderFloatingCart==='function')renderFloatingCart();
}
async function pushCustomerLocation(lat,lon){
  if(!db||!customerLiveOrderId)return;
  try{
    const {error}=await db.rpc('customer_update_order_location',{
      p_order_id:Number(customerLiveOrderId),
      p_latitude:Number(lat),
      p_longitude:Number(lon)
    });
    if(error) console.warn('Live location update failed:',error.message);
  }catch(e){console.warn('Live location update failed:',e)}
}
function startCustomerLiveTracking(orderId){
  if(!orderId||!navigator.geolocation)return;
  showLiveTracking(orderId);
  if(customerLiveWatchId!==null)navigator.geolocation.clearWatch(customerLiveWatchId);
  customerLiveWatchId=navigator.geolocation.watchPosition(pos=>{
    const lat=pos.coords.latitude,lon=pos.coords.longitude;
    const t=document.getElementById('liveTrackingText'); if(t)t.textContent='🟢 Live location updating • '+lat.toFixed(5)+', '+lon.toFixed(5);
    pushCustomerLocation(lat,lon);
  },()=>{}, {enableHighAccuracy:true,maximumAge:5000,timeout:20000});
}
function stopCustomerLiveTracking(){
  if(customerLiveWatchId!==null)navigator.geolocation.clearWatch(customerLiveWatchId);
  customerLiveWatchId=null;
  const t=document.getElementById('liveTrackingText'); if(t)t.textContent='Live location stopped.'; if(typeof renderFloatingCart==='function')renderFloatingCart();
}
function resumeCustomerLiveTracking(){
  try{
    const active=(Array.isArray(orders)?orders:[]).find(o=>o&&o.id&& !['Delivered','Cancelled','Canceled','Order Cancelled'].includes(String(o.status||'')));
    if(active?.id) startCustomerLiveTracking(active.id);
  }catch(e){}
}

const _oldPlaceOrder=window.placeOrder;
if(typeof _oldPlaceOrder==='function'){
  window.placeOrder=async function(ev){
    const beforeCount=Array.isArray(orders)?orders.length:0;
    const result=await _oldPlaceOrder.apply(this,arguments);
    setTimeout(()=>{
      if(Array.isArray(orders)&&orders.length>beforeCount){
        const latest=orders[0]; if(latest?.id)startCustomerLiveTracking(latest.id);
      }
    },300);
    return result;
  };
}

;

(function(){
  function onlyDigits(v){return String(v||'').replace(/\D/g,'').slice(0,10)}
  function openLogin(){
    var overlay=document.getElementById('zinkitAlwaysLogin');
    if(!overlay)return;
    overlay.style.display='flex';
    document.body.style.overflow='hidden';
    var inp=document.getElementById('zinkitAlwaysMobile');
    if(inp){inp.value='';setTimeout(function(){try{inp.focus()}catch(e){}},100)}
  }
  function continueLogin(){
    var inp=document.getElementById('zinkitAlwaysMobile');
    var err=document.getElementById('zinkitAlwaysErr');
    var phone=onlyDigits(inp&&inp.value);
    if(!/^[0-9]{10}$/.test(phone)){if(err)err.textContent='10-digit mobile number bhariye.';return}
    localStorage.setItem('zinkit_customer_mobile',phone);
    var old=document.getElementById('custMobile');
    if(old)old.value=phone;
    var overlay=document.getElementById('zinkitAlwaysLogin');
    if(overlay)overlay.style.display='none';
    document.body.style.overflow='';
    if(typeof window.refreshProfile==='function')try{window.refreshProfile()}catch(e){}
  }
  document.addEventListener('DOMContentLoaded',function(){
    openLogin();
    var inp=document.getElementById('zinkitAlwaysMobile');
    if(inp)inp.addEventListener('input',function(){inp.value=onlyDigits(inp.value);});
    var btn=document.getElementById('zinkitAlwaysContinue');
    if(btn)btn.addEventListener('click',continueLogin);
    if(inp)inp.addEventListener('keydown',function(e){if(e.key==='Enter')continueLogin();});
  });
  window.zinkitOpenAlwaysLogin=openLogin;
})();

;
if("serviceWorker" in navigator){window.addEventListener("load",async()=>{try{const reg=await navigator.serviceWorker.register("./sw.js?v=zinkit-customer-v26");if(reg.waiting)reg.waiting.postMessage({type:"SKIP_WAITING"});reg.addEventListener("updatefound",()=>{const nw=reg.installing;if(!nw)return;nw.addEventListener("statechange",()=>{if(nw.state==="installed"&&navigator.serviceWorker.controller)nw.postMessage({type:"SKIP_WAITING"})})});let reloaded=false;navigator.serviceWorker.addEventListener("controllerchange",()=>{if(!reloaded){reloaded=true;window.location.reload()}})}catch(e){console.warn("PWA update check failed",e)}})}
;

(function(){
  function goProductTop(){
    requestAnimationFrame(function(){
      window.scrollTo(0,0);
      document.documentElement.scrollTop=0;
      document.body.scrollTop=0;
      var main=document.querySelector('main');
      if(main) main.scrollTop=0;
      var app=document.querySelector('.app,.container,#app');
      if(app && typeof app.scrollTop==='number') app.scrollTop=0;
    });
  }

  document.addEventListener('click', function(e){
    var el=e.target && e.target.closest ? e.target.closest(
      '[data-product-id], .product-card, .product, .product-item, .related-product, .product-tile'
    ) : null;
    if(!el) return;

    // Do not interfere with quantity/cart buttons inside a product card.
    if(e.target.closest && e.target.closest('button, input, select, textarea, a')) return;

    setTimeout(goProductTop, 0);
  }, true);

  // Also make the common detail-opening functions land at the top.
  ['openProductDetail','openProduct','showProductDetail'].forEach(function(name){
    if(typeof window[name] === 'function' && !window[name].__mdMunnaTopFixed){
      var original=window[name];
      var wrapped=function(){
        var result=original.apply(this,arguments);
        setTimeout(goProductTop,0);
        return result;
      };
      wrapped.__mdMunnaTopFixed=true;
      window[name]=wrapped;
    }
  });
})();

;

document.addEventListener('DOMContentLoaded',()=>{
  const p=document.getElementById('custMobile');
  if(p){
    const saved=(localStorage.getItem('zinkit_customer_mobile')||'').replace(/\D/g,'').slice(0,10);
    if(saved)p.value=saved;
    p.addEventListener('input',()=>{
      p.value=p.value.replace(/\D/g,'').slice(0,10);
      localStorage.setItem('zinkit_customer_mobile',p.value);
    });
  }
});

;
document.addEventListener('DOMContentLoaded',()=>{initLocalBazaar();autoDetectLocationOnOpen();});
;

async function loadFeaturedFoodCustomer(){
  try{
    if(!db)return; const r=await db.from('app_settings').select('value').eq('key','featured_food').maybeSingle();
    if(r.error||!r.data?.value)return; let d={}; try{d=JSON.parse(r.data.value)||{};}catch(e){return;}
    const sec=document.getElementById('featuredFoodSection'); if(!sec)return; sec.style.display=d.enabled===false?'none':''; if(d.enabled===false)return;
    const title=document.getElementById('featuredFoodTitle'); if(title)title.textContent=d.title||'Featured Food';
    const va=document.getElementById('featuredFoodViewAll'); if(va){va.textContent=d.view_all_text||'View All →'; va.onclick=()=>selectCategory(d.view_all_category||'Hotel');}
    const wrap=document.getElementById('featuredFoodChips'); if(wrap){wrap.innerHTML=''; (Array.isArray(d.chips)?d.chips:[]).forEach(x=>{if(!x?.text||!x?.category)return; const b=document.createElement('button');b.className='foodChip';b.type='button';b.textContent=x.text;b.onclick=()=>selectCategory(x.category);wrap.appendChild(b);});}
  }catch(e){}
}
document.addEventListener('DOMContentLoaded',()=>setTimeout(loadFeaturedFoodCustomer,250));

;

function zinkitPromoEsc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function zinkitPromoMediaMarkup(d,compact){
  const video=d.video_url?`<video src="${zinkitPromoEsc(d.video_url)}" muted playsinline loop controls preload="metadata" aria-label="${zinkitPromoEsc(d.name||'Promotion video')}" onclick="event.stopPropagation()"></video>`:'';
  const photo=d.image_url?`<img src="${zinkitPromoEsc(d.image_url)}" alt="${zinkitPromoEsc(d.name||'Promotion')}" loading="lazy">`:'';
  const media=compact?(photo||video):(video||photo);
  const logo=d.logo_url?`<img class="ffPromoLogo" src="${zinkitPromoEsc(d.logo_url)}" alt="${zinkitPromoEsc(d.name||'Logo')}" loading="lazy">`:'';
  if(compact)return `${d.logo_url?`<img class="ffPromoLogo" src="${zinkitPromoEsc(d.logo_url)}" alt="${zinkitPromoEsc(d.name||'Logo')}" loading="lazy">`:''}${media}<div class="ffSideName">${zinkitPromoEsc(d.name||'')}</div>${d.caption?`<div class="ffSideCaption">${zinkitPromoEsc(d.caption)}</div>`:''}`;
  return `<div class="ffPromoTopInner">${media?media.replace('<img ','<img class="ffPromoTopMedia" ').replace('<video ','<video class="ffPromoTopMedia" '):''}<div class="ffPromoTopText">${logo}${`<b>${zinkitPromoEsc(d.name||'')}</b>`}${d.caption?`<small>${zinkitPromoEsc(d.caption)}</small>`:''}</div></div>`;
}
async function loadFeaturedFoodPromoMediaCustomer(){
  try{
    if(!db)return;const r=await db.from('app_settings').select('value').eq('key','featured_food_media').maybeSingle();if(r.error||!r.data?.value)return;
    let d={};try{d=typeof r.data.value==='string'?JSON.parse(r.data.value):r.data.value;}catch(e){return;}
    const top=document.getElementById('featuredFoodPromoTop'),side=document.getElementById('featuredFoodPromoSide');
    if(!d||d.enabled===false||(!d.image_url&&!d.video_url&&!d.logo_url&&!d.name)){if(top)top.style.display='none';if(side)side.style.display='none';return;}
    if(top){top.innerHTML=zinkitPromoMediaMarkup(d,false);top.style.display='block';top.onclick=()=>selectCategory(d.target_type||'Hotel');top.style.cursor='pointer';}
    if(side){side.innerHTML=zinkitPromoMediaMarkup(d,true);side.style.display='block';side.onclick=()=>selectCategory(d.target_type||'Hotel');side.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();selectCategory(d.target_type||'Hotel');}};}
  }catch(e){console.warn('Featured Food promo media load skipped',e);}
}
document.addEventListener('DOMContentLoaded',()=>setTimeout(loadFeaturedFoodPromoMediaCustomer,400));
// Refresh promotional media occasionally so Admin changes appear without clearing customer state.
setInterval(()=>loadFeaturedFoodPromoMediaCustomer(),120000);
// Independent Festival section: separate app_settings key; does not modify Featured Food.

// Festival Status Stories: independent setting, supports photo, video, and existing product cards.
let zinkitFestivalStatuses=[];let zinkitFestivalStatusIndex=0;
function renderFestivalStatusStories(){const box=document.getElementById('festivalStatusStories');if(!box)return;const items=(zinkitFestivalStatuses||[]).filter(x=>x&&x.enabled!==false);if(!items.length){box.style.display='none';box.innerHTML='';return;}const festivalSection=document.getElementById('festivalPromoSection');if(festivalSection)festivalSection.style.display='block';box.style.display='flex';box.innerHTML=items.map((it,i)=>{const src=it.image_url||it.media_url||'';const thumb=it.media_type==='video'&&src?`<video src="${escapeHtml(src)}" muted playsinline></video>`:(src?`<img src="${escapeHtml(src)}" alt="">`:'<div style="width:100%;height:100%;display:grid;place-items:center;background:white;border-radius:50%;font-size:24px">🛍️</div>');return `<button class="festivalStory" type="button" onclick="event.stopPropagation();openFestivalStatusViewer(${i})"><span class="festivalStoryRing">${thumb}</span><span class="festivalStoryName">${escapeHtml(it.caption||it.product_name||'Festival')}</span></button>`;}).join('');}
function currentFestivalStatusItems(){return (zinkitFestivalStatuses||[]).filter(x=>x&&x.enabled!==false);}
function openFestivalStatusViewer(i){const items=currentFestivalStatusItems();if(!items.length)return;zinkitFestivalStatusIndex=Math.max(0,Math.min(i,items.length-1));renderFestivalStatusViewer();const v=document.getElementById('festivalStatusViewer');if(v)v.style.display='flex';}
function closeFestivalStatusViewer(){const v=document.getElementById('festivalStatusViewer');if(v)v.style.display='none';const media=document.getElementById('festivalStatusViewerMedia');if(media)media.querySelectorAll('video').forEach(x=>x.pause());}
function previousFestivalStatus(){const items=currentFestivalStatusItems();if(items.length){zinkitFestivalStatusIndex=(zinkitFestivalStatusIndex-1+items.length)%items.length;renderFestivalStatusViewer();}}
function nextFestivalStatus(){const items=currentFestivalStatusItems();if(items.length){zinkitFestivalStatusIndex=(zinkitFestivalStatusIndex+1)%items.length;renderFestivalStatusViewer();}}
function renderFestivalStatusViewer(){const items=currentFestivalStatusItems(),it=items[zinkitFestivalStatusIndex];if(!it)return;const media=document.getElementById('festivalStatusViewerMedia'),cap=document.getElementById('festivalStatusViewerCaption'),prod=document.getElementById('festivalStatusViewerProduct');if(!media||!cap||!prod)return;const src=it.media_url||it.image_url||'';if(it.media_type==='video'&&src)media.innerHTML=`<video class="fsViewMedia" src="${escapeHtml(src)}" controls autoplay playsinline></video>`;else if(src)media.innerHTML=`<img class="fsViewMedia" src="${escapeHtml(src)}" alt="${escapeHtml(it.caption||'Festival status')}">`;else media.innerHTML='<div class="fsViewMedia" style="display:grid;place-items:center;font-size:48px">🛍️</div>';cap.textContent=it.caption||it.product_name||'Festival Status';if(it.media_type==='product'){prod.innerHTML=`<div class="fsViewProduct">${it.image_url?`<img src="${escapeHtml(it.image_url)}" alt="">`:'<div style="font-size:30px">🛍️</div>'}<div style="flex:1;min-width:0"><b>${escapeHtml(it.product_name||'Product')}</b><div style="margin-top:4px">${it.product_price!=null?'₹'+escapeHtml(it.product_price):''}</div></div><button type="button" onclick="closeFestivalStatusViewer();selectCategory(${JSON.stringify(it.category||'All')})">View Product</button></div>`;}else prod.innerHTML='';}
async function loadFestivalStatusesCustomer(){try{if(!db)return;const r=await db.from('app_settings').select('value').eq('key','festival_statuses').maybeSingle();if(r.error||!r.data?.value){zinkitFestivalStatuses=[];renderFestivalStatusStories();return;}let d=typeof r.data.value==='string'?JSON.parse(r.data.value):r.data.value;zinkitFestivalStatuses=Array.isArray(d)?d:[];renderFestivalStatusStories();}catch(e){console.warn('Festival status load skipped',e);}}
document.addEventListener('DOMContentLoaded',()=>setTimeout(loadFestivalStatusesCustomer,650));setInterval(loadFestivalStatusesCustomer,120000);

async function loadFestivalPromoCustomer(){
  try{
    if(!db)return;const r=await db.from('app_settings').select('value').eq('key','festival_media').maybeSingle();
    const sec=document.getElementById('festivalPromoSection'),content=document.getElementById('festivalPromoContent'),heading=document.getElementById('festivalPromoHeading');
    if(!sec||!content)return;if(r.error||!r.data?.value){const storyItems=(zinkitFestivalStatuses||[]).some(x=>x&&x.enabled!==false);sec.style.display=storyItems?'block':'none';return;}
    let d={};try{d=typeof r.data.value==='string'?JSON.parse(r.data.value):r.data.value;}catch(e){sec.style.display='none';return;}
    if(!d||d.enabled===false||(!d.name&&!d.image_url&&!d.video_url&&!d.logo_url)){const storyItems=(zinkitFestivalStatuses||[]).some(x=>x&&x.enabled!==false);sec.style.display=storyItems?'block':'none';return;}
    if(heading)heading.textContent=d.title||'🎉 Festival Special';
    content.innerHTML=zinkitPromoMediaMarkup(d,false);
    sec.style.display='block';sec.onclick=()=>selectCategory(d.target_type||'All');sec.style.cursor='pointer';
    sec.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();selectCategory(d.target_type||'All');}};
    sec.setAttribute('role','button');sec.setAttribute('tabindex','0');sec.setAttribute('aria-label',d.title||'Festival Special');
  }catch(e){console.warn('Festival promo load skipped',e);}
}
document.addEventListener('DOMContentLoaded',()=>setTimeout(loadFestivalPromoCustomer,550));
setInterval(()=>loadFestivalPromoCustomer(),120000);

;

/* ZinKit CUSTOMER -> RIDER live tracking.
   Rider GPS is stored in public.rider_locations.
   Customer reads it through the secure get_rider_location_for_order RPC.
*/
let riderLiveTimer=null;
let riderLiveOrderId=null;
let riderLiveMobile=null;

function showRiderLiveTracking(orderId){
  riderLiveOrderId=orderId;
  const c=document.getElementById('liveTrackingCard');
  if(c)c.classList.add('show');
  const t=document.getElementById('liveTrackingText');
  if(t)t.textContent='🚚 Order #'+orderId+' • Rider location check ho rahi hai…';
}

function hideRiderMap(){
  const w=document.getElementById('riderLiveMapWrap');
  const l=document.getElementById('riderLiveMapLink');
  if(w)w.style.display='none';
  if(l)l.style.display='none';
}

let zinkitLeafletPromise=null;
const zinkitRiderMaps={};

function loadZinKitLeaflet(){
  if(window.L)return Promise.resolve(window.L);
  if(zinkitLeafletPromise)return zinkitLeafletPromise;
  zinkitLeafletPromise=new Promise((resolve,reject)=>{
    const old=document.querySelector('script[data-zinkit-leaflet]');
    if(old){
      old.addEventListener('load',()=>resolve(window.L));
      old.addEventListener('error',reject);
      return;
    }
    const sc=document.createElement('script');
    sc.src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
    sc.async=true;
    sc.dataset.zinkitLeaflet='1';
    sc.onload=()=>window.L?resolve(window.L):reject(new Error('Leaflet load failed'));
    sc.onerror=()=>reject(new Error('Leaflet network error'));
    document.head.appendChild(sc);
  });
  return zinkitLeafletPromise;
}

function makeRiderIcon(L){
  const svg=`<svg class="zinkit-rider-svg" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
    <circle cx="50" cy="50" r="48" fill="#dff6cf"/>
    <rect x="58" y="18" width="27" height="31" rx="5" fill="#168b2d"/>
    <rect x="62" y="22" width="19" height="7" rx="2" fill="#39a94b"/>
    <circle cx="47" cy="33" r="10" fill="#f5c79a"/>
    <path d="M36 31c1-10 20-14 25-2l-2 6H37z" fill="#ffd54f"/>
    <path d="M36 47c8-6 18-6 27 1l6 15H31z" fill="#ffd43b"/>
    <path d="M31 60h38l10 10H25z" fill="#30343b"/>
    <circle cx="31" cy="74" r="9" fill="#222"/><circle cx="31" cy="74" r="4" fill="#aaa"/>
    <circle cx="73" cy="74" r="9" fill="#222"/><circle cx="73" cy="74" r="4" fill="#aaa"/>
    <path d="M60 55l14 8-5 7-15-8z" fill="#f5c79a"/>
  </svg>`;
  return L.divIcon({
    className:'zinkit-rider-marker',
    html:'<div class="zinkit-rider-bubble"><div class="zinkit-rider-art">'+svg+'</div><div class="zinkit-rider-label">RIDER</div></div>',
    iconSize:[68,78], iconAnchor:[34,44], popupAnchor:[0,-38]
  });
}
function makeCustomerIcon(L){
  return L.divIcon({
    className:'zinkit-customer-marker',
    html:'<div class="zinkit-customer-pin"><div class="zinkit-customer-pin-inner">📍</div></div>',
    iconSize:[58,66],
    iconAnchor:[29,62],
    popupAnchor:[0,-62]
  });
}

async function createOrUpdateRiderLeafletMap(id,lat,lon,updatedAt,destLat,destLon){
  const el=document.getElementById(id); if(!el||!window.L)return;
  const L=window.L, hasDest=Number.isFinite(Number(destLat))&&Number.isFinite(Number(destLon));
  const dLat=Number(destLat), dLon=Number(destLon);
  let state=zinkitRiderMaps[id];

  if(!state){
    el.innerHTML='<div class="zinkit-blinkit-map-shell"><div class="zinkit-blinkit-top"><small>ORDER IS ON THE WAY</small><strong>Rider is on the way</strong></div><div class="zinkit-map-canvas" style="position:absolute;inset:0"></div><div class="zinkit-blinkit-bottom"><span class="dot"></span><div><b>🛵 Rider → 📍 Drop location</b><span id="zinkitEta-'+id+'">Live location updating</span></div></div></div>';
    const canvas=el.querySelector('.zinkit-map-canvas');
    const map=L.map(canvas,{zoomControl:false,attributionControl:true,preferCanvas:false}).setView([lat,lon],16);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(map);
    const riderMarker=L.marker([lat,lon],{icon:makeRiderIcon(L),zIndexOffset:5000,keyboard:false}).addTo(map);
    riderMarker.bindTooltip('🛵 Rider', {permanent:true,direction:'top',offset:[0,-38],className:'zinkit-rider-tooltip'});
    let customerMarker=null, routeLine=null;
    if(hasDest){
      customerMarker=L.marker([dLat,dLon],{icon:makeCustomerIcon(L),zIndexOffset:4000,keyboard:false}).addTo(map);
      customerMarker.bindTooltip('📍 Drop location', {permanent:true,direction:'top',offset:[0,-48],className:'zinkit-customer-tooltip'});
    }
    state={map,riderMarker,customerMarker,routeLine,destLat:hasDest?dLat:null,destLon:hasDest?dLon:null,lastRouteKey:null,lastRouteAt:0};
    zinkitRiderMaps[id]=state;
    setTimeout(()=>map.invalidateSize(),150);
  }else{
    state.riderMarker.setLatLng([lat,lon]);
    if(hasDest){
      if(!state.customerMarker){
        state.customerMarker=L.marker([dLat,dLon],{icon:makeCustomerIcon(L),zIndexOffset:4000,keyboard:false}).addTo(state.map);
        state.customerMarker.bindTooltip('📍 Drop location', {permanent:true,direction:'top',offset:[0,-48],className:'zinkit-customer-tooltip'});
      }else state.customerMarker.setLatLng([dLat,dLon]);
      state.destLat=dLat; state.destLon=dLon;
    }
    setTimeout(()=>state.map.invalidateSize(),40);
  }

  const routeKey=hasDest?lat.toFixed(4)+','+lon.toFixed(4)+'>'+dLat.toFixed(4)+','+dLon.toFixed(4):null;
  if(hasDest && (!state.lastRouteKey || routeKey!==state.lastRouteKey || Date.now()-state.lastRouteAt>15000)){
    state.lastRouteKey=routeKey; state.lastRouteAt=Date.now();
    try{
      const url='https://router.project-osrm.org/route/v1/driving/'+lon+','+lat+';'+dLon+','+dLat+'?overview=full&geometries=geojson';
      const rr=await fetch(url,{cache:'no-store'}); const data=await rr.json();
      if(data.routes&&data.routes[0]&&data.routes[0].geometry){
        const pts=data.routes[0].geometry.coordinates.map(p=>[p[1],p[0]]);
        if(!state.routeLine)state.routeLine=L.polyline(pts,{color:'#1976d2',weight:5,opacity:.95,lineCap:'round',lineJoin:'round'}).addTo(state.map);
        else state.routeLine.setLatLngs(pts);
        const km=Number(data.routes[0].distance||0)/1000;
        const mins=Math.max(1,Math.round((Number(data.routes[0].duration||0))/60));
        const eta=document.getElementById('zinkitEta-'+id); if(eta)eta.textContent='Approx. '+mins+' min • '+km.toFixed(1)+' km away';
      }
    }catch(e){
      if(!state.routeLine)state.routeLine=L.polyline([[lat,lon],[dLat,dLon]],{color:'#1976d2',weight:5,opacity:.85,lineCap:'round'}).addTo(state.map);
    }
  }

  if(hasDest){
    const b=L.latLngBounds([[lat,lon],[dLat,dLon]]);
    state.map.fitBounds(b,{padding:[70,95],maxZoom:17});
  }else{
    state.map.setView([lat,lon],16);
  }
  setTimeout(()=>state.map.invalidateSize(true),120);
  const when=updatedAt?new Date(updatedAt).toLocaleTimeString('en-IN'):'just now';
  state.riderMarker.bindPopup('<b>🛵 ZinKit Rider</b><br>Live location<br>Updated '+when);
}

async function updateRiderMap(lat,lon,updatedAt,destLat,destLon){
  const la=Number(lat),lo=Number(lon); if(!Number.isFinite(la)||!Number.isFinite(lo))return;
  const openUrl='https://www.google.com/maps?q='+encodeURIComponent(la+','+lo);
  const w=document.getElementById('riderLiveMapWrap'), link=document.getElementById('riderLiveMapLink'), t=document.getElementById('liveTrackingText');
  if(w)w.style.display='block'; if(link){link.href=openUrl;link.style.display='inline-block'}
  const ow=document.getElementById('orderLiveMapWrap'), ol=document.getElementById('orderLiveMapLink'), os=document.getElementById('orderLiveStatus');
  if(ow)ow.style.display='block'; if(ol){ol.href=openUrl;ol.style.display='inline-block'}
  const when=updatedAt?new Date(updatedAt).toLocaleTimeString('en-IN'):'just now';
  const msg='🟢 Rider LIVE • Updated '+when; if(t)t.textContent=msg; if(os)os.textContent=msg;
  try{
    await loadZinKitLeaflet();
    await createOrUpdateRiderLeafletMap('riderLiveMap',la,lo,updatedAt,destLat,destLon);
    await createOrUpdateRiderLeafletMap('orderLiveMap',la,lo,updatedAt,destLat,destLon);
  }catch(e){ if(t)t.textContent=msg+' • Map loading…'; if(os)os.textContent=msg+' • Map loading…'; }
}

async function fetchRiderLiveLocation(){
  if(!db||!riderLiveOrderId)return;

  const t=document.getElementById('liveTrackingText');
  const orderStatus=document.getElementById('orderLiveStatus');
  const orderId=Number(riderLiveOrderId);

  try{
    // Always read the exact order first so the correct customer mobile + rider
    // are used, even if localStorage contains an old mobile number.
    const ordRes=await db.from('orders')
      .select('id,mobile,rider_id,status,latitude,longitude')
      .eq('id',orderId)
      .maybeSingle();

    if(ordRes.error) throw ordRes.error;
    const ord=ordRes.data;

    if(!ord){
      const msg='⚠️ Order details nahi mile.';
      if(t)t.textContent=msg;
      if(orderStatus)orderStatus.textContent=msg;
      return;
    }

    const status=String(ord.status||'').trim().toLowerCase();
    if(['delivered','cancelled','canceled','order cancelled'].includes(status)){
      const msg='ℹ️ Order complete/cancelled hai. Live tracking band hai.';
      if(t)t.textContent=msg;
      if(orderStatus)orderStatus.textContent=msg;
      hideRiderMap();
      const ow=document.getElementById('orderLiveMapWrap');
      if(ow)ow.style.display='none';
      return;
    }

    if(!ord.rider_id){
      const msg='🟡 Rider abhi order accept nahi kiya hai.';
      if(t)t.textContent=msg;
      if(orderStatus)orderStatus.textContent=msg;
      hideRiderMap();
      const ow=document.getElementById('orderLiveMapWrap');
      if(ow)ow.style.display='none';
      return;
    }

    const orderMobile=String(ord.mobile||riderLiveMobile||$('custMobile')?.value||localStorage.getItem('zinkit_customer_mobile')||'')
      .replace(/\D/g,'').slice(-10);

    if(!/^[0-9]{10}$/.test(orderMobile)){
      const msg='📱 Order ka customer mobile number valid nahi hai.';
      if(t)t.textContent=msg;
      if(orderStatus)orderStatus.textContent=msg;
      return;
    }

    const rpcResult=await db.rpc('get_rider_location_for_order',{
      p_order_id:orderId,
      p_mobile:orderMobile
    });

    if(rpcResult.error) throw rpcResult.error;

    let row=Array.isArray(rpcResult.data)?rpcResult.data[0]:rpcResult.data;

    // DB fallback: use the rider_id assigned to this exact order.
    if(!row){
      try{
        const rl=await db.from('rider_locations')
          .select('latitude,longitude,updated_at')
          .eq('rider_id',ord.rider_id)
          .order('updated_at',{ascending:false})
          .limit(1);
        if(!rl.error && Array.isArray(rl.data) && rl.data.length) row=rl.data[0];
      }catch(e){}
    }

    let destLat=Number(ord.latitude), destLon=Number(ord.longitude);
    if(!Number.isFinite(destLat)||!Number.isFinite(destLon)){
      try{
        const saved=JSON.parse(localStorage.getItem('zinkit_location')||'null');
        if(saved && Number.isFinite(Number(saved.latitude)) && Number.isFinite(Number(saved.longitude))){
          destLat=Number(saved.latitude); destLon=Number(saved.longitude);
        }
      }catch(e){}
    }

    if(row && Number.isFinite(Number(row.latitude)) && Number.isFinite(Number(row.longitude))){
      updateRiderMap(row.latitude,row.longitude,row.updated_at,destLat,destLon);
    }else{
      hideRiderMap();
      const ow=document.getElementById('orderLiveMapWrap');
      if(ow)ow.style.display='none';
      const msg='🟡 Rider assign ho gaya hai, GPS location ka wait hai…';
      if(t)t.textContent=msg;
      if(orderStatus)orderStatus.textContent=msg;
    }
  }catch(e){
    const msg='⚠️ Live rider location error: '+(e?.message||'fetch failed');
    if(t)t.textContent=msg;
    if(orderStatus)orderStatus.textContent=msg;
  }
}

async function startRiderLiveTracking(orderId, mobileOverride){
  if(!orderId)return;
  riderLiveOrderId=Number(orderId);
  riderLiveMobile=String(mobileOverride||$('custMobile')?.value||localStorage.getItem('zinkit_customer_mobile')||'')
    .replace(/\D/g,'').slice(-10);

  showRiderLiveTracking(riderLiveOrderId);

  if(riderLiveTimer)clearInterval(riderLiveTimer);

  // Fetch immediately, then refresh every 3 seconds.
  await fetchRiderLiveLocation();
  riderLiveTimer=setInterval(()=>{
    if(riderLiveOrderId) fetchRiderLiveLocation();
  },3000);

  window.scrollTo({top:0,behavior:'smooth'});
}

function startCustomerLiveTracking(orderId){
  // Backward-compatible function name; customer GPS is not used for rider tracking.
  startRiderLiveTracking(orderId);
}

function stopCustomerLiveTracking(){
  if(riderLiveTimer)clearInterval(riderLiveTimer);
  riderLiveTimer=null;
  riderLiveOrderId=null;
  hideRiderMap();
  const t=document.getElementById('liveTrackingText');
  if(t)t.textContent='Rider live tracking stopped.';
}

function resumeCustomerLiveTracking(){
  try{
    const active=(Array.isArray(orders)?orders:[]).find(o=>o&&o.id&&
      !['Delivered','Cancelled','Canceled','Order Cancelled'].includes(String(o.status||'')));
    if(active?.id)startRiderLiveTracking(active.id);
  }catch(e){}
}

const _oldPlaceOrderRiderLive=window.placeOrder;
if(typeof _oldPlaceOrderRiderLive==='function'){
  window.placeOrder=async function(ev){
    const beforeCount=Array.isArray(orders)?orders.length:0;
    const result=await _oldPlaceOrderRiderLive.apply(this,arguments);
    setTimeout(()=>{
      if(Array.isArray(orders)&&orders.length>beforeCount){
        const latest=orders[0];
        if(latest?.id)startRiderLiveTracking(latest.id);
      }
    },500);
    return result;
  };
}

;

async function loadFreshFoodHeroCustomer(){
  try{
    if(!db)return;
    const r=await db.from('app_settings').select('value').eq('key','fresh_food_hero').maybeSingle();
    if(r.error||!r.data?.value)return;
    const d=JSON.parse(r.data.value);
    const hero=$('freshFoodHero');if(!hero)return;
    if(d.enabled===false){hero.style.display='none';return;}
    hero.style.display='';
    const title=$('ffCustomerTitle');if(title)title.innerHTML=(typeof escapeHtml==='function'?escapeHtml(d.title||'Fresh Food'):String(d.title||'Fresh Food'))+'<br>'+(typeof escapeHtml==='function'?escapeHtml(d.subtitle||'Now at Your Doorstep'):String(d.subtitle||'Now at Your Doorstep'));
    const desc=$('ffCustomerDescription');if(desc)desc.textContent=d.description||'';
    const btn=$('ffCustomerButton');if(btn){btn.textContent=d.button_text||'Order Now →';btn.onclick=function(){selectCategory(d.category||'Biryani');$('products')?.scrollIntoView({behavior:'smooth'});};}
    const media=$('ffCustomerMedia');if(!media)return;
    const url=d.media_url||d.image_url||'';media.innerHTML='';hero.style.backgroundImage='';
    if(url && d.media_type==='video'){
      const v=document.createElement('video');v.src=url;v.autoplay=true;v.muted=true;v.defaultMuted=true;v.loop=true;v.playsInline=true;v.setAttribute('playsinline','');v.setAttribute('webkit-playsinline','');v.preload='auto';v.setAttribute('aria-label','Fresh Food banner video');v.style.cssText='width:100%;height:100%;object-fit:cover;display:block;';media.appendChild(v);
      const play=v.play();if(play&&play.catch)play.catch(()=>{});
    }else if(url){
      const img=document.createElement('img');img.src=url;img.alt='Fresh Food banner';img.style.cssText='width:100%;height:100%;object-fit:cover;display:block;';media.appendChild(img);
    }
  }catch(e){console.log('Fresh Food banner load failed',e);}
}
document.addEventListener('DOMContentLoaded',loadFreshFoodHeroCustomer);

;

document.addEventListener('DOMContentLoaded', async function(){
  try{
    if(typeof db==='undefined'||!db)return;
    const r=await db.from('app_settings').select('key,value').in('key',['fresh_food_banner_title','fresh_food_banner_subtitle','fresh_food_banner_image','fresh_food_banner_video','fresh_food_banner_media_type','fresh_food_banner_button','fresh_food_banner_active','fresh_food_banner_video_autoplay']); if(r.error)throw r.error;
    const m=Object.fromEntries((r.data||[]).map(x=>[x.key,x.value])); if(String(m.fresh_food_banner_active??'true').toLowerCase()==='false'){const hero0=document.getElementById('freshFoodHero');if(hero0)hero0.style.display='none';return;}
    const hero=document.getElementById('freshFoodHero'),media=document.getElementById('ffCustomerMedia'),title=document.getElementById('ffCustomerTitle'),desc=document.getElementById('ffCustomerDescription'),btn=document.getElementById('ffCustomerButton'); if(!hero||!media)return; hero.style.display='';
    if(title)title.textContent=m.fresh_food_banner_title||'Fresh Food'; if(desc)desc.textContent=m.fresh_food_banner_subtitle||'Fresh food, fast delivery'; if(btn&&m.fresh_food_banner_button)btn.textContent=m.fresh_food_banner_button+' →';
    media.innerHTML='';
    if(m.fresh_food_banner_media_type==='video'&&m.fresh_food_banner_video){ const v=document.createElement('video');v.src=m.fresh_food_banner_video;v.muted=true;v.playsInline=true;v.loop=true;v.autoplay=String(m.fresh_food_banner_video_autoplay??'true').toLowerCase()!=='false';v.controls=false;v.preload='auto';v.setAttribute('playsinline','');v.setAttribute('webkit-playsinline','');v.style.cssText='width:100%;height:100%;object-fit:cover;display:block;';media.appendChild(v);if(v.autoplay){const play=()=>v.play().catch(()=>{});v.addEventListener('canplay',play,{once:true});v.addEventListener('loadeddata',play,{once:true});play();document.addEventListener('visibilitychange',()=>{if(!document.hidden)play();});}}
    else if(m.fresh_food_banner_image){ const im=document.createElement('img');im.src=m.fresh_food_banner_image;im.alt='Fresh Food';im.style.cssText='width:100%;height:100%;object-fit:cover;display:block;';media.appendChild(im);}
  }catch(e){console.warn('Fresh Food banner load failed',e);}
});

;

(function(){
  function syncPopularProducts(){
    const source=document.getElementById('products');
    const rail=document.getElementById('popularProducts');
    if(!source||!rail)return;
    const cards=Array.from(source.querySelectorAll('.zinkitProductCard')).slice(0,6);
    rail.innerHTML='';
    cards.forEach(card=>rail.appendChild(card.cloneNode(true)));
    const section=document.getElementById('popularProductsSection');
    if(section)section.style.display=cards.length?'block':'none';
  }
  document.addEventListener('DOMContentLoaded',()=>{
    const source=document.getElementById('products');
    if(!source)return;
    new MutationObserver(syncPopularProducts).observe(source,{childList:true,subtree:false});
    setTimeout(syncPopularProducts,400);
    setTimeout(syncPopularProducts,1400);
  });
  window.addEventListener('pageshow',()=>setTimeout(syncPopularProducts,250));
})();

;

let zinkitPopularProductIds=[];
async function loadPopularProductsCustomer(){const wrap=document.getElementById('popularProducts');if(!wrap||!db)return;try{const r=await db.from('app_settings').select('value').eq('key','popular_product_ids').maybeSingle();let ids=[];if(!r.error&&r.data?.value){let v=r.data.value;try{if(typeof v==='string')v=JSON.parse(v)}catch(e){}if(Array.isArray(v))ids=v.map(String);}zinkitPopularProductIds=ids;renderPopularProductsCustomer();}catch(e){console.warn('Popular products settings load failed',e);renderPopularProductsCustomer();}}
function renderPopularProductsCustomer(){const wrap=document.getElementById('popularProducts'),section=document.getElementById('popularProductsSection');if(!wrap)return;const ids=Array.isArray(zinkitPopularProductIds)?zinkitPopularProductIds:[];const list=(Array.isArray(products)?products:[]).filter(p=>ids.includes(String(productId(p)))&&(p.is_active===undefined||p.is_active===null||p.is_active===true));if(!list.length){if(section)section.style.display='none';wrap.innerHTML='';return;}if(section)section.style.display='';wrap.innerHTML=list.map(p=>{const id=JSON.stringify(productId(p));const img=productImage(p);const qty=Object.entries(cart||{}).filter(([k])=>String(k).split('__')[0]===String(productId(p))).reduce((a,[,v])=>a+Number(v),0);const control=qty>0?`<div class="qty productQty"><button type="button" onclick='event.stopPropagation();changeQty(${id},-1)'>−</button><span>${qty}</span><button type="button" onclick='event.stopPropagation();changeQty(${id},1)'>+</button></div>`:`<button class="add" type="button" onclick='event.stopPropagation();openVariantModal(${id})'>ADD</button>`;return `<div class="card zinkitProductCard" role="button" tabindex="0" onclick="openProductDetail(${id})"><div class="pic">${img?`<img src="${esc(img)}" loading="lazy" decoding="async" alt="${esc(productName(p))}" onerror="this.style.display='none'">`:'🛍️'}</div><div class="name">${esc(productName(p))}</div><div class="muted">${esc(productCategory(p))}${p.brand?' · '+esc(p.brand):''}</div><div class="row">${productPriceMarkup(p)}${control}</div></div>`}).join('');}
