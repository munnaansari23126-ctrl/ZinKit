ZinKit V13 — Blinkit-style Brand Store Page

Customer App:
- Shop by Brand brand cards now open a dedicated Brand Store screen instead of only filtering the Home product grid.
- Brand Store displays the brand logo, name, description, product count, and matching products.
- Product cards reuse the existing product image, price, variant selection, cart, and product detail flows.
- Admin > Brands continues to manage brand name/logo/description/store/active status.
- Admin > Products: set the product Brand field to the exact brand name (e.g. Jockey) for it to appear in that brand store.

Deployment notes:
- Keep the same Supabase project and existing configuration.
- This update does not run SQL or deploy to Vercel automatically.
- Ensure the brands table and its policies are configured in the existing project. Review browser-client write policies before production; brand management writes must be restricted to authenticated admins.
