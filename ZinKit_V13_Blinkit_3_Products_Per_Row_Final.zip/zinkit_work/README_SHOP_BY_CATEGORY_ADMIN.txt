ZinKit Shop by Category Admin control

Admin App > Shop by Category:
- Add category with name, emoji/icon, sort order and Active/Inactive status.
- Edit, deactivate/activate, or delete categories.
- Customer App reads app_settings key product_categories and renders that list dynamically.
- Deleted categories stay deleted; defaults are seeded only when the setting does not yet exist.
- Deleting a category does not delete products. Product records and orders are not changed.
- Customer App must be refreshed/redeployed with this updated file to see code changes; settings sync through the same Supabase project.

No SQL migration added. This feature relies on the existing app_settings table and permissions already used by Admin.
