ZinKit V13 — Festival Status Photo / Video / Product

Admin > Ads / Featured Food area > Festival Section now includes a Festival Status manager. Admin can add multiple photo statuses, video statuses, and status cards linked to existing products from the products table. Status items can be shown/hidden or deleted. Status items are stored separately in app_settings key festival_statuses; the existing festival_media and featured_food_media keys are unchanged.

Customer Home shows horizontal story circles in the Festival section. Tapping opens a story viewer with previous/next controls. Video plays only after the customer opens a story. Product status shows the existing product image/name/price and a View Product action that opens the product's category. This does not insert duplicate products or change orders/cart schemas.

Storage: photo/video uploads reuse the existing uploadFeaturedFoodPromoFile helper and existing ad-images/product-images/ad-videos buckets. Admin storage upload permission and public-read access must be configured in the existing Supabase project.

Validation performed: ZIP integrity and inline JavaScript syntax checks. Live Supabase/Vercel/mobile testing is not performed here.
