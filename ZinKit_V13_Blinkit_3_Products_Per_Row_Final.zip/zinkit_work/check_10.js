
function zinkitPromoEsc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function zinkitPromoMediaMarkup(d,compact){
  const video=d.video_url?`<video src="${zinkitPromoEsc(d.video_url)}" muted playsinline loop controls preload="metadata" aria-label="${zinkitPromoEsc(d.name||'Promotion video')}" onclick="event.stopPropagation()"></video>`:'';
  const photo=d.image_url?`<img src="${zinkitPromoEsc(d.image_url)}" alt="${zinkitPromoEsc(d.name||'Promotion')}" loading="lazy">`:'';
  const media=compact?(photo||video):(video||photo);
  const logo=d.logo_url?`<img class="ffPromoLogo" src="${zinkitPromoEsc(d.logo_url)}" alt="${zinkitPromoEsc(d.name||'Logo')}" loading="lazy">`:'';
  if(compact)return `${media}<div class="ffSideName">${zinkitPromoEsc(d.name||'')}</div>${d.caption?`<div class="ffSideCaption">${zinkitPromoEsc(d.caption)}</div>`:''}`;
  return `<div class="ffPromoTopInner">${media?media.replace('<img ','<img class="ffPromoTopMedia" ').replace('<video ','<video class="ffPromoTopMedia" '):''}<div class="ffPromoTopText">${logo}${`<b>${zinkitPromoEsc(d.name||'')}</b>`}${d.caption?`<small>${zinkitPromoEsc(d.caption)}</small>`:''}</div></div>`;
}
async function loadFeaturedFoodPromoMediaCustomer(){
  try{
    if(!db)return;const r=await db.from('app_settings').select('value').eq('key','featured_food_media').maybeSingle();if(r.error||!r.data?.value)return;
    let d={};try{d=typeof r.data.value==='string'?JSON.parse(r.data.value):r.data.value;}catch(e){return;}
    const top=document.getElementById('featuredFoodPromoTop'),side=document.getElementById('featuredFoodPromoSide');
    if(!d||d.enabled===false||(!d.image_url&&!d.video_url&&!d.logo_url&&!d.name)){if(top)top.style.display='none';if(side)side.style.display='none';return;}
    if(top){top.innerHTML=zinkitPromoMediaMarkup(d,false);top.style.display='block';top.onclick=()=>selectCategory(d.target_type||'Hotel');top.style.cursor='pointer';}
    if(side){side.innerHTML=zinkitPromoMediaMarkup(d,true);side.style.display='block';side.onclick=()=>selectCategory(d.target_type||'Hotel');side.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();selectCategory(d.target_type||'Hotel');}};}
  }catch(e){console.warn('Featured Food promo media load skipped',e);}
}
document.addEventListener('DOMContentLoaded',()=>setTimeout(loadFeaturedFoodPromoMediaCustomer,400));
// Refresh promotional media occasionally so Admin changes appear without clearing customer state.
setInterval(()=>loadFeaturedFoodPromoMediaCustomer(),120000);
// Independent Festival section: separate app_settings key; does not modify Featured Food.

// Festival Status Stories: independent setting, supports photo, video, and existing product cards.
let zinkitFestivalStatuses=[];let zinkitFestivalStatusIndex=0;
function renderFestivalStatusStories(){const box=document.getElementById('festivalStatusStories');if(!box)return;const items=(zinkitFestivalStatuses||[]).filter(x=>x&&x.enabled!==false);if(!items.length){box.style.display='none';box.innerHTML='';return;}const festivalSection=document.getElementById('festivalPromoSection');if(festivalSection)festivalSection.style.display='block';box.style.display='flex';box.innerHTML=items.map((it,i)=>{const src=it.image_url||it.media_url||'';const thumb=it.media_type==='video'&&src?`<video src="${escapeHtml(src)}" muted playsinline></video>`:(src?`<img src="${escapeHtml(src)}" alt="">`:'<div style="width:100%;height:100%;display:grid;place-items:center;background:white;border-radius:50%;font-size:24px">🛍️</div>');return `<button class="festivalStory" type="button" onclick="event.stopPropagation();openFestivalStatusViewer(${i})"><span class="festivalStoryRing">${thumb}</span><span class="festivalStoryName">${escapeHtml(it.caption||it.product_name||'Festival')}</span></button>`;}).join('');}
function currentFestivalStatusItems(){return (zinkitFestivalStatuses||[]).filter(x=>x&&x.enabled!==false);}
function openFestivalStatusViewer(i){const items=currentFestivalStatusItems();if(!items.length)return;zinkitFestivalStatusIndex=Math.max(0,Math.min(i,items.length-1));renderFestivalStatusViewer();const v=document.getElementById('festivalStatusViewer');if(v)v.style.display='flex';}
function closeFestivalStatusViewer(){const v=document.getElementById('festivalStatusViewer');if(v)v.style.display='none';const media=document.getElementById('festivalStatusViewerMedia');if(media)media.querySelectorAll('video').forEach(x=>x.pause());}
function previousFestivalStatus(){const items=currentFestivalStatusItems();if(items.length){zinkitFestivalStatusIndex=(zinkitFestivalStatusIndex-1+items.length)%items.length;renderFestivalStatusViewer();}}
function nextFestivalStatus(){const items=currentFestivalStatusItems();if(items.length){zinkitFestivalStatusIndex=(zinkitFestivalStatusIndex+1)%items.length;renderFestivalStatusViewer();}}
function renderFestivalStatusViewer(){const items=currentFestivalStatusItems(),it=items[zinkitFestivalStatusIndex];if(!it)return;const media=document.getElementById('festivalStatusViewerMedia'),cap=document.getElementById('festivalStatusViewerCaption'),prod=document.getElementById('festivalStatusViewerProduct');if(!media||!cap||!prod)return;const src=it.media_url||it.image_url||'';if(it.media_type==='video'&&src)media.innerHTML=`<video class="fsViewMedia" src="${escapeHtml(src)}" controls autoplay playsinline></video>`;else if(src)media.innerHTML=`<img class="fsViewMedia" src="${escapeHtml(src)}" alt="${escapeHtml(it.caption||'Festival status')}">`;else media.innerHTML='<div class="fsViewMedia" style="display:grid;place-items:center;font-size:48px">🛍️</div>';cap.textContent=it.caption||it.product_name||'Festival Status';if(it.media_type==='product'){prod.innerHTML=`<div class="fsViewProduct">${it.image_url?`<img src="${escapeHtml(it.image_url)}" alt="">`:'<div style="font-size:30px">🛍️</div>'}<div style="flex:1;min-width:0"><b>${escapeHtml(it.product_name||'Product')}</b><div style="margin-top:4px">${it.product_price!=null?'₹'+escapeHtml(it.product_price):''}</div></div><button type="button" onclick="closeFestivalStatusViewer();selectCategory(${JSON.stringify(it.category||'All')})">View Product</button></div>`;}else prod.innerHTML='';}
async function loadFestivalStatusesCustomer(){try{if(!db)return;const r=await db.from('app_settings').select('value').eq('key','festival_statuses').maybeSingle();if(r.error||!r.data?.value){zinkitFestivalStatuses=[];renderFestivalStatusStories();return;}let d=typeof r.data.value==='string'?JSON.parse(r.data.value):r.data.value;zinkitFestivalStatuses=Array.isArray(d)?d:[];renderFestivalStatusStories();}catch(e){console.warn('Festival status load skipped',e);}}
document.addEventListener('DOMContentLoaded',()=>setTimeout(loadFestivalStatusesCustomer,650));setInterval(loadFestivalStatusesCustomer,120000);

async function loadFestivalPromoCustomer(){
  try{
    if(!db)return;const r=await db.from('app_settings').select('value').eq('key','festival_media').maybeSingle();
    const sec=document.getElementById('festivalPromoSection'),content=document.getElementById('festivalPromoContent'),heading=document.getElementById('festivalPromoHeading');
    if(!sec||!content)return;if(r.error||!r.data?.value){const storyItems=(zinkitFestivalStatuses||[]).some(x=>x&&x.enabled!==false);sec.style.display=storyItems?'block':'none';return;}
    let d={};try{d=typeof r.data.value==='string'?JSON.parse(r.data.value):r.data.value;}catch(e){sec.style.display='none';return;}
    if(!d||d.enabled===false||(!d.name&&!d.image_url&&!d.video_url&&!d.logo_url)){const storyItems=(zinkitFestivalStatuses||[]).some(x=>x&&x.enabled!==false);sec.style.display=storyItems?'block':'none';return;}
    if(heading)heading.textContent=d.title||'🎉 Festival Special';
    content.innerHTML=zinkitPromoMediaMarkup(d,false);
    sec.style.display='block';sec.onclick=()=>selectCategory(d.target_type||'All');sec.style.cursor='pointer';
    sec.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();selectCategory(d.target_type||'All');}};
    sec.setAttribute('role','button');sec.setAttribute('tabindex','0');sec.setAttribute('aria-label',d.title||'Festival Special');
  }catch(e){console.warn('Festival promo load skipped',e);}
}
document.addEventListener('DOMContentLoaded',()=>setTimeout(loadFestivalPromoCustomer,550));
setInterval(()=>loadFestivalPromoCustomer(),120000);
