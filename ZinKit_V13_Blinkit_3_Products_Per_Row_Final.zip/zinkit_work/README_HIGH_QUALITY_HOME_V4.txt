ZinKit High-Quality Clean Product Home V4

Changes:
- Added quick product-category shortcuts at the top of the Customer home screen.
- Refined mobile-first product cards with clean spacing, clear pricing and prominent Add/quantity controls.
- Product images use contained sizing to reduce cropping/stretching and keep the full product visible.
- Refined category tiles, search and home sections for a cleaner premium look.

Scope: Customer/index.html visual changes only. Admin and Rider files are included unchanged. Existing app logic, Supabase configuration, store selection, products, cart, orders, payment and rider tracking code were not intentionally changed.

Validation: ZIP integrity and inline JavaScript syntax checks performed. This does not confirm live Supabase behavior or full browser/device checkout and rider-tracking flows; perform staging tests before production release.
