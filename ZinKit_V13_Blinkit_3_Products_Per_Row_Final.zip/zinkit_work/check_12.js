
async function loadFreshFoodHeroCustomer(){
  try{
    if(!db)return;
    const r=await db.from('app_settings').select('value').eq('key','fresh_food_hero').maybeSingle();
    if(r.error||!r.data?.value)return;
    const d=JSON.parse(r.data.value);
    const hero=$('freshFoodHero');if(!hero)return;
    if(d.enabled===false){hero.style.display='none';return;}
    hero.style.display='';
    const title=$('ffCustomerTitle');if(title)title.innerHTML=(typeof escapeHtml==='function'?escapeHtml(d.title||'Fresh Food'):String(d.title||'Fresh Food'))+'<br>'+(typeof escapeHtml==='function'?escapeHtml(d.subtitle||'Now at Your Doorstep'):String(d.subtitle||'Now at Your Doorstep'));
    const desc=$('ffCustomerDescription');if(desc)desc.textContent=d.description||'';
    const btn=$('ffCustomerButton');if(btn){btn.textContent=d.button_text||'Order Now →';btn.onclick=function(){selectCategory(d.category||'Biryani');$('products')?.scrollIntoView({behavior:'smooth'});};}
    const media=$('ffCustomerMedia');if(!media)return;
    const url=d.media_url||d.image_url||'';media.innerHTML='';hero.style.backgroundImage='';
    if(url && d.media_type==='video'){
      const v=document.createElement('video');v.src=url;v.autoplay=true;v.muted=true;v.defaultMuted=true;v.loop=true;v.playsInline=true;v.setAttribute('playsinline','');v.setAttribute('webkit-playsinline','');v.preload='auto';v.setAttribute('aria-label','Fresh Food banner video');v.style.cssText='width:100%;height:100%;object-fit:cover;display:block;';media.appendChild(v);
      const play=v.play();if(play&&play.catch)play.catch(()=>{});
    }else if(url){
      const img=document.createElement('img');img.src=url;img.alt='Fresh Food banner';img.style.cssText='width:100%;height:100%;object-fit:cover;display:block;';media.appendChild(img);
    }
  }catch(e){console.log('Fresh Food banner load failed',e);}
}
document.addEventListener('DOMContentLoaded',loadFreshFoodHeroCustomer);
