ZinKit Order Return System

Added to the existing Customer and Admin apps:
- Customer can request a return for delivered/completed orders from Your Orders.
- Customer must enter the 10-digit mobile used for the order and provide a return reason.
- Admin Orders panel includes Order Return Requests with Approve/Reject actions.
- Uses a separate order_return_requests table; existing products, prices, images, orders, and delivery flows are not replaced.

One-time setup:
1. Run SUPABASE_ORDER_RETURNS.sql in Supabase SQL Editor.
2. Deploy updated Admin/index.html and Customer/index.html from this ZIP.
3. Test with a delivered order.

Note: current customer login is phone-only, so the phone number is not independently verified. Live Supabase integration has not been tested from this environment.
