ZinKit V13 — PWA icon package

Included: Customer, Admin and Rider manifest updates and PNG icons in 72, 96, 128, 144, 152, 180, 192, 256, 384 and 512 px. The manifests list 192/256/384/512 icons; iPhone Add to Home Screen uses the 180 px Apple touch icon. Existing app HTML, Supabase SQL/config, and app features are preserved from the source ZIP except PWA metadata/icon references and service-worker registration version strings.

Deploy the app folders to their corresponding hosting paths. This ZIP does not deploy to Vercel and does not make any live Supabase changes. On iPhone Safari, open the deployed Customer app, tap Share, then Add to Home Screen. No automatic install popup is added.

After deployment, verify each app loads, login/products/orders work, icons appear, and service-worker updates. Keep a copy of the currently live ZIP before replacing files.
