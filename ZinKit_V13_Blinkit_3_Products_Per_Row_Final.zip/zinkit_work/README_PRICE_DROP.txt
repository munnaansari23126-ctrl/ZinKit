ZinKit Fashion Categories — Discount Price Update

Included apps: Admin, Customer, Rider (existing bundle preserved).

Admin:
- Enter Discount Price / Selling Price in the existing Price field.
- Enter Original Price (higher than selling price) to activate a real discount.
- Discount amount and percentage preview automatically.
- Existing products can be edited; original price is retained in the existing Description metadata, so no new Supabase column or SQL migration is required.

Customer:
- Price Drop category filters by actual discount metadata, not by product category words.
- Discounted product cards and product details show sale price, struck-through original price, and percentage off.
- Products without an original price higher than their selling price do not appear in Price Drop.

Rider app and other bundle files were not intentionally changed.


Customer reviews update:
- Product detail page includes star rating, review submission, average rating, and review list.
- Run SUPABASE_PRODUCT_REVIEWS.sql once in Supabase SQL Editor before using reviews.


STORE-WISE PRODUCT DISCOUNT (UPDATED)
- Admin > Products form mein Store select karke “Store Discount (%)” bhar sakte hain.
- Discount existing products table ke Description field mein metadata ke roop mein store hota hai; koi nayi table/SQL migration zaroori nahi.
- Product ka existing price/price column change nahi hota; customer app discount display aur cart total mein discount apply karta hai.
- Store discount per product row/store alag hota hai. Discount set karne se pehle Store select karna zaroori hai.
- Existing image fields, product IDs, variants, orders aur doosre modules ko change nahi kiya gaya.
