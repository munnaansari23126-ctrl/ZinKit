
document.addEventListener('DOMContentLoaded',()=>{
  const p=document.getElementById('custMobile');
  if(p){
    const saved=(localStorage.getItem('zinkit_customer_mobile')||'').replace(/\D/g,'').slice(0,10);
    if(saved)p.value=saved;
    p.addEventListener('input',()=>{
      p.value=p.value.replace(/\D/g,'').slice(0,10);
      localStorage.setItem('zinkit_customer_mobile',p.value);
    });
  }
});
