
document.addEventListener('DOMContentLoaded', async function(){
  try{
    if(typeof db==='undefined'||!db)return;
    const r=await db.from('app_settings').select('key,value').in('key',['fresh_food_banner_title','fresh_food_banner_subtitle','fresh_food_banner_image','fresh_food_banner_video','fresh_food_banner_media_type','fresh_food_banner_button','fresh_food_banner_active','fresh_food_banner_video_autoplay']); if(r.error)throw r.error;
    const m=Object.fromEntries((r.data||[]).map(x=>[x.key,x.value])); if(String(m.fresh_food_banner_active??'true').toLowerCase()==='false'){const hero0=document.getElementById('freshFoodHero');if(hero0)hero0.style.display='none';return;}
    const hero=document.getElementById('freshFoodHero'),media=document.getElementById('ffCustomerMedia'),title=document.getElementById('ffCustomerTitle'),desc=document.getElementById('ffCustomerDescription'),btn=document.getElementById('ffCustomerButton'); if(!hero||!media)return; hero.style.display='';
    if(title)title.textContent=m.fresh_food_banner_title||'Fresh Food'; if(desc)desc.textContent=m.fresh_food_banner_subtitle||'Fresh food, fast delivery'; if(btn&&m.fresh_food_banner_button)btn.textContent=m.fresh_food_banner_button+' →';
    media.innerHTML='';
    if(m.fresh_food_banner_media_type==='video'&&m.fresh_food_banner_video){ const v=document.createElement('video');v.src=m.fresh_food_banner_video;v.muted=true;v.playsInline=true;v.loop=true;v.autoplay=String(m.fresh_food_banner_video_autoplay??'true').toLowerCase()!=='false';v.controls=false;v.preload='auto';v.setAttribute('playsinline','');v.setAttribute('webkit-playsinline','');v.style.cssText='width:100%;height:100%;object-fit:cover;display:block;';media.appendChild(v);if(v.autoplay){const play=()=>v.play().catch(()=>{});v.addEventListener('canplay',play,{once:true});v.addEventListener('loadeddata',play,{once:true});play();document.addEventListener('visibilitychange',()=>{if(!document.hidden)play();});}}
    else if(m.fresh_food_banner_image){ const im=document.createElement('img');im.src=m.fresh_food_banner_image;im.alt='Fresh Food';im.style.cssText='width:100%;height:100%;object-fit:cover;display:block;';media.appendChild(im);}
  }catch(e){console.warn('Fresh Food banner load failed',e);}
});
