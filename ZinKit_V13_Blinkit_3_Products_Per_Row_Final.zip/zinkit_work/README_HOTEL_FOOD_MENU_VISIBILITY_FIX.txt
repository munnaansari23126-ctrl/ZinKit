ZinKit V13 — Hotel/Food Menu Visibility Diagnostic Fix

Customer App change:
- Customer hotel menu loading now displays actual Supabase errors instead of silently rendering an empty menu.
- Gives a clear message when active categories or active food items are missing.
- Admin and Rider files and existing business logic were not otherwise changed.

Important checks:
1. Admin hotel Store ID must match the store selected in Customer App.
2. In Admin > Hotels/Food > Menu, create an active category, then save food items under that category.
3. Keep the food item Active and Available.
4. If Customer App displays an RLS error, apply the supplied SUPABASE_FOOD_MENU_RLS_FIX.sql in the SAME Supabase project after reviewing its policies and ensure public SELECT policies exist for active restaurants, food_categories, and food_items.
5. JavaScript/ZIP validation does not verify live Supabase data, policies, or production behavior.
