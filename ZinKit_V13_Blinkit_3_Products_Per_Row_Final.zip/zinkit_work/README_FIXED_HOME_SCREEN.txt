ZinKit Quick Commerce — Fixed Home Screen Update

Updated: Customer/index.html only.
Design: White location/search header, yellow quick-commerce hero banner, clean four-column category grid, green accent styling, responsive small-screen layout.
Preserved: existing JavaScript, Supabase configuration, store selection, products, cart, orders, payment, rider live tracking, and Admin/Rider HTML files.

Validation performed: HTML/JS source inspected and JavaScript syntax checked separately. A browser/device end-to-end test and live Supabase transaction test are still required before production release.
