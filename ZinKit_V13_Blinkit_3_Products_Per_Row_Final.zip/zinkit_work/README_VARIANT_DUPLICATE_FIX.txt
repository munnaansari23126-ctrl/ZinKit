ZinKit V13 Product Variant Fix

Changes:
- Customer product variant picker now reads the exact variants saved in the product Description metadata (__ZINKIT_VARIANTS__). It no longer invents 100g/250g/500g/1kg choices when a product has configured variants.
- Variant names are trimmed and duplicate names are removed case-insensitively. Empty-price variants are ignored.
- Products with no configured variants show one base-price Default option instead of four fabricated quantities.
- Admin starts with one blank variant row for new products and restores saved variants when editing an existing product.
- Variant prices continue to use the existing store discount calculation; other app files and Supabase project configuration are unchanged.

Validation:
- ZIP integrity check passed.
- Inline JavaScript syntax checks passed for Admin (10 blocks), Customer (15 blocks), Rider (3 blocks).
- Live Supabase/Vercel testing has not been performed by this patch.
