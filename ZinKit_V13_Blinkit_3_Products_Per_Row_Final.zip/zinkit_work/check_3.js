
/* Customer -> Supabase live location bridge. It starts after a successful order and can be resumed from Orders. */
let customerLiveWatchId=null;
let customerLiveOrderId=null;
function showLiveTracking(orderId){
  customerLiveOrderId=orderId;
  const c=document.getElementById('liveTrackingCard'); if(c)c.classList.add('show');
  const t=document.getElementById('liveTrackingText'); if(t)t.textContent='Order #'+orderId+' ke liye live location ON hai.'; if(typeof renderFloatingCart==='function')renderFloatingCart();
}
async function pushCustomerLocation(lat,lon){
  if(!db||!customerLiveOrderId)return;
  try{
    const {error}=await db.rpc('customer_update_order_location',{
      p_order_id:Number(customerLiveOrderId),
      p_latitude:Number(lat),
      p_longitude:Number(lon)
    });
    if(error) console.warn('Live location update failed:',error.message);
  }catch(e){console.warn('Live location update failed:',e)}
}
function startCustomerLiveTracking(orderId){
  if(!orderId||!navigator.geolocation)return;
  showLiveTracking(orderId);
  if(customerLiveWatchId!==null)navigator.geolocation.clearWatch(customerLiveWatchId);
  customerLiveWatchId=navigator.geolocation.watchPosition(pos=>{
    const lat=pos.coords.latitude,lon=pos.coords.longitude;
    const t=document.getElementById('liveTrackingText'); if(t)t.textContent='🟢 Live location updating • '+lat.toFixed(5)+', '+lon.toFixed(5);
    pushCustomerLocation(lat,lon);
  },()=>{}, {enableHighAccuracy:true,maximumAge:5000,timeout:20000});
}
function stopCustomerLiveTracking(){
  if(customerLiveWatchId!==null)navigator.geolocation.clearWatch(customerLiveWatchId);
  customerLiveWatchId=null;
  const t=document.getElementById('liveTrackingText'); if(t)t.textContent='Live location stopped.'; if(typeof renderFloatingCart==='function')renderFloatingCart();
}
function resumeCustomerLiveTracking(){
  try{
    const active=(Array.isArray(orders)?orders:[]).find(o=>o&&o.id&& !['Delivered','Cancelled','Canceled','Order Cancelled'].includes(String(o.status||'')));
    if(active?.id) startCustomerLiveTracking(active.id);
  }catch(e){}
}

const _oldPlaceOrder=window.placeOrder;
if(typeof _oldPlaceOrder==='function'){
  window.placeOrder=async function(ev){
    const beforeCount=Array.isArray(orders)?orders.length:0;
    const result=await _oldPlaceOrder.apply(this,arguments);
    setTimeout(()=>{
      if(Array.isArray(orders)&&orders.length>beforeCount){
        const latest=orders[0]; if(latest?.id)startCustomerLiveTracking(latest.id);
      }
    },300);
    return result;
  };
}
