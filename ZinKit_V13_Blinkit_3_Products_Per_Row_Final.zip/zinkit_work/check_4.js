
(function(){
  function onlyDigits(v){return String(v||'').replace(/\D/g,'').slice(0,10)}
  function openLogin(){
    var overlay=document.getElementById('zinkitAlwaysLogin');
    if(!overlay)return;
    overlay.style.display='flex';
    document.body.style.overflow='hidden';
    var inp=document.getElementById('zinkitAlwaysMobile');
    if(inp){inp.value='';setTimeout(function(){try{inp.focus()}catch(e){}},100)}
  }
  function continueLogin(){
    var inp=document.getElementById('zinkitAlwaysMobile');
    var err=document.getElementById('zinkitAlwaysErr');
    var phone=onlyDigits(inp&&inp.value);
    if(!/^[0-9]{10}$/.test(phone)){if(err)err.textContent='10-digit mobile number bhariye.';return}
    localStorage.setItem('zinkit_customer_mobile',phone);
    var old=document.getElementById('custMobile');
    if(old)old.value=phone;
    var overlay=document.getElementById('zinkitAlwaysLogin');
    if(overlay)overlay.style.display='none';
    document.body.style.overflow='';
    if(typeof window.refreshProfile==='function')try{window.refreshProfile()}catch(e){}
  }
  document.addEventListener('DOMContentLoaded',function(){
    openLogin();
    var inp=document.getElementById('zinkitAlwaysMobile');
    if(inp)inp.addEventListener('input',function(){inp.value=onlyDigits(inp.value);});
    var btn=document.getElementById('zinkitAlwaysContinue');
    if(btn)btn.addEventListener('click',continueLogin);
    if(inp)inp.addEventListener('keydown',function(e){if(e.key==='Enter')continueLogin();});
  });
  window.zinkitOpenAlwaysLogin=openLogin;
})();
