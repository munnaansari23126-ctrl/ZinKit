ZinKit Food Menu: Category save RLS fix

Error: Category save failed: new row violates row-level security policy for table "food_categories"

Steps:
1. Open Supabase Dashboard for the same ZinKit project.
2. Go to SQL Editor > New query.
3. Open SUPABASE_FOOD_MENU_RLS_FIX.sql from this ZIP, copy the full contents into SQL Editor, and click Run.
4. Sign in to the ZinKit Admin app using the Supabase Auth account that is allowed to manage the app.
5. Try saving the category again.

This script keeps Row-Level Security enabled. It gives authenticated users menu-management access and allows public customers to read active menu rows. If your app does not use a real Supabase Auth session for the Admin, do not add public INSERT policies as a shortcut; secure the admin session first.

Note: SQL execution and the live Supabase save must be confirmed in your own Supabase project; this ZIP update alone does not change the remote database.
