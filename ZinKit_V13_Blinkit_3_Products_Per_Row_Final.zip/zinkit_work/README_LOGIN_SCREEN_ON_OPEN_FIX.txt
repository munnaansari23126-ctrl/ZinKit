ZinKit V13 — Login Screen on App Open Fix

Changes in this patch:
- Customer app displays a phone + OTP login screen when the app opens.
- First-time/expired-session customers can request and verify a Supabase SMS OTP.
- If a valid Supabase session already exists, the screen offers Continue without sending another OTP.
- Customer checkout mobile is filled from the verified Supabase phone after login.
- Existing Customer/Admin/Rider HTML, service worker, manifests, SQL, and other project files are preserved.

Important setup/testing:
1. Supabase Authentication > Providers > Phone must be enabled and an SMS provider configured.
2. This is a code patch only; it has not been deployed to Vercel or applied to live Supabase.
3. Test first-time OTP, reopening with an existing session, switching phone number, session expiry, checkout, and order ownership using two test accounts.
4. Login screen visibility is implemented in Customer/index.html only. Admin and Rider login behavior is unchanged.
