ZinKit V13 - Circle Full Product Photos

Customer product images are styled as circular thumbnails. object-fit: contain keeps the complete uploaded product image visible inside the circle instead of cropping it. Applied to home products, shop results, and related products. No Supabase schema, data, prices, stock, auth, or orders changed.

Archive validation only; deploy and visually verify on the target phone before replacing the live app.
