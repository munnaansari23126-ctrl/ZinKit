ZinKit Customer - Order Again

Added only in Customer app > Your Orders: each order has an "Order Again" button.

Behavior:
- Uses the existing orders list and existing products table; no new SQL/table is required.
- Refreshes current store/product data before adding items, and uses current product prices/discount logic at cart render/checkout, not historical order prices.
- Skips products that are unavailable in the currently selected store, inactive, marked out of stock, or have stock <= 0. Quantity is capped by the current stock field when present.
- Adds available matching products to the existing cart and opens Cart so the customer can review the current total before placing a new order.
- No order is submitted automatically. Customer must review cart and tap Proceed to Checkout.
- Existing Supabase URL/key, Multi-Store logic, Admin/Rider files, cancellation and return code remain unchanged.

Verification performed: Customer inline JavaScript syntax check passed. Live Supabase query/order/cart checkout was not remotely executed, so please test in your deployed/staging app before production.
