ZinKit V13 — Vegetables & Fruits Blinkit-style sidebar update

When the main category is “Vegetables & Fruits”, the category browser shows Fruits, Vegetables, Leaves & Saag, Frozen Vegetables, Freshly Cut & Sprouts, and Coriander & Others.
The first two use existing common product-category labels “Fresh Fruits” and “Fresh Vegetables”; remaining options match their corresponding category metadata/aliases.
Admin-configured parent-child categories continue to take priority over these fallback defaults.
No Supabase SQL, credentials, tables, or data were changed.
Static checks: customer JavaScript syntax checked with node --check; ZIP integrity checked.
Live Supabase data, deployed Vercel UI, and product-category coverage have not been verified in this static update.
