ZinKit V13 — Strict Category Product Matching Fix

- Customer category filters now use category/subcategory/department metadata instead of product-name text matching.
- Parent departments can include explicitly categorized subcategories (for example Men -> Men - Shirt).
- A product named “shirt” is not shown under Shirt unless its category metadata matches.
- Price Drop still uses the existing discount predicate.
- Customer/Admin/Rider files and Supabase configuration are preserved; no database schema or live data changed.

Important: products must have the correct category/subcategory assigned in Admin for exact filtering. This ZIP has not been deployed to Vercel and live Supabase behavior is not verified.
