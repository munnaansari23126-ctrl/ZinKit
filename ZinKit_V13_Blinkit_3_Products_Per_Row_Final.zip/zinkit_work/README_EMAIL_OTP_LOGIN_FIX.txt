ZinKit V13 — Phone -> Email -> Email OTP Login

Customer login flow:
1. Customer enters a 10-digit Indian mobile number.
2. Customer enters an email address.
3. App requests a 6-digit email OTP from Supabase Auth.
4. Customer verifies the email OTP; a valid Supabase Auth session is required before ordering.

Order ownership:
- Existing orders.user_id column is used to store the authenticated Supabase user ID.
- My Orders, track lookup, cancellation and return ownership checks use user_id.
- The mobile number is saved as delivery contact only and is NOT verified by SMS.

Supabase setup:
- Authentication > Sign In / Providers > Email: enabled.
- For OTP codes, Email template must use {{ .Token }} and OTP verification type email.
- Configure SMTP for production delivery; Supabase default mail service may be limited.
- Review SUPABASE_ORDER_PRIVACY_OTP_FIX.sql and verify profiles, rider assignment, and order_return_requests schemas before running.
- No Supabase database or Vercel deployment was performed by this patch. Live email delivery, cross-customer privacy, Admin/Rider compatibility still require testing in staging.
