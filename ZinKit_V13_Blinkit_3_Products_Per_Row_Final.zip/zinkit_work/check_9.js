
async function loadFeaturedFoodCustomer(){
  try{
    if(!db)return; const r=await db.from('app_settings').select('value').eq('key','featured_food').maybeSingle();
    if(r.error||!r.data?.value)return; let d={}; try{d=JSON.parse(r.data.value)||{};}catch(e){return;}
    const sec=document.getElementById('featuredFoodSection'); if(!sec)return; sec.style.display=d.enabled===false?'none':''; if(d.enabled===false)return;
    const title=document.getElementById('featuredFoodTitle'); if(title)title.textContent=d.title||'Featured Food';
    const va=document.getElementById('featuredFoodViewAll'); if(va){va.textContent=d.view_all_text||'View All →'; va.onclick=()=>selectCategory(d.view_all_category||'Hotel');}
    const wrap=document.getElementById('featuredFoodChips'); if(wrap){wrap.innerHTML=''; (Array.isArray(d.chips)?d.chips:[]).forEach(x=>{if(!x?.text||!x?.category)return; const b=document.createElement('button');b.className='foodChip';b.type='button';b.textContent=x.text;b.onclick=()=>selectCategory(x.category);wrap.appendChild(b);});}
  }catch(e){}
}
document.addEventListener('DOMContentLoaded',()=>setTimeout(loadFeaturedFoodCustomer,250));
