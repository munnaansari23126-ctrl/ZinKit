ZinKit V13 Order Privacy Security Fix

- Customer orders scoped to customer_id = auth.uid().
- Anonymous access to orders and return requests revoked.
- Existing policies replaced to prevent permissive-policy OR bypass.
- Admin access follows profiles.id = auth.uid() and profiles.role = 'admin'.
- Unscoped Rider fallback updates removed.
- Trigger restricts customer changes to cancellation and rider changes to claim/status.
- Return requests scoped to owning order or admin.

Before SQL: back up DB; confirm profiles(id, role), orders(customer_id UUID, rider_id UUID),
and order_return_requests exist; confirm rider Supabase Auth UUID matches rider_id.
This replaces all policies on orders and order_return_requests, so review custom policies
and run in staging first. Test two customer accounts, admin and rider.
Older orders with NULL customer_id remain private until ownership is independently verified.
Not live-deployed; SQL has not been run against your Supabase.
