ZinKit Fashion Department Navigation V9

Customer App:
- Tapping Men opens a submenu: T-Shirt, Shirt, Jeans, Pant.
- Tapping Women opens a submenu: Saree, Kurti, Dress, Tops, Jeans, Leggings.
- Accessories, Innerwear, Footwear, Kids, Jewellery each open relevant product-type choices.
- Choosing a type filters the existing Customer product list using existing product category/name fields.

Admin App:
- Fashion Store Product form has quick category buttons for Men and Women types.
- Existing products table and category settings are reused; no separate fashion product table was added.
- Store selection, image upload, price, colour/size and stock fields remain in the existing product form.

Validation performed:
- ZIP integrity check
- Inline JavaScript syntax check for Customer, Admin and Rider
- Duplicate HTML ID check

Not yet verified:
- Live Supabase save/load or device end-to-end shopping test.
