ZinKit Cancel Settings Patch

Changes:
1. Admin -> App Settings now has Customer Order Cancel and Product/Cart Change Cancel controls.
2. Save Settings stores these keys in the existing Supabase app_settings table:
   - order_cancel_enabled = true/false
   - product_change_cancel_enabled = true/false
3. Customer App reads these shared settings. If enabled, customer can cancel eligible orders and remove product/food items from cart. If disabled, corresponding customer buttons/actions are hidden/blocked.
4. Existing Supabase URL/key, tables, store selection, products, orders, returns, delivery settings, rider tracking, ads, and other files are preserved.

No new database table is required. Open Admin Settings and save once to create the two app_settings keys (the existing save routine inserts missing keys).

Validation performed: Node.js syntax checks passed for all inline scripts in Admin, Customer, and Rider HTML files. Live Supabase writes, Gallery upload, order cancellation, and browser UI behavior were not remotely executed; please test with Admin login and a test cart/order before production use.
