ZinKit Order Again shortcut near Profile

- Added an Order Again row inside Customer App Profile menu, immediately below Your Orders.
- Selecting it opens Your Orders, where the existing per-order Order Again buttons remain available.
- Existing Supabase, Multi-Store, stock/price validation and checkout logic are unchanged.
- No new Supabase table or SQL migration is required for this UI shortcut.
- Live Supabase order placement was not tested as part of this UI change.
