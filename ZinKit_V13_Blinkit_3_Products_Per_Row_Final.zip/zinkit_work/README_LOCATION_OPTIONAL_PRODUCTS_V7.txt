ZinKit Location-Optional Product Browsing — V7

Fix:
- Customer can browse active products before adding a delivery location.
- If GPS is unavailable and the customer has not manually selected a store, Customer app uses all-stores catalogue mode instead of forcing Admin's configured active_store_id.
- If the customer explicitly selected a store, that store selection is retained.
- Delivery eligibility is still checked at checkout; this change does not disable delivery restrictions.

Preserved:
- Existing Supabase configuration and product schema
- Multi-store selection and product filtering after location/store selection
- Cart, orders, payment, and rider tracking source

Validation:
- ZIP integrity and inline JavaScript syntax are checked.
- Live Supabase, browser/device, and checkout end-to-end tests remain required.
