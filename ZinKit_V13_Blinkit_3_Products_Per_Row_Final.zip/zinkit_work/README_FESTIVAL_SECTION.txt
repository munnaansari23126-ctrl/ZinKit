ZinKit V13 — Festival Section

Added an independent Festival Special section to Customer Home, controlled from the Admin app inside the Featured Food panel.

Admin can set section title, festival/brand name, active/inactive status, logo, photo, video, caption, and tap-action category. Settings are stored independently under app_settings key `festival_media`; Featured Food uses its existing keys and is not overwritten. Uploads reuse the existing ad-images/ad-videos storage bucket logic.

Customer section is shown between the top promotional banner area and Featured Food, only when Festival is active and has content. Customer refreshes the setting periodically.

Validation performed: ZIP integrity and JavaScript syntax checks. Live Supabase Storage permissions, saving to the deployed Supabase project, and rendering in the deployed Vercel app still need to be tested. No Supabase SQL migration was added.
