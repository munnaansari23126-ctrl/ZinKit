ZinKit V13 - Location Auto-Restore + Product Refresh Fix

Fix: When the installed Home Screen/PWA is reopened and a saved GPS location exists, the Customer app now refreshes multi-store delivery settings, updates the selected-store UI, and reloads products instead of returning immediately after displaying the saved location.

This does not request location permission again when a saved location is available. Existing Supabase configuration, tables, orders, cart, rider tracking, and other app files are preserved.

Validation: ZIP archive integrity checked and Customer JavaScript syntax should be revalidated before deployment. Live Supabase/Vercel behavior still requires testing in the deployed app.
