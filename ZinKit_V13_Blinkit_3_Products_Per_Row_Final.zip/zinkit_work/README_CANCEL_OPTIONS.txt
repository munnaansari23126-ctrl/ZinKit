ZinKit Cancel Options patch

Included changes:
- Admin App Settings includes Cancel Options.
- Admin Orders panel now loads orders from the existing Supabase orders table and offers status changes, including Cancelled.
- Admin product form includes Cancel Product / Changes. This clears the form/edit mode only; it does not delete saved product rows or storage files.
- Customer Profile includes Cancel options screen.
- Customer Cancel Order routes to My Orders; existing order cancel action remains.
- Customer can clear current cart selections after confirmation. This does not cancel already-placed orders.

Safety:
- Existing Supabase URL/key, table names, store/product logic, delivery, payment and rider code retained.
- No SQL migration is required for this UI patch.
- JavaScript inline-script syntax checked with Node.js. Live Supabase / device UI testing was not available, so order status RLS permissions and live app behavior must still be tested after deployment.
