-- ZinKit Food / Restaurant Menu RLS Fix
-- Run this in Supabase Dashboard > SQL Editor > New query.
-- Admin must be signed in with Supabase Auth before saving categories/items.

ALTER TABLE public.food_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.food_items ENABLE ROW LEVEL SECURITY;

-- Remove previous policies with these names so this script can be run again.
DROP POLICY IF EXISTS zinkit_food_categories_public_read_active ON public.food_categories;
DROP POLICY IF EXISTS zinkit_food_categories_admin_select ON public.food_categories;
DROP POLICY IF EXISTS zinkit_food_categories_admin_insert ON public.food_categories;
DROP POLICY IF EXISTS zinkit_food_categories_admin_update ON public.food_categories;
DROP POLICY IF EXISTS zinkit_food_categories_admin_delete ON public.food_categories;

DROP POLICY IF EXISTS zinkit_food_items_public_read_active ON public.food_items;
DROP POLICY IF EXISTS zinkit_food_items_admin_select ON public.food_items;
DROP POLICY IF EXISTS zinkit_food_items_admin_insert ON public.food_items;
DROP POLICY IF EXISTS zinkit_food_items_admin_update ON public.food_items;
DROP POLICY IF EXISTS zinkit_food_items_admin_delete ON public.food_items;

-- Customers can read active menu rows. Admins with a valid Supabase Auth session
-- can manage the menu. This does not disable RLS.
CREATE POLICY zinkit_food_categories_public_read_active
ON public.food_categories FOR SELECT TO anon, authenticated
USING (active = TRUE);

CREATE POLICY zinkit_food_categories_admin_select
ON public.food_categories FOR SELECT TO authenticated
USING (TRUE);

CREATE POLICY zinkit_food_categories_admin_insert
ON public.food_categories FOR INSERT TO authenticated
WITH CHECK (TRUE);

CREATE POLICY zinkit_food_categories_admin_update
ON public.food_categories FOR UPDATE TO authenticated
USING (TRUE) WITH CHECK (TRUE);

CREATE POLICY zinkit_food_categories_admin_delete
ON public.food_categories FOR DELETE TO authenticated
USING (TRUE);

CREATE POLICY zinkit_food_items_public_read_active
ON public.food_items FOR SELECT TO anon, authenticated
USING (active = TRUE);

CREATE POLICY zinkit_food_items_admin_select
ON public.food_items FOR SELECT TO authenticated
USING (TRUE);

CREATE POLICY zinkit_food_items_admin_insert
ON public.food_items FOR INSERT TO authenticated
WITH CHECK (TRUE);

CREATE POLICY zinkit_food_items_admin_update
ON public.food_items FOR UPDATE TO authenticated
USING (TRUE) WITH CHECK (TRUE);

CREATE POLICY zinkit_food_items_admin_delete
ON public.food_items FOR DELETE TO authenticated
USING (TRUE);
