ZinKit V13 test follow-up

Changes in this package:
- Customer Categories tab now builds its own category grid directly from the active category list, with a built-in fallback list. This avoids relying on copying a hidden Home DOM section.
- Customer/Admin/Rider service-worker cache versions were incremented so the browser can pick up this deployed update.

Important: Brand creation is intentionally still protected by the Admin-only Supabase RLS policies. If Brand save fails, capture the exact error shown under the Brand form. Do not re-enable public INSERT/UPDATE/DELETE policies. The authenticated Admin user must satisfy public.has_zinkit_role(auth.uid(), 'admin').

Validation: HTML/JS syntax should be rechecked after deployment. Supabase live connection, category screen on-device, Brand write permissions, checkout and rider tracking require real app testing.
