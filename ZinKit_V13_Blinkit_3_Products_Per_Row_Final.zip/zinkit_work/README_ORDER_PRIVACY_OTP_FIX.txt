ZinKit V13 — Order Privacy + Email OTP Login Fix

Implemented in Customer/index.html:
- Login sequence: mobile number -> email address -> 6-digit email OTP.
- Email OTP must produce a Supabase Auth session before checkout.
- New orders store verified auth.uid() in the existing orders.user_id column.
- My Orders, track lookup, cancel, and return ownership checks use orders.user_id.
- Customer cancellation is restricted in the SQL trigger to changing status only.

IMPORTANT DATABASE NOTES:
- This version uses the existing orders.user_id column, not a new customer_id column.
- Review SUPABASE_ORDER_PRIVACY_OTP_FIX.sql before running. It removes all existing policies on orders and order_return_requests and recreates customer/admin/assigned-rider policies.
- The SQL assumes public.profiles(id uuid, role text), orders.rider_id uuid, and order_return_requests(order_id). Verify these schemas first.
- Assigned riders can see/update only their assigned orders; admin assignment is required for a rider to see an order.
- Existing orders with user_id NULL will not be visible to customers until ownership is independently verified. Do not map orders by phone number alone.
- Email OTP verifies email only; it does not verify the phone number.
- Ensure Supabase Auth Email provider is enabled and email template uses {{ .Token }}. Configure SMTP for reliable production delivery.
- No live Supabase SQL, email delivery, cross-customer test, or Vercel deployment was performed by this patch.
- Back up database and test in staging before production. Check Admin/Rider order flows and the return table schema first.
