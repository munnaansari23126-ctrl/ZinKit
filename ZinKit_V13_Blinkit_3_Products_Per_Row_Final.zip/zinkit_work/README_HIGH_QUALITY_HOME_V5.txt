ZinKit High-Quality Home V5 — Customer + Admin + Rider

Customer home order updated as requested:
1. Automatic delivery-location bar (existing location permission/selection logic preserved)
2. Search + voice search
3. All Products quick option
4. Display banner (existing admin-controlled Fresh Food hero)
5. Popular Products rail (shows up to six currently rendered product cards; uses existing product records)
6. Shop by Category
7. Featured Food
8. Shop by Brand
9. All Products grid

Existing Customer/Admin/Rider files and Supabase-related code are retained. No database schema or credentials were changed.

Checks performed: ZIP integrity; Customer inline JavaScript syntax; duplicate HTML IDs. Browser/device interaction, automatic GPS permission, live Supabase reads/writes, checkout, and rider tracking still require staging/end-to-end verification before production release.
