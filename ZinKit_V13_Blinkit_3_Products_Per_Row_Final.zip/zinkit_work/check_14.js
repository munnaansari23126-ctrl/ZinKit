
(function(){
  function syncPopularProducts(){
    const source=document.getElementById('products');
    const rail=document.getElementById('popularProducts');
    if(!source||!rail)return;
    const cards=Array.from(source.querySelectorAll('.zinkitProductCard')).slice(0,6);
    rail.innerHTML='';
    cards.forEach(card=>rail.appendChild(card.cloneNode(true)));
    const section=document.getElementById('popularProductsSection');
    if(section)section.style.display=cards.length?'block':'none';
  }
  document.addEventListener('DOMContentLoaded',()=>{
    const source=document.getElementById('products');
    if(!source)return;
    new MutationObserver(syncPopularProducts).observe(source,{childList:true,subtree:false});
    setTimeout(syncPopularProducts,400);
    setTimeout(syncPopularProducts,1400);
  });
  window.addEventListener('pageshow',()=>setTimeout(syncPopularProducts,250));
})();
