
/* ZinKit CUSTOMER -> RIDER live tracking.
   Rider GPS is stored in public.rider_locations.
   Customer reads it through the secure get_rider_location_for_order RPC.
*/
let riderLiveTimer=null;
let riderLiveOrderId=null;
let riderLiveMobile=null;

function showRiderLiveTracking(orderId){
  riderLiveOrderId=orderId;
  const c=document.getElementById('liveTrackingCard');
  if(c)c.classList.add('show');
  const t=document.getElementById('liveTrackingText');
  if(t)t.textContent='🚚 Order #'+orderId+' • Rider location check ho rahi hai…';
}

function hideRiderMap(){
  const w=document.getElementById('riderLiveMapWrap');
  const l=document.getElementById('riderLiveMapLink');
  if(w)w.style.display='none';
  if(l)l.style.display='none';
}

let zinkitLeafletPromise=null;
const zinkitRiderMaps={};

function loadZinKitLeaflet(){
  if(window.L)return Promise.resolve(window.L);
  if(zinkitLeafletPromise)return zinkitLeafletPromise;
  zinkitLeafletPromise=new Promise((resolve,reject)=>{
    const old=document.querySelector('script[data-zinkit-leaflet]');
    if(old){
      old.addEventListener('load',()=>resolve(window.L));
      old.addEventListener('error',reject);
      return;
    }
    const sc=document.createElement('script');
    sc.src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
    sc.async=true;
    sc.dataset.zinkitLeaflet='1';
    sc.onload=()=>window.L?resolve(window.L):reject(new Error('Leaflet load failed'));
    sc.onerror=()=>reject(new Error('Leaflet network error'));
    document.head.appendChild(sc);
  });
  return zinkitLeafletPromise;
}

function makeRiderIcon(L){
  const svg=`<svg class="zinkit-rider-svg" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
    <circle cx="50" cy="50" r="48" fill="#dff6cf"/>
    <rect x="58" y="18" width="27" height="31" rx="5" fill="#168b2d"/>
    <rect x="62" y="22" width="19" height="7" rx="2" fill="#39a94b"/>
    <circle cx="47" cy="33" r="10" fill="#f5c79a"/>
    <path d="M36 31c1-10 20-14 25-2l-2 6H37z" fill="#ffd54f"/>
    <path d="M36 47c8-6 18-6 27 1l6 15H31z" fill="#ffd43b"/>
    <path d="M31 60h38l10 10H25z" fill="#30343b"/>
    <circle cx="31" cy="74" r="9" fill="#222"/><circle cx="31" cy="74" r="4" fill="#aaa"/>
    <circle cx="73" cy="74" r="9" fill="#222"/><circle cx="73" cy="74" r="4" fill="#aaa"/>
    <path d="M60 55l14 8-5 7-15-8z" fill="#f5c79a"/>
  </svg>`;
  return L.divIcon({
    className:'zinkit-rider-marker',
    html:'<div class="zinkit-rider-bubble"><div class="zinkit-rider-art">'+svg+'</div><div class="zinkit-rider-label">RIDER</div></div>',
    iconSize:[68,78], iconAnchor:[34,44], popupAnchor:[0,-38]
  });
}
function makeCustomerIcon(L){
  return L.divIcon({
    className:'zinkit-customer-marker',
    html:'<div class="zinkit-customer-pin"><div class="zinkit-customer-pin-inner">📍</div></div>',
    iconSize:[58,66],
    iconAnchor:[29,62],
    popupAnchor:[0,-62]
  });
}

async function createOrUpdateRiderLeafletMap(id,lat,lon,updatedAt,destLat,destLon){
  const el=document.getElementById(id); if(!el||!window.L)return;
  const L=window.L, hasDest=Number.isFinite(Number(destLat))&&Number.isFinite(Number(destLon));
  const dLat=Number(destLat), dLon=Number(destLon);
  let state=zinkitRiderMaps[id];

  if(!state){
    el.innerHTML='<div class="zinkit-blinkit-map-shell"><div class="zinkit-blinkit-top"><small>ORDER IS ON THE WAY</small><strong>Rider is on the way</strong></div><div class="zinkit-map-canvas" style="position:absolute;inset:0"></div><div class="zinkit-blinkit-bottom"><span class="dot"></span><div><b>🛵 Rider → 📍 Drop location</b><span id="zinkitEta-'+id+'">Live location updating</span></div></div></div>';
    const canvas=el.querySelector('.zinkit-map-canvas');
    const map=L.map(canvas,{zoomControl:false,attributionControl:true,preferCanvas:false}).setView([lat,lon],16);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(map);
    const riderMarker=L.marker([lat,lon],{icon:makeRiderIcon(L),zIndexOffset:5000,keyboard:false}).addTo(map);
    riderMarker.bindTooltip('🛵 Rider', {permanent:true,direction:'top',offset:[0,-38],className:'zinkit-rider-tooltip'});
    let customerMarker=null, routeLine=null;
    if(hasDest){
      customerMarker=L.marker([dLat,dLon],{icon:makeCustomerIcon(L),zIndexOffset:4000,keyboard:false}).addTo(map);
      customerMarker.bindTooltip('📍 Drop location', {permanent:true,direction:'top',offset:[0,-48],className:'zinkit-customer-tooltip'});
    }
    state={map,riderMarker,customerMarker,routeLine,destLat:hasDest?dLat:null,destLon:hasDest?dLon:null,lastRouteKey:null,lastRouteAt:0};
    zinkitRiderMaps[id]=state;
    setTimeout(()=>map.invalidateSize(),150);
  }else{
    state.riderMarker.setLatLng([lat,lon]);
    if(hasDest){
      if(!state.customerMarker){
        state.customerMarker=L.marker([dLat,dLon],{icon:makeCustomerIcon(L),zIndexOffset:4000,keyboard:false}).addTo(state.map);
        state.customerMarker.bindTooltip('📍 Drop location', {permanent:true,direction:'top',offset:[0,-48],className:'zinkit-customer-tooltip'});
      }else state.customerMarker.setLatLng([dLat,dLon]);
      state.destLat=dLat; state.destLon=dLon;
    }
    setTimeout(()=>state.map.invalidateSize(),40);
  }

  const routeKey=hasDest?lat.toFixed(4)+','+lon.toFixed(4)+'>'+dLat.toFixed(4)+','+dLon.toFixed(4):null;
  if(hasDest && (!state.lastRouteKey || routeKey!==state.lastRouteKey || Date.now()-state.lastRouteAt>15000)){
    state.lastRouteKey=routeKey; state.lastRouteAt=Date.now();
    try{
      const url='https://router.project-osrm.org/route/v1/driving/'+lon+','+lat+';'+dLon+','+dLat+'?overview=full&geometries=geojson';
      const rr=await fetch(url,{cache:'no-store'}); const data=await rr.json();
      if(data.routes&&data.routes[0]&&data.routes[0].geometry){
        const pts=data.routes[0].geometry.coordinates.map(p=>[p[1],p[0]]);
        if(!state.routeLine)state.routeLine=L.polyline(pts,{color:'#1976d2',weight:5,opacity:.95,lineCap:'round',lineJoin:'round'}).addTo(state.map);
        else state.routeLine.setLatLngs(pts);
        const km=Number(data.routes[0].distance||0)/1000;
        const mins=Math.max(1,Math.round((Number(data.routes[0].duration||0))/60));
        const eta=document.getElementById('zinkitEta-'+id); if(eta)eta.textContent='Approx. '+mins+' min • '+km.toFixed(1)+' km away';
      }
    }catch(e){
      if(!state.routeLine)state.routeLine=L.polyline([[lat,lon],[dLat,dLon]],{color:'#1976d2',weight:5,opacity:.85,lineCap:'round'}).addTo(state.map);
    }
  }

  if(hasDest){
    const b=L.latLngBounds([[lat,lon],[dLat,dLon]]);
    state.map.fitBounds(b,{padding:[70,95],maxZoom:17});
  }else{
    state.map.setView([lat,lon],16);
  }
  setTimeout(()=>state.map.invalidateSize(true),120);
  const when=updatedAt?new Date(updatedAt).toLocaleTimeString('en-IN'):'just now';
  state.riderMarker.bindPopup('<b>🛵 ZinKit Rider</b><br>Live location<br>Updated '+when);
}

async function updateRiderMap(lat,lon,updatedAt,destLat,destLon){
  const la=Number(lat),lo=Number(lon); if(!Number.isFinite(la)||!Number.isFinite(lo))return;
  const openUrl='https://www.google.com/maps?q='+encodeURIComponent(la+','+lo);
  const w=document.getElementById('riderLiveMapWrap'), link=document.getElementById('riderLiveMapLink'), t=document.getElementById('liveTrackingText');
  if(w)w.style.display='block'; if(link){link.href=openUrl;link.style.display='inline-block'}
  const ow=document.getElementById('orderLiveMapWrap'), ol=document.getElementById('orderLiveMapLink'), os=document.getElementById('orderLiveStatus');
  if(ow)ow.style.display='block'; if(ol){ol.href=openUrl;ol.style.display='inline-block'}
  const when=updatedAt?new Date(updatedAt).toLocaleTimeString('en-IN'):'just now';
  const msg='🟢 Rider LIVE • Updated '+when; if(t)t.textContent=msg; if(os)os.textContent=msg;
  try{
    await loadZinKitLeaflet();
    await createOrUpdateRiderLeafletMap('riderLiveMap',la,lo,updatedAt,destLat,destLon);
    await createOrUpdateRiderLeafletMap('orderLiveMap',la,lo,updatedAt,destLat,destLon);
  }catch(e){ if(t)t.textContent=msg+' • Map loading…'; if(os)os.textContent=msg+' • Map loading…'; }
}

async function fetchRiderLiveLocation(){
  if(!db||!riderLiveOrderId)return;

  const t=document.getElementById('liveTrackingText');
  const orderStatus=document.getElementById('orderLiveStatus');
  const orderId=Number(riderLiveOrderId);

  try{
    // Always read the exact order first so the correct customer mobile + rider
    // are used, even if localStorage contains an old mobile number.
    const ordRes=await db.from('orders')
      .select('id,mobile,rider_id,status,latitude,longitude')
      .eq('id',orderId)
      .maybeSingle();

    if(ordRes.error) throw ordRes.error;
    const ord=ordRes.data;

    if(!ord){
      const msg='⚠️ Order details nahi mile.';
      if(t)t.textContent=msg;
      if(orderStatus)orderStatus.textContent=msg;
      return;
    }

    const status=String(ord.status||'').trim().toLowerCase();
    if(['delivered','cancelled','canceled','order cancelled'].includes(status)){
      const msg='ℹ️ Order complete/cancelled hai. Live tracking band hai.';
      if(t)t.textContent=msg;
      if(orderStatus)orderStatus.textContent=msg;
      hideRiderMap();
      const ow=document.getElementById('orderLiveMapWrap');
      if(ow)ow.style.display='none';
      return;
    }

    if(!ord.rider_id){
      const msg='🟡 Rider abhi order accept nahi kiya hai.';
      if(t)t.textContent=msg;
      if(orderStatus)orderStatus.textContent=msg;
      hideRiderMap();
      const ow=document.getElementById('orderLiveMapWrap');
      if(ow)ow.style.display='none';
      return;
    }

    const orderMobile=String(ord.mobile||riderLiveMobile||$('custMobile')?.value||localStorage.getItem('zinkit_customer_mobile')||'')
      .replace(/\D/g,'').slice(-10);

    if(!/^[0-9]{10}$/.test(orderMobile)){
      const msg='📱 Order ka customer mobile number valid nahi hai.';
      if(t)t.textContent=msg;
      if(orderStatus)orderStatus.textContent=msg;
      return;
    }

    const rpcResult=await db.rpc('get_rider_location_for_order',{
      p_order_id:orderId,
      p_mobile:orderMobile
    });

    if(rpcResult.error) throw rpcResult.error;

    let row=Array.isArray(rpcResult.data)?rpcResult.data[0]:rpcResult.data;

    // DB fallback: use the rider_id assigned to this exact order.
    if(!row){
      try{
        const rl=await db.from('rider_locations')
          .select('latitude,longitude,updated_at')
          .eq('rider_id',ord.rider_id)
          .order('updated_at',{ascending:false})
          .limit(1);
        if(!rl.error && Array.isArray(rl.data) && rl.data.length) row=rl.data[0];
      }catch(e){}
    }

    let destLat=Number(ord.latitude), destLon=Number(ord.longitude);
    if(!Number.isFinite(destLat)||!Number.isFinite(destLon)){
      try{
        const saved=JSON.parse(localStorage.getItem('zinkit_location')||'null');
        if(saved && Number.isFinite(Number(saved.latitude)) && Number.isFinite(Number(saved.longitude))){
          destLat=Number(saved.latitude); destLon=Number(saved.longitude);
        }
      }catch(e){}
    }

    if(row && Number.isFinite(Number(row.latitude)) && Number.isFinite(Number(row.longitude))){
      updateRiderMap(row.latitude,row.longitude,row.updated_at,destLat,destLon);
    }else{
      hideRiderMap();
      const ow=document.getElementById('orderLiveMapWrap');
      if(ow)ow.style.display='none';
      const msg='🟡 Rider assign ho gaya hai, GPS location ka wait hai…';
      if(t)t.textContent=msg;
      if(orderStatus)orderStatus.textContent=msg;
    }
  }catch(e){
    const msg='⚠️ Live rider location error: '+(e?.message||'fetch failed');
    if(t)t.textContent=msg;
    if(orderStatus)orderStatus.textContent=msg;
  }
}

async function startRiderLiveTracking(orderId, mobileOverride){
  if(!orderId)return;
  riderLiveOrderId=Number(orderId);
  riderLiveMobile=String(mobileOverride||$('custMobile')?.value||localStorage.getItem('zinkit_customer_mobile')||'')
    .replace(/\D/g,'').slice(-10);

  showRiderLiveTracking(riderLiveOrderId);

  if(riderLiveTimer)clearInterval(riderLiveTimer);

  // Fetch immediately, then refresh every 3 seconds.
  await fetchRiderLiveLocation();
  riderLiveTimer=setInterval(()=>{
    if(riderLiveOrderId) fetchRiderLiveLocation();
  },3000);

  window.scrollTo({top:0,behavior:'smooth'});
}

function startCustomerLiveTracking(orderId){
  // Backward-compatible function name; customer GPS is not used for rider tracking.
  startRiderLiveTracking(orderId);
}

function stopCustomerLiveTracking(){
  if(riderLiveTimer)clearInterval(riderLiveTimer);
  riderLiveTimer=null;
  riderLiveOrderId=null;
  hideRiderMap();
  const t=document.getElementById('liveTrackingText');
  if(t)t.textContent='Rider live tracking stopped.';
}

function resumeCustomerLiveTracking(){
  try{
    const active=(Array.isArray(orders)?orders:[]).find(o=>o&&o.id&&
      !['Delivered','Cancelled','Canceled','Order Cancelled'].includes(String(o.status||'')));
    if(active?.id)startRiderLiveTracking(active.id);
  }catch(e){}
}

const _oldPlaceOrderRiderLive=window.placeOrder;
if(typeof _oldPlaceOrderRiderLive==='function'){
  window.placeOrder=async function(ev){
    const beforeCount=Array.isArray(orders)?orders.length:0;
    const result=await _oldPlaceOrderRiderLive.apply(this,arguments);
    setTimeout(()=>{
      if(Array.isArray(orders)&&orders.length>beforeCount){
        const latest=orders[0];
        if(latest?.id)startRiderLiveTracking(latest.id);
      }
    },500);
    return result;
  };
}
