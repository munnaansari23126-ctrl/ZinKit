
(function(){
  function goProductTop(){
    requestAnimationFrame(function(){
      window.scrollTo(0,0);
      document.documentElement.scrollTop=0;
      document.body.scrollTop=0;
      var main=document.querySelector('main');
      if(main) main.scrollTop=0;
      var app=document.querySelector('.app,.container,#app');
      if(app && typeof app.scrollTop==='number') app.scrollTop=0;
    });
  }

  document.addEventListener('click', function(e){
    var el=e.target && e.target.closest ? e.target.closest(
      '[data-product-id], .product-card, .product, .product-item, .related-product, .product-tile'
    ) : null;
    if(!el) return;

    // Do not interfere with quantity/cart buttons inside a product card.
    if(e.target.closest && e.target.closest('button, input, select, textarea, a')) return;

    setTimeout(goProductTop, 0);
  }, true);

  // Also make the common detail-opening functions land at the top.
  ['openProductDetail','openProduct','showProductDetail'].forEach(function(name){
    if(typeof window[name] === 'function' && !window[name].__mdMunnaTopFixed){
      var original=window[name];
      var wrapped=function(){
        var result=original.apply(this,arguments);
        setTimeout(goProductTop,0);
        return result;
      };
      wrapped.__mdMunnaTopFixed=true;
      window[name]=wrapped;
    }
  });
})();
