
const MD_MUNNA_DAILY_ORDER_LIMIT=1000;

/* ZinKit shared delivery settings — loaded from Admin -> Supabase app_settings. */
let ZINKIT_DELIVERY_RESTRICTION_ENABLED = true;
let ZINKIT_STORE_LAT = null;
let ZINKIT_STORE_LON = null;
let ZINKIT_DELIVERY_FRONT_KM = 10;
let ZINKIT_DELIVERY_BACK_KM = 10;
let ZINKIT_DELIVERY_LEFT_KM = 10;
let ZINKIT_DELIVERY_RIGHT_KM = 10;
let ZINKIT_STORE_NAME = 'ZinKit Store';
let ZINKIT_ACTIVE_STORE_ID = null;
let ZINKIT_ACTIVE_STORE_AREA = '';
let ZINKIT_ACTIVE_STORE_RANGE_KM = 10;
let ZINKIT_ACTIVE_STORE_CHARGE = 0;
let ZINKIT_DELIVERY_SETTINGS_READY = false;
let ZINKIT_STORE_MATCH_SOURCE = 'legacy';

function zinkitDistanceKm(lat1,lon1,lat2,lon2){
  const R=6371, toRad=x=>x*Math.PI/180;
  const dLat=toRad(lat2-lat1), dLon=toRad(lon2-lon1);
  const a=Math.sin(dLat/2)**2 + Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dLon/2)**2;
  return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
}

function zinkitMaxDeliveryRadiusKm(){
  return Math.max(
    Number(ZINKIT_DELIVERY_FRONT_KM)||0,
    Number(ZINKIT_DELIVERY_BACK_KM)||0,
    Number(ZINKIT_DELIVERY_LEFT_KM)||0,
    Number(ZINKIT_DELIVERY_RIGHT_KM)||0
  );
}

function zinkitDeliveryDistance(lat,lon){
  if(!Number.isFinite(Number(ZINKIT_STORE_LAT)) || !Number.isFinite(Number(ZINKIT_STORE_LON))) return NaN;
  return zinkitDistanceKm(Number(ZINKIT_STORE_LAT),Number(ZINKIT_STORE_LON),Number(lat),Number(lon));
}

function zinkitCheckDeliveryRange(lat,lon){
  /* OFF = no store-distance restriction. */
  if(!ZINKIT_DELIVERY_RESTRICTION_ENABLED){
    return {allowed:true,distance:zinkitDeliveryDistance(lat,lon),unrestricted:true};
  }
  const d=zinkitDeliveryDistance(lat,lon);
  const radius=zinkitMaxDeliveryRadiusKm();
  const allowed=Number.isFinite(d) && radius>0 && d<=radius;
  return {allowed,distance:d,radius,unrestricted:false};
}

function zinkitShowRangeStatus(distance,allowed){
  const el=$('orderPlaceStatus');
  if(!el)return;
  if(!ZINKIT_DELIVERY_RESTRICTION_ENABLED){
    el.textContent='✅ Delivery restriction OFF • Normal / unrestricted delivery';
    el.style.color='#16852b';
    return;
  }
  const radius=zinkitMaxDeliveryRadiusKm();
  if(!Number.isFinite(Number(distance))){
    el.textContent='❌ Store location Admin app mein set nahi hai.';
    el.style.color='#c62828';
    return;
  }
  el.textContent=allowed
    ? `✅ Delivery available • ${distance.toFixed(1)} km away (within ${radius} km)`
    : `❌ Delivery available nahi hai • ${distance.toFixed(1)} km away. ZinKit delivery range ${radius} km hai.`;
  el.style.color=allowed?'#16852b':'#c62828';
}

function zinkitDirectionAllowed(store,lat,lon){
  const slat=Number(store.latitude), slon=Number(store.longitude), clat=Number(lat), clon=Number(lon);
  if(![slat,slon,clat,clon].every(Number.isFinite)) return {allowed:false,distance:NaN,radius:0,direction:''};
  const distance=zinkitDistanceKm(slat,slon,clat,clon);
  if(store.delivery_restriction_enabled===false) return {allowed:true,distance,radius:Infinity,direction:'Unrestricted'};
  const y=Math.sin((clon-slon)*Math.PI/180)*Math.cos(clat*Math.PI/180);
  const x=Math.cos(slat*Math.PI/180)*Math.sin(clat*Math.PI/180)-Math.sin(slat*Math.PI/180)*Math.cos(clat*Math.PI/180)*Math.cos((clon-slon)*Math.PI/180);
  const bearing=(Math.atan2(y,x)*180/Math.PI+360)%360;
  let direction, key;
  if(bearing>=315||bearing<45){direction='North';key='delivery_front_km';}
  else if(bearing<135){direction='East';key='delivery_right_km';}
  else if(bearing<225){direction='South';key='delivery_back_km';}
  else {direction='West';key='delivery_left_km';}
  const fallback=Number(store.delivery_range_km)||0;
  const radius=Math.max(0,Number(store[key] ?? fallback)||0);
  return {allowed:radius>0 && distance<=radius,distance,radius,direction};
}
function zinkitSaveStoreChoice(id){
  if(id==null||id==='') localStorage.removeItem('zinkit_selected_store_id');
  else localStorage.setItem('zinkit_selected_store_id',String(id));
}
function zinkitGetStoreChoice(){return localStorage.getItem('zinkit_selected_store_id')||'';}
async function zinkitSelectStore(id){
  const stores=window.ZINKIT_STORES||[]; const s=stores.find(x=>String(x.id)===String(id));
  if(!s)return;
  // Manual store selection must not hide the store's products just because
  // the developer/test device is outside that store's delivery radius.
  // Delivery restriction is enforced at checkout; product browsing remains
  // available for the selected store.
  ZINKIT_ACTIVE_STORE_ID=s.id; ZINKIT_STORE_NAME=String(s.name||'ZinKit Store'); ZINKIT_ACTIVE_STORE_AREA=String(s.area||'');
  ZINKIT_STORE_LAT=Number(s.latitude); ZINKIT_STORE_LON=Number(s.longitude);
  ZINKIT_ACTIVE_STORE_RANGE_KM=Number(s.delivery_range_km)||10;
  ZINKIT_ACTIVE_STORE_CHARGE=Math.min(30,Math.max(0,Number(s.delivery_charge)||0));
  ZINKIT_DELIVERY_RESTRICTION_ENABLED=s.delivery_restriction_enabled!==false;
  ZINKIT_DELIVERY_FRONT_KM=Number(s.delivery_front_km??s.delivery_range_km??10)||0;
  ZINKIT_DELIVERY_BACK_KM=Number(s.delivery_back_km??s.delivery_range_km??10)||0;
  ZINKIT_DELIVERY_LEFT_KM=Number(s.delivery_left_km??s.delivery_range_km??10)||0;
  ZINKIT_DELIVERY_RIGHT_KM=Number(s.delivery_right_km??s.delivery_range_km??10)||0;
  ZINKIT_STORE_MATCH_SOURCE='manual'; window.ZINKIT_SELECTED_STORE={store:s}; zinkitSaveStoreChoice(s.id);
  zinkitUpdateSelectedStoreUI(); await loadProducts();
}
async function zinkitLoadDeliverySettings(){
  if(!db){
    ZINKIT_DELIVERY_SETTINGS_READY=true;
    return;
  }
  try{
    /* Multi-store first: active stores are candidates and the nearest
       store inside its own delivery range is selected for the customer. */
    /* Read all store columns so Customer V24 remains compatible with the
       current multi-store schema even when optional delivery columns have
       not been added to every store yet. */
    const sr=await db.from('stores')
      .select('*')
      .eq('active',true);

    if(!sr.error && Array.isArray(sr.data) && sr.data.length){
      window.ZINKIT_STORES=sr.data;
      let customerLat=Number(deliveryLocation?.latitude);
      let customerLon=Number(deliveryLocation?.longitude);

      if(Number.isFinite(customerLat) && Number.isFinite(customerLon)){
        let best=null;
        const savedId=zinkitGetStoreChoice();
        for(const s of sr.data){
          const slat=Number(s.latitude), slon=Number(s.longitude);
          /* Ignore placeholder 0,0 store coordinates during nearest-store
             matching; they must never win over a real store location. */
          if(!Number.isFinite(slat)||!Number.isFinite(slon)||(slat===0&&slon===0)) continue;
          const chk=zinkitDirectionAllowed(s,customerLat,customerLon);
          if(chk.allowed && (!best || (String(s.id)===String(savedId)) || chk.distance<best.distance)){
            best={store:s,distance:chk.distance,range:chk.radius,allowed:chk.allowed,restriction:s.delivery_restriction_enabled!==false,direction:chk.direction};
            if(String(s.id)===String(savedId)) break;
          }
        }
        if(best){
          const s=best.store;
          ZINKIT_ACTIVE_STORE_ID=s.id;
          ZINKIT_STORE_NAME=String(s.name||'ZinKit Store');
          ZINKIT_ACTIVE_STORE_AREA=String(s.area||'');
          ZINKIT_STORE_LAT=Number(s.latitude);
          ZINKIT_STORE_LON=Number(s.longitude);
          ZINKIT_ACTIVE_STORE_RANGE_KM=best.range;
          ZINKIT_ACTIVE_STORE_CHARGE=Math.min(30,Math.max(0,Number(s.delivery_charge)||0));
          ZINKIT_DELIVERY_RESTRICTION_ENABLED=best.restriction;
          ZINKIT_DELIVERY_FRONT_KM=Number(s.delivery_front_km??s.delivery_range_km??best.range)||0;
          ZINKIT_DELIVERY_BACK_KM=Number(s.delivery_back_km??s.delivery_range_km??best.range)||0;
          ZINKIT_DELIVERY_LEFT_KM=Number(s.delivery_left_km??s.delivery_range_km??best.range)||0;
          ZINKIT_DELIVERY_RIGHT_KM=Number(s.delivery_right_km??s.delivery_range_km??best.range)||0;
          window.ZINKIT_SELECTED_STORE=best;
          ZINKIT_STORE_MATCH_SOURCE='multi-store';
          ZINKIT_DELIVERY_SETTINGS_READY=true;
          return;
        }
      }

      // No GPS match: keep a previously selected active store, otherwise use
      // the first active store so store-scoped products never disappear just
      // because location permission is unavailable. Delivery restriction is
      // still enforced when the customer attempts a location-based checkout.
      const savedId=zinkitGetStoreChoice();
      // Without GPS, browse the active catalogue across stores by default.
      // Only narrow to one store when the customer explicitly selected that store.
      // This prevents a configured Admin store with no products from making the
      // whole Home Screen look empty before the customer adds a delivery location.
      const preferredId=savedId && String(savedId)!=='all' ? String(savedId) : '';
      if(!preferredId){
        ZINKIT_ACTIVE_STORE_ID=null;
        ZINKIT_STORE_NAME='All Stores';
        ZINKIT_ACTIVE_STORE_AREA='';
        ZINKIT_STORE_LAT=null; ZINKIT_STORE_LON=null;
        ZINKIT_ACTIVE_STORE_RANGE_KM=0; ZINKIT_ACTIVE_STORE_CHARGE=0;
        ZINKIT_STORE_MATCH_SOURCE='all-stores';
        window.ZINKIT_SELECTED_STORE={store:null,allStores:true};
        zinkitSaveStoreChoice('all');
        zinkitUpdateSelectedStoreUI();
        ZINKIT_DELIVERY_SETTINGS_READY=true;
        return;
      }
      const saved=sr.data.find(s=>String(s.id)===String(preferredId));
      const validStores=sr.data.filter(s=>{
        const la=Number(s.latitude),lo=Number(s.longitude);
        return Number.isFinite(la)&&Number.isFinite(lo)&&!(la===0&&lo===0);
      });
      const chosen=saved||validStores[0]||sr.data[0];
      if(chosen){
        ZINKIT_ACTIVE_STORE_ID=chosen.id;
        ZINKIT_STORE_NAME=String(chosen.name||'ZinKit Store');
        ZINKIT_ACTIVE_STORE_AREA=String(chosen.area||'');
        ZINKIT_STORE_LAT=Number(chosen.latitude);
        ZINKIT_STORE_LON=Number(chosen.longitude);
        ZINKIT_ACTIVE_STORE_RANGE_KM=Number(chosen.delivery_range_km)||10;
        ZINKIT_ACTIVE_STORE_CHARGE=Math.min(30,Math.max(0,Number(chosen.delivery_charge)||0));
        ZINKIT_DELIVERY_RESTRICTION_ENABLED=chosen.delivery_restriction_enabled!==false;
        ZINKIT_DELIVERY_FRONT_KM=Number(chosen.delivery_front_km??chosen.delivery_range_km??10)||0;
        ZINKIT_DELIVERY_BACK_KM=Number(chosen.delivery_back_km??chosen.delivery_range_km??10)||0;
        ZINKIT_DELIVERY_LEFT_KM=Number(chosen.delivery_left_km??chosen.delivery_range_km??10)||0;
        ZINKIT_DELIVERY_RIGHT_KM=Number(chosen.delivery_right_km??chosen.delivery_range_km??10)||0;
        window.ZINKIT_SELECTED_STORE={store:chosen};
        ZINKIT_STORE_MATCH_SOURCE='multi-store-default';
        zinkitSaveStoreChoice(chosen.id);
        zinkitUpdateSelectedStoreUI();
        ZINKIT_DELIVERY_SETTINGS_READY=true;
        return;
      }
    }

    /* Backward-compatible fallback to the existing app_settings system. */
    const keys=[
      'active_store_id',
      'delivery_restriction_enabled',
      'store_name',
      'store_latitude',
      'store_longitude',
      'delivery_front_km',
      'delivery_back_km',
      'delivery_left_km',
      'delivery_right_km'
    ];
    const r=await db.from('app_settings').select('key,value').in('key',keys);
    if(r.error) throw r.error;
    const m=Object.fromEntries((r.data||[]).map(x=>[x.key,x.value]));
    ZINKIT_ACTIVE_STORE_ID=m.active_store_id||null;
    ZINKIT_STORE_NAME=String(m.store_name||'ZinKit Store');
    ZINKIT_STORE_LAT=Number(m.store_latitude);
    ZINKIT_STORE_LON=Number(m.store_longitude);
    ZINKIT_DELIVERY_RESTRICTION_ENABLED=String(m.delivery_restriction_enabled??'true').toLowerCase()==='true';
    ZINKIT_DELIVERY_FRONT_KM=Math.max(0,Number(m.delivery_front_km??10)||0);
    ZINKIT_DELIVERY_BACK_KM=Math.max(0,Number(m.delivery_back_km??10)||0);
    ZINKIT_DELIVERY_LEFT_KM=Math.max(0,Number(m.delivery_left_km??10)||0);
    ZINKIT_DELIVERY_RIGHT_KM=Math.max(0,Number(m.delivery_right_km??10)||0);
    ZINKIT_ACTIVE_STORE_RANGE_KM=zinkitMaxDeliveryRadiusKm();
    ZINKIT_STORE_MATCH_SOURCE='legacy';
    ZINKIT_DELIVERY_SETTINGS_READY=true;
  }catch(e){
    console.warn('Multi-store delivery settings load failed:',e?.message||e);
    ZINKIT_DELIVERY_SETTINGS_READY=false;
  }
}
function zinkitDeliveryRangeLabel(){
  if(!ZINKIT_DELIVERY_RESTRICTION_ENABLED) return 'Normal / unrestricted delivery';
  const r=Number(ZINKIT_ACTIVE_STORE_RANGE_KM)||zinkitMaxDeliveryRadiusKm();
  return r>0 ? `${r} km` : 'Not configured';
}
function zinkitUpdateSelectedStoreUI(){
  const el=document.getElementById('zinkitSelectedStoreInfo');
  if(!el)return;
  const sel=document.getElementById('zinkitStoreSelector');
  if(sel && Array.isArray(window.ZINKIT_STORES)){
    const current=String(ZINKIT_ACTIVE_STORE_ID||'');
    sel.innerHTML='<option value="">🏪 Select store</option>'+window.ZINKIT_STORES.map(s=>`<option value="${esc(String(s.id))}">${esc(String(s.name||'ZinKit Store'))}${s.area?' • '+esc(String(s.area)):''}</option>`).join('');
    sel.value=current;
  }
  if(ZINKIT_STORE_MATCH_SOURCE==='multi-store' && ZINKIT_STORE_NAME){
    const area=ZINKIT_ACTIVE_STORE_AREA?` • ${ZINKIT_ACTIVE_STORE_AREA}`:'';
    el.textContent=`🏪 Store: ${ZINKIT_STORE_NAME}${area}`;
  }else if(ZINKIT_STORE_NAME){
    el.textContent=`🏪 Store: ${ZINKIT_STORE_NAME}`;
  }else{
    el.textContent='';
  }
}
function mdMunnaDayKey(){const d=new Date();return "zinkit_orders_"+d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0")}
function mdMunnaTodayOrderCount(){try{return Number(localStorage.getItem(mdMunnaDayKey())||0)}catch(e){return 0}}
function mdMunnaCanProcessOrder(){return mdMunnaTodayOrderCount()<MD_MUNNA_DAILY_ORDER_LIMIT}
function mdMunnaRecordProcessedOrder(){try{localStorage.setItem(mdMunnaDayKey(),String(mdMunnaTodayOrderCount()+1))}catch(e){}}
function mdMunnaShowDailyLimit(){alert("Aaj ke 1,000 orders complete ho gaye hain. Naye orders kal se process honge.")}
