ZinKit GitHub Android Cloud Build starter

Includes Customer, Admin and Rider PWA sources extracted unchanged from supplied V13 archive. Only Customer debug Android APK is configured for first test.

UPLOAD: Extract this ZIP in iPhone Files, then upload the CONTENTS (including .github folder) into GitHub repository root. GitHub website may not preserve hidden folders in some iPhone upload workflows; verify .github/workflows/android-customer-debug.yml exists. Keep existing original ZIP and README.

RUN: GitHub Actions -> ZinKit Customer Android Debug APK -> Run workflow -> download artifact after successful run. This is a DEBUG APK, not Play Store release.

IMPORTANT: This has not been run or signed. APK build and functionality are unverified. No Supabase SQL changes are needed. Never commit service-role keys, private credentials or .env files to a public repository. Review repository visibility and source before uploading.

For iOS: requires a separate macOS cloud runner and Apple signing credentials.
