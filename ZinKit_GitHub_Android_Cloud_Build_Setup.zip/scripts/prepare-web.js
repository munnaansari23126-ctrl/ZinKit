const fs=require('fs');fs.rmSync('www',{recursive:true,force:true});fs.cpSync('Customer','www',{recursive:true});console.log('Copied Customer PWA to www');
